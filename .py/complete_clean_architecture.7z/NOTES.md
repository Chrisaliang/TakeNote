app/libs/platformservicejar.jar是科大讯飞平台服务jar包
目前只用于调用平台蓝牙功能


1. 科大讯飞平台车机 获取序列号 需要通过属性
persist.sys.navi.uuid 来读取