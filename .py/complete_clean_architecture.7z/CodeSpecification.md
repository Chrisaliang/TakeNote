# 编码规范
    代码组织按照功能模块划分,各自的功能模块内部组织称相应的MVP，MVVM或者其他架构模式，这里一般采用MVVM架构(Android Databng)