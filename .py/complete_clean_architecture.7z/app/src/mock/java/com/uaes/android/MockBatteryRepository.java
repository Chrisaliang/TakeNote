package com.uaes.android;

import android.support.annotation.VisibleForTesting;

import com.uaes.android.domain.BatteryRepository;
import com.uaes.android.domain.entity.DMBatteryStatus;

import java.util.Random;

public class MockBatteryRepository implements BatteryRepository {

    @VisibleForTesting
    public DMBatteryStatus status = new DMBatteryStatus();
    private Random random = new Random();

    @Override
    public DMBatteryStatus queryBatteryStatus() {
        status.isAgeing = random.nextBoolean();
        status.isBatteryLifeFull = random.nextBoolean();
        status.hintDescription = "测试";
        return status;
    }

    @Override
    public DMBatteryStatus queryBatteryVol() {
        status.isAgeing = random.nextBoolean();
        status.isBatteryLifeFull = random.nextBoolean();
        status.hintDescription = "测试";
        return status;
    }

    @Override
    public String queryBatteryDescription(boolean isStatus, boolean isVol) {
        return "测试";
    }
}
