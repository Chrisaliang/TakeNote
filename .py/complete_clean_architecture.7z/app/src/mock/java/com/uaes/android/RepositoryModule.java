package com.uaes.android;

import com.google.gson.Gson;
import com.uaes.android.data.AMapLocationRepository;
import com.uaes.android.data.MaintainRepositoryImp;
import com.uaes.android.data.MessageCenterRepositoryImp;
import com.uaes.android.data.http.HttpMaintainApi;
import com.uaes.android.data.room.CacheDao;
import com.uaes.android.domain.BatteryRepository;
import com.uaes.android.domain.DriverMasterRepository;
import com.uaes.android.domain.FuelHelperRepository;
import com.uaes.android.domain.LocationRepository;
import com.uaes.android.domain.MaintainRepository;
import com.uaes.android.domain.MessageCenterRepository;
import com.uaes.android.domain.PowerDefenderRepository;
import com.uaes.android.domain.S4ShopRepository;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

@Module
abstract class RepositoryModule {

    @Provides
    @Singleton
    static FuelHelperRepository providerFuelHelperRepository(Gson gson, App app) {
        return new MockFuelHelperRepository(app, gson);
    }

    @Provides
    @Singleton
    static BatteryRepository providerBatterRepository() {
        return new MockBatteryRepository();
    }

    @Provides
    @Singleton
    static LocationRepository providerLocationRepository(App app) {
        return new AMapLocationRepository(app);
    }

    @Provides
    @Singleton
    static MessageCenterRepository providerMessageCenterRepository(CacheDao cacheDao) {
        return new MessageCenterRepositoryImp(cacheDao);
    }

    @Provides
    @Singleton
    static DriverMasterRepository providerDriverManagerRepository() {
        return new MockDriverMasterRepository();
    }

    @Provides
    @Singleton
    static MaintainRepository providerMaintainRepository(HttpMaintainApi api, Gson gson, App app) {
        return new MaintainRepositoryImp(api, gson, app);
    }


    @Provides
    @Singleton
    static PowerDefenderRepository providerPowerRepository(App app, Gson gson) {
        return new MockPowerRepository(gson, app);
    }


    @Provides
    @Singleton
    static S4ShopRepository providerS4ShopRepository(App app, Gson gson) {
        return new MockS4ShopRepository(app, gson);
    }

}
