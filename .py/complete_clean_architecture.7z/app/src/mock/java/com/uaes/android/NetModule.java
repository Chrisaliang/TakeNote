package com.uaes.android;

import com.google.gson.Gson;
import com.uaes.android.data.http.HttpFuelHelper;
import com.uaes.android.data.http.HttpMaintainApi;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

/**
 * Created by hand on 2017/11/1.
 * Net work module
 */
@Module
public abstract class NetModule {

    @Singleton
    @Provides
    static HttpFuelHelper providerFuelHelper(App app, Gson gson) {
        return new MockHttpFuelHelper(app, gson);
    }

    @Singleton
    @Provides
    static HttpMaintainApi providerMaintainApi() {
        return new MockHttpMaintain();
    }
}
