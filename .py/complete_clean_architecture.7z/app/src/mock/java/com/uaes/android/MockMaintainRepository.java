package com.uaes.android;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.google.gson.stream.JsonReader;
import com.uaes.android.domain.MaintainRepository;
import com.uaes.android.domain.entity.DMMaintainItemDetail;
import com.uaes.android.domain.entity.DMMaintainRating;
import com.uaes.android.domain.entity.DMMaintainRecord;
import com.uaes.android.domain.entity.DMMaintainSetting;
import com.uaes.android.domain.entity.DMMaintainStatus;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class MockMaintainRepository implements MaintainRepository {

    private App app;

    private Gson gson;

    private DMMaintainSetting dmMaintainSetting = new DMMaintainSetting();

    private DMMaintainStatus status;

    private List<DMMaintainRecord> records;


    MockMaintainRepository(App app, Gson gson) {
        this.app = app;
        this.gson = gson;
    }

    @Override
    public DMMaintainStatus queryStatus() {

        if (status == null) {
            status = new DMMaintainStatus();
            status.maintainType = MaintainRepository.TYPE_MAINTAIN_MILE;
            status.maintainValue = 896;
            status.maintainList = new ArrayList<>();
            status.maintainList.add("更换发动机机油");
            status.maintainList.add("更换变速器油");
            status.maintainList.add("更换发动机机油");
            status.maintainList.add("更换变速器油");
            status.maintainList.add("更换发动机机油");
            status.maintainList.add("更换发动机机油");
            status.maintainList.add("更换发动机机油");
            status.maintainList.add("更换发动机机油");
            status.maintainList.add("更换发动机机油");
            status.maintainList.add("更换发动机机油");
        }
        return status;
    }

    @Override
    public DMMaintainSetting querySetting() {
        return dmMaintainSetting;
    }

    @Override
    public boolean updateSetting(DMMaintainSetting setting) {
        dmMaintainSetting.isAllowedPush = setting.isAllowedPush;
        dmMaintainSetting.pushFrequency = setting.pushFrequency;
        dmMaintainSetting.pushType = setting.pushType;
        return true;
    }

    @Override
    public List<DMMaintainRecord> queryRecord() throws Exception {
        if (records == null) {
            InputStream inputStream = null;
            try {
                inputStream = app.getAssets().open("maintain_records.json");
                Type type = new TypeToken<List<DMMaintainRecord>>() {
                }.getType();
                records = gson.fromJson(new JsonReader(new InputStreamReader(inputStream)), type);
            } finally {
                if (inputStream != null)
                    inputStream.close();
            }
        }
        return records;
    }

    @Override
    public boolean ratingRecord(DMMaintainRating rating) {
        return false;
    }

    @Override
    public DMMaintainItemDetail queryDMMaintainItemDetail(int type) throws Exception {
        return new DMMaintainItemDetail();
    }
}
