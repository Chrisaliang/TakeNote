package com.uaes.android;

import com.uaes.android.data.http.HttpMaintainApi;
import com.uaes.android.data.json.CommonResponse;
import com.uaes.android.data.json.MaintainContentItemJson;
import com.uaes.android.data.json.MaintainRecordJson;
import com.uaes.android.data.json.MaintainSettingJson;
import com.uaes.android.data.json.MaintainStatusJson;
import com.uaes.android.data.json.MaintainStatusReminderJson;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Nullable;

import okhttp3.MediaType;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import okio.BufferedSource;
import retrofit2.Call;
import retrofit2.Response;

/**
 * Created by ${GY} on 2018/5/23
 * des：
 */
public class MockHttpMaintain implements HttpMaintainApi {
    @Override
    public Call<CommonResponse<MaintainStatusJson>> queryStatus() {
        return new MockCall<CommonResponse<MaintainStatusJson>>() {
            @Override
            public Response<CommonResponse<MaintainStatusJson>> execute() {
                MaintainStatusJson maintainStatusJson = new MaintainStatusJson();
                MaintainStatusReminderJson maintainStatusReminderJson = new MaintainStatusReminderJson();
                maintainStatusReminderJson.maintainType = "day";
                maintainStatusReminderJson.maintainValue = "1000";
                maintainStatusJson.statusReminder = maintainStatusReminderJson;
                ArrayList<MaintainContentItemJson> itemList = new ArrayList<>();
                for (int i = 0; i < 6; i++) {
                    MaintainContentItemJson maintainContentItemJson = new MaintainContentItemJson(String.valueOf(i + 1), "机油保养");
                    itemList.add(maintainContentItemJson);
                }
                maintainStatusJson.maintainList = itemList;
                CommonResponse<MaintainStatusJson> receive = new CommonResponse<>();
                receive.msgContent = maintainStatusJson;
                return Response.success(receive);
            }
        };
    }

    @Override
    public Call<CommonResponse<MaintainSettingJson>> querySetting() {
        return new MockCall<CommonResponse<MaintainSettingJson>>() {
            @Override
            public Response<CommonResponse<MaintainSettingJson>> execute() {
                MaintainSettingJson maintainSettingJson = new MaintainSettingJson(true, 1, 2);
                CommonResponse<MaintainSettingJson> receive = new CommonResponse<>();
                receive.msgContent = maintainSettingJson;
                return Response.success(receive);
            }
        };
    }

    @Override
    public Call<ResponseBody> updateSetting(RequestBody body) {
        return new MockCall<ResponseBody>() {
            @Override
            public Response<ResponseBody> execute() {
                ResponseBody body1 = new ResponseBody() {
                    @Nullable
                    @Override
                    public MediaType contentType() {
                        return null;
                    }

                    @Override
                    public long contentLength() {
                        return 0;
                    }

                    @Override
                    public BufferedSource source() {
                        return null;
                    }
                };
                return Response.success(body1);
            }
        };
    }

    @Override
    public Call<CommonResponse<List<MaintainRecordJson>>> queryRecord() {
        return new MockCall<CommonResponse<List<MaintainRecordJson>>>() {
            @Override
            public Response<CommonResponse<List<MaintainRecordJson>>> execute() {
                ArrayList<MaintainRecordJson> maintainRecordJsons = new ArrayList<>();
                for (int i = 0; i < 3; i++) {
                    MaintainRecordJson maintainRecordJson = new MaintainRecordJson();
                    maintainRecordJson.id = "222";
                    maintainRecordJson.name = "上海市浦东新区4S店";
                    maintainRecordJson.mile = 55555;
                    maintainRecordJson.time = "2018-04-05 15:33";
                    maintainRecordJson.attitudeRating = 4;
                    maintainRecordJson.serviceRating = 3;
                    maintainRecordJson.transparencyOfFeesRate = 2;
                    ArrayList<MaintainContentItemJson> contentList = new ArrayList<>();
                    for (int i1 = 0; i1 < 8; i1++) {
                        MaintainContentItemJson maintainRecordContentJson = new MaintainContentItemJson("333"
                                , "打蜡了");
                        contentList.add(maintainRecordContentJson);
                    }
                    maintainRecordJson.maintainContents = contentList;
                    maintainRecordJsons.add(maintainRecordJson);
                }
                CommonResponse<List<MaintainRecordJson>> receive = new CommonResponse<>();
                receive.msgContent = maintainRecordJsons;
                return Response.success(receive);
            }
        };
    }

    @Override
    public Call<ResponseBody> ratingRecord(RequestBody body) {
        return new MockCall<ResponseBody>() {
            @Override
            public Response<ResponseBody> execute() {
                ResponseBody body1 = new ResponseBody() {
                    @Nullable
                    @Override
                    public MediaType contentType() {
                        return null;
                    }

                    @Override
                    public long contentLength() {
                        return 0;
                    }

                    @Override
                    public BufferedSource source() {
                        return null;
                    }
                };
                return Response.success(body1);
            }
        };
    }
}
