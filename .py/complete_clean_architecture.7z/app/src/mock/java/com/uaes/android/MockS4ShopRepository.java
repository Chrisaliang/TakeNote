package com.uaes.android;

import android.support.annotation.Nullable;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.uaes.android.domain.S4ShopRepository;
import com.uaes.android.domain.entity.DM4SShop;

import java.util.List;

public class MockS4ShopRepository implements S4ShopRepository {

    private App app;

    private Gson gson;

    MockS4ShopRepository(App app, Gson gson) {
        this.app = app;
        this.gson = gson;
    }


    @Nullable
    @Override
    public List<DM4SShop> queryList(String province, double latitude, double longitude) throws Exception {
        return JsonLoadHelper.loadJson(gson, app, "4s_shop.json", new TypeToken<List<DM4SShop>>() {
        }.getType());
    }
}
