package com.uaes.android;

import android.content.Context;

import com.google.gson.Gson;
import com.google.gson.stream.JsonReader;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;

public class JsonLoadHelper {

    public static <T> T loadJson(Gson gson, Context context, String fileName, Type type) throws Exception {
        InputStream inputStream = null;
        try {
            inputStream = context.getAssets().open(fileName);
            return gson.fromJson(new JsonReader(new InputStreamReader(inputStream)), type);
        } finally {
            if (inputStream != null)
                inputStream.close();
        }
    }
}
