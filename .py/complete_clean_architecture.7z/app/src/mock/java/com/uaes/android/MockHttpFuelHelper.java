package com.uaes.android;

import android.content.Context;
import android.support.annotation.NonNull;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import com.uaes.android.data.http.HttpFuelHelper;
import com.uaes.android.data.json.CommonResponse;
import com.uaes.android.data.json.FuelFillRecordJson;
import com.uaes.android.data.json.FuelMonitorJson;
import com.uaes.android.data.json.FuelScale;
import com.uaes.android.data.json.FuelStationJson;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.util.List;

import okhttp3.Request;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MockHttpFuelHelper implements HttpFuelHelper {

    private Context context;
    private Gson gson;

    MockHttpFuelHelper(Context context, Gson gson) {
        this.context = context;
        this.gson = gson;
    }

    @Override
    public Call<CommonResponse<FuelScale>> getFuelScale(String queryType) {
        return new Call<CommonResponse<FuelScale>>() {
            @Override
            public Response<CommonResponse<FuelScale>> execute() throws IOException {
                InputStream inputStream = context.getAssets().open("fuel_scale.json");
                Type type = new TypeToken<CommonResponse<FuelScale>>() {
                }.getType();
                CommonResponse<FuelScale> result = gson.fromJson(new InputStreamReader(inputStream), type);
                inputStream.close();
                return Response.success(result);
            }

            @Override
            public void enqueue(@NonNull Callback<CommonResponse<FuelScale>> callback) {

            }

            @Override
            public boolean isExecuted() {
                return false;
            }

            @Override
            public void cancel() {

            }

            @Override
            public boolean isCanceled() {
                return false;
            }

            @SuppressWarnings("MethodDoesntCallSuperMethod")
            @Override
            public Call<CommonResponse<FuelScale>> clone() {
                return null;
            }

            @Override
            public Request request() {
                return null;
            }
        };
    }

    @Override
    public Call<CommonResponse<FuelMonitorJson>> getMonitor() {
        return null;
    }

    @Override
    public Call<CommonResponse<List<FuelStationJson>>> getStation(String location, int strategy) {
        return null;
    }

    @Override
    public Call<JsonObject> setFuelAccount(long eventId, int star) {
        return null;
    }

    @Override
    public Call<CommonResponse<List<FuelFillRecordJson>>> getFillRecord(String year) {
        return null;
    }

    @Override
    public Call<CommonResponse<List<String>>> queryAvailableYears() {
        return null;
    }

}
