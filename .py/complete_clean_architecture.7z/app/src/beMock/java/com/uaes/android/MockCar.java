package com.uaes.android;

/**
 * Created by aber on 1/24/2018.
 * 测试环境
 */

public interface MockCar {

    String MOCK_VIN = "testBE"; // 六楼车机
    String MOCK_SN = "863010031601283"; // 实车
    boolean MOCK = true;
}
