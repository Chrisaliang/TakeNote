package com.uaes.android;

import com.google.gson.Gson;

import org.junit.Before;
import org.junit.Test;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DataFormatTest {

    private static final String json = "{'time':'2018-05-21 14:20:23'}";
    private Date date;
    private Gson gson;
    private String pattern = "yyyy.MM.dd\nHH:mm:ss";

    @Before
    public void setUp() {

        gson = new Gson();
//        gson = new GsonBuilder()
//                .setDateFormat(pattern)
//                .create();
        Time time = gson.fromJson(json, Time.class);
        date = time.time;
    }

    @Test
    public void testDateFormat() {

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

        String format1 = simpleDateFormat.format(date);

        Time time = gson.fromJson(json, Time.class);

//        System.out.println(time);

        System.out.println(format1);
//        String format = simpleDateFormat.format(new Date());

//        System.out.println(format);

    }

    class Time {

        Date time;

        @Override
        public String toString() {
            return new SimpleDateFormat(pattern).format(time);
        }
    }
}
