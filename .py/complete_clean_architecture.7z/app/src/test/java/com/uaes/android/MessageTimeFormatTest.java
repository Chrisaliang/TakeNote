package com.uaes.android;

import com.google.gson.Gson;

import org.junit.Before;
import org.junit.Test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MessageTimeFormatTest {

    private static final String PATTERN = "yyyy-MM-dd HH:mm";

    private Gson gson;

    private SimpleDateFormat sdf;

    @Before
    public void setUp() {
        gson = new Gson();
        sdf = new SimpleDateFormat();
        sdf.applyPattern(PATTERN);
    }

    @Test
    public void dateTest() {

//        String rawTime = "{'time':'2017-11-17 13:32:22'}";
//        Time date = gson.fromJson(rawTime, Time.class);
//        String msgTime = new SimpleDateFormat(PATTERN).format(date.time);

        String rawTime = "2017-11-17 13:32:22";
        Date date = null;
        try {
            sdf.applyPattern("yyyy-MM-dd HH:mm:ss");
            date = sdf.parse(rawTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        sdf.applyPattern(PATTERN);
        String msgTime = sdf.format(date);

        System.out.println(msgTime);
    }


    @Deprecated
    static class Time {
        Date time;
    }
}
