package com.uaes.android;

import com.aliyuncs.DefaultAcsClient;
import com.aliyuncs.exceptions.ClientException;
import com.aliyuncs.http.ProtocolType;
import com.aliyuncs.profile.DefaultProfile;
import com.aliyuncs.profile.IClientProfile;
import com.aliyuncs.push.model.v20160801.PushMessageToAndroidRequest;
import com.aliyuncs.push.model.v20160801.PushMessageToAndroidResponse;

import org.junit.Before;
import org.junit.Test;

public class AliPushTest {

    private static final String accessKeyId = "LTAIrNFBbdmMIaef";
    private static final String accessKeySecret = "QQsBR9SaQxXX1iJzByHaL46nXBDLv8";


    private static final String messageRequestBody = "{" +
            "\"TYPE\":\"fuelWarn\"," +
            "\"title\":\"消息推送测试推荐\"," +
            "\"messageClass\":\"通知\"," +
            "\"systemTime\":\"2017-11-17 13:32:22\"," +
            "\"body\":警告你的车子已经没有机油了" +
            "}";


    private DefaultAcsClient client;

    @Before
    public void setUp() {
        IClientProfile profile = DefaultProfile.getProfile(
                "cn-hangzhou",
                accessKeyId,
                accessKeySecret
        );
        client = new DefaultAcsClient(profile);
        client.setAutoRetry(true);
    }

    @Test
    public void sendMsg() throws ClientException {

        PushMessageToAndroidRequest pushMessageToAndroidRequest
                = new PushMessageToAndroidRequest();
        pushMessageToAndroidRequest.setTarget("ACCOUNT");
        pushMessageToAndroidRequest.setTargetValue(MockCar.MOCK_VIN);
        pushMessageToAndroidRequest.setAppKey(ServiceEnvironment.appKey);
        pushMessageToAndroidRequest.setTitle("Message: ");
        pushMessageToAndroidRequest.setBody(messageRequestBody);
        pushMessageToAndroidRequest.setProtocol(ProtocolType.HTTPS);

        PushMessageToAndroidResponse pushResponse = client.getAcsResponse(pushMessageToAndroidRequest);
        System.out.printf("RequestId: %s, Message ID: %s\n",
                pushResponse.getRequestId(), pushResponse.getMessageId());
    }
}
