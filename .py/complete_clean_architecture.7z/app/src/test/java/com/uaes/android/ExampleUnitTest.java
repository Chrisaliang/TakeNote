package com.uaes.android;

import com.uaes.android.domain.BatteryRepository;
import com.uaes.android.domain.JobThread;
import com.uaes.android.domain.entity.DMBatteryStatus;
import com.uaes.android.domain.usecase.BatteryStatusSubscription;

import org.junit.Assert;
import org.junit.Test;

import io.reactivex.Observer;
import io.reactivex.Scheduler;
import io.reactivex.disposables.Disposable;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * @see <a href="http://d.android.com/tools/testing">Testing documentation</a>
 */
public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() {
        assertEquals(4, 2 + 2);
    }

    @Test
    public void mockTest() {

        final DMBatteryStatus status = new DMBatteryStatus();

        BatteryRepository repository = mock(BatteryRepository.class);

        BatteryStatusSubscription batteryStatusSubscription = new BatteryStatusSubscription(
                repository,
                new JobThread() {
                    @Override
                    public Scheduler providerUi() {
                        return null;
                    }

                    @Override
                    public Scheduler provideWorker() {
                        return null;
                    }
                }
        );
        batteryStatusSubscription.execute().subscribe(new Observer<DMBatteryStatus>() {
            @Override
            public void onSubscribe(Disposable d) {

            }

            @Override
            public void onNext(DMBatteryStatus dmBatteryStatus) {
                Assert.assertEquals(status, dmBatteryStatus);
            }

            @Override
            public void onError(Throwable e) {

            }

            @Override
            public void onComplete() {

            }
        });
    }
}