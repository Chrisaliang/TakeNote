package com.uaes.android;

import android.content.Context;
import android.content.Intent;
import android.support.test.InstrumentationRegistry;
import android.support.test.runner.AndroidJUnit4;

import com.uaes.android.common.Intents;

import org.junit.Test;
import org.junit.runner.RunWith;

@RunWith(AndroidJUnit4.class)
public class BroadcastTest {

    private static final String json = "{" +
            "\"deviceName\": \"LNBSCUAK5HF043611\"," +
            "\"TY\": \"CTR\"," +
            "\"nowDate\": \"2018-06-01 11:23:14\"," +
            "\"fltlvl\": 1," +
            "\"title\": \"hello\"," +
            "\"voiceContent\": \"hello hello\"," +
            "\"textContent\": \"hello\"" +
            "}";

    @Test
    public void sendBroadcast() {

        Context context = InstrumentationRegistry.getTargetContext();

        Intent broadcast = new Intent(Intents.ACTION_MQTT_CTR);
        broadcast.putExtra(Intents.KEY_MQTT_CTR, json);
        context.sendBroadcast(broadcast);
    }
}
