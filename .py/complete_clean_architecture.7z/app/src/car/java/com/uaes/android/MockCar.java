package com.uaes.android;

/**
 * Created by aber on 1/24/2018.
 * 测试环境
 */

public interface MockCar {
    boolean MOCK = false;
    String MOCK_VIN = "testEmulator"; // 六楼模拟器
    String MOCK_SN = "863010031601282"; // 实车
}
