package com.uaes.android;

/**
 * 测试环境服务端配置
 * */
public interface ServiceEnvironment {
    String BASE_URL = "https://tst-api-iot.uaes.com";
    long appKey = 24695401;
}
