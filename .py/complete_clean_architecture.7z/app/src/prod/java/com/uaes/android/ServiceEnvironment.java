package com.uaes.android;

/**
 * 生产环境服务端配置
 * */
public interface ServiceEnvironment {
    String BASE_URL = "";
}
