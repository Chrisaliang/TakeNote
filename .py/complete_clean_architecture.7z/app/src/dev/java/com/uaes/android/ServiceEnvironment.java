package com.uaes.android;

/**
 * 测试环境服务端配置
 * */
public interface ServiceEnvironment {
    String BASE_URL = "https://dev-api-iot.uaes.com";
    long appKey = 24675829;
}
