package com.uaes.android.presenter.driver;

public class DriverMasterPage {

    // 页面状态 提示
    public String titleSum;

    // 页面状态 提示 描述
    public String titleDsc;

    // 急加速
    public int acuteAcc;

    // 急刹车
    public int acuteBreak;

    // 急转弯
    public int acuteTurn;

    // 连续加减速
    public int continueAccAndDec;

    // 凌晨驾驶
    public int nightDrive;
}
