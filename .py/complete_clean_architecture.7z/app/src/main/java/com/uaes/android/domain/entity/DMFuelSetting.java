package com.uaes.android.domain.entity;

import android.support.annotation.IntRange;

import com.uaes.android.domain.FuelHelperRepository;

/**
 * 用油会计设置
 */
public class DMFuelSetting {

    @FuelHelperRepository.GasFilter
    public int gasQuery;

    @IntRange(from = 3, to = 50)
    public int fuelThreshold;
}
