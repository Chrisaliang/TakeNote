package com.uaes.android.presenter.powerdefender.pojo;

/**
 * Created by diaokaibin@gmail.com on 2018/5/14.
 */
public class PowerPart {
    public String title;
    public String errorSubject;
    public String errorContent;
}
