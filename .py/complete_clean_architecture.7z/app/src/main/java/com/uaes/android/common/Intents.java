package com.uaes.android.common;

/**
 * 全局Keys, Actions
 * */
public interface Intents {
    /**
     * 授权动作广播
     */
    String ACTION_AUTHORIZATION = "com.uaes.android.common.ACTION_AUTHORIZATION";

    /**
     * 内部网络错误广播, 使用 LocalBroadcastManager  发送该广播
     * 通知弹窗
     */
    String ACTION_NETWORK_ERROR = "com.uaes.android.common.NETWORK_ERROR";

    /**
     * 动力卫士主页面刷新广播
     */
    String ACTION_POWER_TRAIN_GUARD = "com.uaes.iot.ACTION_POWER_TRAIN_GUARD";

    /**
     * Mqtt 消息指令广播
     */
    String ACTION_MQTT_CTR = "com.uaes.iot.ACTION_MQTT_CTR";

    /**
     * Mqtt 消息KEY , 使用KEY , 类型是String
     */
    String KEY_MQTT_CTR = "com.uaes.iot.KEY_MQTT_CTR";
}
