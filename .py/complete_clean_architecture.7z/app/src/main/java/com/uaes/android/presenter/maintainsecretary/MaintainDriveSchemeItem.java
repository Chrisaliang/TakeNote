package com.uaes.android.presenter.maintainsecretary;

/**
 * Created by ${GY} on 2018/5/10
 * des：
 */
public class MaintainDriveSchemeItem {
    public String minutes;
    public String miles;
    public String lightNumbers;
    public String detailPassWay;
    public int position;
    public boolean isChoice;
}
