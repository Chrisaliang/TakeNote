package com.uaes.android.domain.usecase;

import android.support.annotation.Nullable;

import com.uaes.android.domain.DMMsgUpdateListener;
import com.uaes.android.domain.JobThread;
import com.uaes.android.domain.MessageCenterRepository;
import com.uaes.android.domain.entity.DMMessageCenterItem;
import com.uaes.android.presenter.message.MsgMapper;
import com.uaes.android.presenter.message.UpdateMessageListener;

import io.reactivex.BackpressureStrategy;
import io.reactivex.Flowable;
import io.reactivex.FlowableEmitter;
import io.reactivex.FlowableOnSubscribe;

public class MessageCenterMsgUpdate implements DMMsgUpdateListener {


    private MessageCenterRepository repository;

    private JobThread jobThread;

    private UpdateMessageListener listener;

    private MsgMapper mapper;

    public MessageCenterMsgUpdate(MessageCenterRepository repository, JobThread jobThread) {
        this.repository = repository;
        this.jobThread = jobThread;
        mapper = new MsgMapper();
    }

    public void setListener(@Nullable UpdateMessageListener listener) {
        this.listener = listener;
    }

    public Flowable<DMMessageCenterItem> execute() {
//        return Single.just(repository.)
//        repository.updateMessage();
        return Flowable.create(new FlowableOnSubscribe<DMMessageCenterItem>() {
            @Override
            public void subscribe(FlowableEmitter<DMMessageCenterItem> emitter) {
                repository.updateMessage(emitter);
            }
        }, BackpressureStrategy.BUFFER)
                .observeOn(jobThread.providerUi())
                .subscribeOn(jobThread.provideWorker());
    }

//    public void execute() {
//
////        if (listener != null)
////            repository.updateMessage(this);
//
////        return repository.updateMessage()
////                .observeOn(jobThread.providerUi())
////                .subscribeOn(jobThread.provideWorker());
//    }

    @Override
    public void onUpdate(DMMessageCenterItem item) {
        if (this.listener != null)
            this.listener.onItemUpdate(mapper.map(item));
    }

}
