package com.uaes.android;

import javax.inject.Singleton;

import dagger.android.AndroidInjector;
import dagger.android.support.AndroidSupportInjectionModule;

@Singleton
@dagger.Component(
        modules = {
                AndroidSupportInjectionModule.class,
                AndroidComponentModule.class,
                JsonModule.class,
                PersistentModule.class,
                RepositoryModule.class,
                UseCaseModule.class,
                SchedulerModule.class,
                ViewModelModule.class,
                C51EModule.class,
                NetModule.class
        }
)
public interface AppComponent extends AndroidInjector<App> {
    @dagger.Component.Builder
    abstract class Builder extends AndroidInjector.Builder<App> {
    }
}
