package com.uaes.android.domain.usecase;

import com.uaes.android.domain.JobThread;
import com.uaes.android.domain.MessageCenterRepository;
import com.uaes.android.domain.SingleUseCase;
import com.uaes.android.domain.entity.DMMessageCenterItem;

import java.util.List;

import io.reactivex.Single;
import io.reactivex.functions.Function;

public class MessageCenterMsgQuery extends SingleUseCase<List<DMMessageCenterItem>> {

    private MessageCenterRepository repository;

    private JobThread jobThread;

    private int messageType = MessageCenterRepository.MESSAGE_CENTER_QUERY_ALL;

    public MessageCenterMsgQuery(MessageCenterRepository repository, JobThread jobThread) {
        this.repository = repository;
        this.jobThread = jobThread;
    }


    public void setMessageType(@MessageCenterRepository.MsgType int messageType) {
        this.messageType = messageType;
    }

    @Override
    protected Single<List<DMMessageCenterItem>> buildSingle() {
        return Single.just(repository)
                .map(new Function<MessageCenterRepository, List<DMMessageCenterItem>>() {
                    @Override
                    public List<DMMessageCenterItem> apply(MessageCenterRepository repository) {
                        return repository.queryMessage(messageType);
                    }
                })
                .observeOn(jobThread.providerUi())
                .subscribeOn(jobThread.provideWorker());
    }
}
