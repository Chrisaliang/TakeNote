package com.uaes.android.tts;

import android.annotation.SuppressLint;
import android.content.Context;
import android.media.AudioManager;
import android.media.AudioManager.OnAudioFocusChangeListener;
import android.os.Handler;

import com.iflytek.autofly.utils.FlyLog;
import com.iflytek.autofly.voicecore.tts.TtsInitListener;
import com.iflytek.autofly.voicecore.tts.TtsListener;
import com.iflytek.autofly.voicecore.tts.TtsSession;
import com.iflytek.autofly.voicecore.tts.TtsSessionManager;

import java.lang.reflect.Method;

/**
 * Tts
 *
 * @author admin<br>
 * description: Tts<br/>
 * create: 2015-12-19 morning 11:07:26<br/>
 */

@Deprecated
public class Tts {

    private static final String TAG = "Tts";
    // tts 设置手机模式
    private static final String TTS_SPEECH_MOBILE_MODE = "[k2]";
    // tts 设置导航模式
    private static final String TTS_SPEECH_NAVIGATE_MODE = "[k1]";
    // tts 设置通用模式
    private static final String TTS_SPEECH_NORMAL_MODE = "[k0]";
    // tts 发音人
    private static final int SPEAKER_SELF_DEFINED = 99;
    // tts 开启提示音
    private static final String TTS_SPEECH_OPEN_REFER = "[x1]";
    // tts 关闭提示音
    private static final String TTS_SPEECH_CLOSE_REFER = "[x0]";
    // tts 强制将数字读取为号码
    private static final String TTS_SPEECH_PHONE_NUM_MODE = "[n1]";
    // tts 强制将数字读取为数值
    private static final String TTS_SPEECH_VALUE_NUM_MODE = "[n2]";
    // tts 读取普通数字
    private static final String TTS_SPEECH_NORMAL_NUM_MODE = "[n0]";
    // tts 强制使用姓名读音规则
    private static final String TTS_SPEECH_NAME_FORCE_MODE = "[r1]";
    // tts 自动判断姓名读音
    private static final String TTS_SPEECH_NAME_NORMAL_MODE = "[r0]";
    // tts 使用韵律标注
    private static final String TTS_SPEECH_OPEN_PROSODY = "[z1]";
    // tts 不使用韵律标注
    private static final String TTS_SPEECH_CLOSE_PROSODY = "[z0]";
    // tts 字母发音
    private static final String TTS_SPEECH_LETTER = "[h1]";
    // tts 单词发音
    private static final String TTS_SPEECH_WORD = "[h2]";
    private static Tts mInstance = null;
    private static TtsSession mSessionEntity = null;
    private final Handler mHandler = new Handler();
    // TTS 播报
    private TtsSessionManager mTtsSessionManager;
    // 是否正在播放
    private boolean mIsPlaying = false;
    //处理延迟处理
    private Context mContext;
    //handle audio focus.
    private AudioFocusManager mManager;
    private OnAudioFocusChangeListener mFocusListener = new OnAudioFocusChangeListener() {
        @Override
        public void onAudioFocusChange(int focusChange) {
            FlyLog.d(TAG, "onAudioFocusChange | FocusChange " + focusChange);

            if (AudioManager.AUDIOFOCUS_LOSS == focusChange) {
                if (null != mSessionEntity) {
                    mSessionEntity.stopSpeak();
                }
                mManager.abandonAudioFocus(mFocusListener);
                FlyLog.d(TAG, "onAudioFocusChange | AudioFocus Loss");
            } else if (AudioManager.AUDIOFOCUS_LOSS_TRANSIENT == focusChange) {
                if (null != mSessionEntity) {
                    mSessionEntity.pauseSpeak();
                }
                FlyLog.d(TAG, "onAudioFocusChange | AudioFocus Loss TRANSIENT");
            } else if (AudioManager.AUDIOFOCUS_GAIN == focusChange) {
                if (null != mSessionEntity) {
                    mSessionEntity.resumeSpeak();
                }
                FlyLog.d(TAG, "onAudioFocusChange | AudioFocus gain");
            }
        }
    };

    private TtsListener mPlayerListener = new TtsListener() {

        // TTS开始播报
        @Override
        public void onPlayBegin() {

            FlyLog.d(TAG, "onPlayBegin | TTS onPlayBegin");
            mIsPlaying = true;
        }

        //播报中断
        @Override
        public void onPlayInterrupted() {

            FlyLog.d(TAG, "onPlayInterrupted | TTS onPlayInterrupted");
            // mPlayer.stop();
            if (null != mSessionEntity) {
                mSessionEntity.stopSpeak();
                abandonFocus();
            }
        }

        //TTS播报结束
        @Override
        public void onPlayCompleted() {

            FlyLog.d(TAG, "onPlayCompleted | TTS onPlayCompleted");
            mIsPlaying = false;
            mManager.abandonAudioFocus(mFocusListener);
            // resume();
        }

        @Override
        public void onProgressReturn(int arg0, int arg1) {
            FlyLog.d(TAG, "arg0:" + arg0 + ", arg1:" + arg1);
        }
    };

    /**
     * TTS相关回调
     */
    private TtsInitListener mTtsInitListener = new TtsInitListener() {

        @Override
        public void onTtsInited(boolean state, int errId) {

            if (state) {
                mSessionEntity = mTtsSessionManager.getTtsSession();
                mSessionEntity.sessionStart(mPlayerListener, AudioManager.STREAM_VOICE_CALL);
            } else {
                FlyLog.e(TAG, "onTtsInited | TTS error state: " + errId);
            }
        }
    };

    private Tts(Context context) {
        // Initialization the play control.
        FlyLog.d(TAG, "Tts | tts initialization");
        mContext = context;
        mTtsSessionManager = TtsSessionManager.getInstance();
        mManager = new AudioFocusManager(context);
    }

    public static synchronized void init(Context context) {
        if (mInstance == null) {
            FlyLog.d(TAG, "init | instance is null and init tts");
            mInstance = new Tts(context);
            mInstance.mTtsSessionManager.initClient(mInstance.mContext, mInstance.mTtsInitListener);
        }
    }

    public static void unInit() {
        if (mInstance != null) {

            mInstance.stop();
            mSessionEntity.sessionStop();
            mInstance.mTtsSessionManager.destroyClient();
        }
        mInstance = null;
    }

    public static Tts getInstance(Context context) {
        if (mInstance == null) {
//            throw new RuntimeException("TTS is not initialized!");
            init(context);
        }
        return mInstance;
    }

    /**
     * 将文本中的数字读成号码，[n1]标签是TTS将数字读取为号码，[n0]标签是恢复默认方式
     *
     * @param text play string
     * @return builder.toString()
     */
    public static String setTextToNumberPattern(String text) {
        if (null == text) {
            return null;
        }
        return TTS_SPEECH_PHONE_NUM_MODE + text + TTS_SPEECH_NORMAL_NUM_MODE;
    }

    /**
     * 将文本中的数字读成正常的数字模式，通过[n0]标签控制
     *
     * @param text play string
     * @return builder.toString()
     */
    public static String setTextToDigitalPattern(String text) {
        if (null == text) {
            return null;
        }
        //         .append(TtsConstant.TTS_SPEECH_NORMAL_NUM_MODE);
        return TTS_SPEECH_VALUE_NUM_MODE + text;
    }

    /**
     * 使用姓名标注规则，主要用于文本中存在人名的时候，使用[r1]标签控制
     *
     * @param text play string
     * @return builder.toString()
     */
    public static String setTextToNamePattern(String text) {
        if (null == text) {
            return null;
        }
        return TTS_SPEECH_NAME_FORCE_MODE + text + TTS_SPEECH_NAME_NORMAL_MODE;
    }

    /**
     * 使用韵律标注规则，主要用于文本中存在韵律标注的情况，通过[z1]标签控制
     *
     * @param text play string
     * @return builder.toString()
     */
    public static String setTextToRhythmPattern(String text) {
        if (null == text) {
            return null;
        }
        return TTS_SPEECH_OPEN_PROSODY + text + TTS_SPEECH_CLOSE_PROSODY;
    }

    /**
     * 使用提示音拼接规则，通过[x1]标签开启提示音
     *
     * @param text play string
     * @return builder.toString()
     */
    public static String setTextToReferPattern(String text) {
        if (null == text) {
            return null;
        }
        return TTS_SPEECH_OPEN_REFER + text + TTS_SPEECH_CLOSE_REFER;
    }

    /**
     * 不使用提示音拼接规则，通过[x0]标签关闭提示音，设置通用模式
     *
     * @param text play string
     * @return builder.toString()
     */
    public static String setTextToNormalPattern(String text) {
        if (null == text) {
            return null;
        }
        return TTS_SPEECH_CLOSE_REFER + text;
    }

    /**
     * 按字母发音
     *
     * @param text play string
     * @return builder.toString()
     */
    public static String setTextToLetterPattern(String text) {
        if (text == null) {
            return null;
        }
        return TTS_SPEECH_LETTER + text;
    }

    /**
     * 按单词发音
     *
     * @param text play string
     * @return builder.toString()
     */
    public static String setTextToWordPattern(String text) {
        if (text == null) {
            return null;
        }
        return TTS_SPEECH_WORD + text;
    }

    /**
     * 手机模式
     *
     * @param text play string
     * @return builder.toString()
     */
    public static String setTextToMobilePattern(String text) {
        if (text == null) {
            return null;
        }
        return TTS_SPEECH_MOBILE_MODE + text;
    }

    /**
     * 导航模式
     *
     * @param text play string
     * @return builder.toString()
     */
    public static String setTextToNavigatePattern(String text) {
        if (text == null) {
            return null;
        }
        return TTS_SPEECH_NAVIGATE_MODE + text;
    }

    /**
     * 普通模式
     *
     * @param text play string
     * @return builder.toString()
     */
    public static String setTextToGeneralPattern(String text) {
        if (text == null) {
            return null;
        }
        return TTS_SPEECH_NORMAL_MODE + text;
    }

    /**
     * 普通模式
     *
     * @param text play string
     * @return builder.toString()
     */
    public static String setTextToGeneral2NaviPattern(String text) {
        if (text == null) {
            return null;
        }
        return TTS_SPEECH_NORMAL_MODE + text + TTS_SPEECH_NAVIGATE_MODE;
    }

    public static String setTtsSpeed(String text, int level) {
        if (text == null) {
            return null;
        }
        return "[s" + level + "]" + text;
    }

    private static String setSpeaker(String text) {

        int speakerId = getprop("persist.sys.autofly.speaker", SPEAKER_SELF_DEFINED);

        return "[m" + speakerId + "]" + text;
    }

    private static int getprop(String key, int defaultValue) {
        int value = defaultValue;
        try {
            @SuppressLint("PrivateApi") Class<?> c = Class.forName("android.os.SystemProperties");
            Method get = c.getMethod("get", String.class, String.class);
            value = Integer.parseInt((String) (get.invoke(c, key, "unknown")));
        } catch (Exception e) {
            FlyLog.e(TAG, "getprop | get property error, " + e.getMessage());
        }
        return value;
    }

    public void requestFocus() {
        //主要解决背景有音乐的情况下，通过语音助理调用天气，中间不会出现音乐的声音。
        if (mManager != null) {
            mManager.requestAudioFocus(mFocusListener);
        }
    }

    public void abandonFocus() {
        //释放音频焦点
        if (mManager != null) {
            mManager.abandonAudioFocus(mFocusListener);
        }
    }

    public void play(String str) {
        if (str == null) {
            return;
        }
        FlyLog.v(TAG, "play | tts play");

        str = setSpeaker(str);
        mManager.requestAudioFocus(mFocusListener);
        if (mSessionEntity != null) {
            if (mIsPlaying) {
                FlyLog.d(TAG, "play | isPlaying, so stop first!");
                mSessionEntity.stopSpeak();
            }
            int ret = mSessionEntity.startSpeak(str);
            if (0 != ret) {
                mSessionEntity.sessionStart(mPlayerListener, AudioManager.STREAM_MUSIC);
            }
        } else {
            mManager.abandonAudioFocus(mFocusListener);
        }
    }

    /**
     * 延迟播放
     *
     * @param strTemp     play string
     * @param delayMillis delay time
     */
    public void postPlay(String strTemp, long delayMillis) {
        if (strTemp == null) {
            return;
        }
        FlyLog.v(TAG, "postPlay | tts postPlay");

        final String str = setSpeaker(strTemp);
        mManager.requestAudioFocus(mFocusListener);
        if (mIsPlaying) {
            FlyLog.d(TAG, "postPlay | isPlaying, so stop first!");
            mSessionEntity.stopSpeak();
        }
        mHandler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (mSessionEntity != null) {
                    int ret = mSessionEntity.startSpeak(str);
                    if (0 != ret) {
                        mSessionEntity.sessionStart(mPlayerListener, AudioManager.STREAM_VOICE_CALL);
                    }
                } else {
                    mManager.abandonAudioFocus(mFocusListener);
                }
            }
        }, delayMillis);
    }

    public void stop() {
        FlyLog.d(TAG, "stop | tts stop");
        if (null != mSessionEntity) {
            mSessionEntity.stopSpeak();
        }
        mManager.abandonAudioFocus(mFocusListener);
    }

    public void pause() {
        if (null != mSessionEntity) {
            mSessionEntity.pauseSpeak();
        }
    }

    public void resume() {
        if (null != mSessionEntity) {
            mSessionEntity.resumeSpeak();
        }
    }

    public boolean isPlaying() {
        return mIsPlaying;
    }
}
