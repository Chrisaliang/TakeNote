package com.uaes.android.data.json;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by Chrisaliang on 2017/11/23.
 * generate the general json for some query
 */

@SuppressWarnings("ALL")
public class GeneralAttributeSent {

    @SerializedName("attributeList")
    public List<GeneralAttribute> attributeList;

//    @SerializedName("vin")
//    public String vinCode;

    @Override
    public String toString() {
        return "GeneralAttributeSent{" +
                "attributeList=" + attributeList +
//                ", vinCode='" + vinCode + '\'' +
                '}';
    }

    public static class GeneralAttribute {

        @SerializedName("attributeType")
        public String attributeType;

        @SerializedName("attributeValue")
        public String attributeValue;

        @Override
        public String toString() {
            return "GeneralAttribute{" +
                    "attributeType='" + attributeType + '\'' +
                    ", attributeValue='" + attributeValue + '\'' +
                    '}';
        }
    }
}
