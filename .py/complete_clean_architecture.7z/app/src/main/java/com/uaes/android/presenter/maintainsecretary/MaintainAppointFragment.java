package com.uaes.android.presenter.maintainsecretary;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.databinding.MaintainFragmentAppointmentBinding;
import com.uaes.android.databinding.MaintainItemAppointmentBinding;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import timber.log.Timber;

/**
 * Created by ${GY} on 2018/5/10
 * des：
 */

public class MaintainAppointFragment extends MaintainBaseFragment implements MaintainOnClickListener {
    private static final String TAG = "MaintainAppoint_";

    private MaintainFragmentAppointmentBinding binding;
    private MaintainAppointViewModel maintainAppointViewModel;
    private MaintainAppointAdapter appointAdapter;
    @Inject
    ViewModelProvider.Factory factory;

    private Observer<List<MaintainAppointItem>> listObserver = new Observer<List<MaintainAppointItem>>() {
        @Override
        public void onChanged(@Nullable List<MaintainAppointItem> maintainHistoryItems) {
            appointAdapter.updateALL(maintainHistoryItems);
        }
    };

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        maintainAppointViewModel = ViewModelProviders.of(this, factory).get(MaintainAppointViewModel.class);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.maintain_fragment_appointment,
                container, false);
        binding.setLifecycleOwner(this);
        maintainAppointViewModel.getDataObserver().observe(this, listObserver);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding.setMaintainAppointViewModel(maintainAppointViewModel);
        binding.setMaintainOnClickListener(this);
        initAdapter();
    }


    private void initAdapter() {
        if (appointAdapter == null)
            appointAdapter = new MaintainAppointAdapter(maintainAppointViewModel, mNavigator);
        binding.rclAppoint.setLayoutManager(new LinearLayoutManager(getActivity()));
        binding.rclAppoint.setAdapter(appointAdapter);
    }

    @Override
    public void onStart() {
        super.onStart();
        maintainAppointViewModel.queryDriveSchemeData();
    }

    @Override
    public void onStop() {
        super.onStop();
        maintainAppointViewModel.unSubscribe();
    }

    @Override
    public void onClick(int type) {
        mNavigator.onBack();
    }

    private static class MaintainAppointAdapter extends RecyclerView.Adapter<MaintainAppointViewHolder> {
        private MaintainNavigator mNavigator;
        private MaintainAppointViewModel maintainAppointViewModel;
        private ArrayList<MaintainAppointItem> dataList;


        MaintainAppointAdapter(MaintainAppointViewModel maintainAppointViewModel, MaintainNavigator mNavigator) {
            dataList = new ArrayList<>();
            this.maintainAppointViewModel = maintainAppointViewModel;
            this.mNavigator = mNavigator;
        }

        @NonNull
        @Override
        public MaintainAppointViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            MaintainItemAppointmentBinding itembinding = DataBindingUtil.inflate(
                    LayoutInflater.from(parent.getContext()),
                    R.layout.maintain_item_appointment, parent,
                    false);
            return new MaintainAppointViewHolder(itembinding);
        }

        @Override
        public void onBindViewHolder(@NonNull MaintainAppointViewHolder holder, int position) {
            holder.bind(dataList.get(position), maintainAppointViewModel, mNavigator);
        }

        @Override
        public int getItemCount() {
            return dataList.size();
        }

        void updateALL(List<MaintainAppointItem> maintainAppointItems) {
            dataList.clear();
            dataList.addAll(maintainAppointItems);
            Timber.tag(TAG).d("dataList.size:%s", dataList.size());
            notifyDataSetChanged();
        }
    }

    private static class MaintainAppointViewHolder extends RecyclerView.ViewHolder {

        private MaintainItemAppointmentBinding itemBinding;

        MaintainAppointViewHolder(MaintainItemAppointmentBinding itemBinding) {
            super(itemBinding.getRoot());
            this.itemBinding = itemBinding;
        }

        void bind(MaintainAppointItem maintainAppointItem,
                  MaintainAppointViewModel maintainAppointViewModel,
                  MaintainNavigator mNavigator) {
            itemBinding.setMaintainAppointItem(maintainAppointItem);
            itemBinding.setMaintainAppointViewModel(maintainAppointViewModel);
            itemBinding.setNavigatorOnclickListener(mNavigator);
            itemBinding.executePendingBindings();
        }
    }
}
