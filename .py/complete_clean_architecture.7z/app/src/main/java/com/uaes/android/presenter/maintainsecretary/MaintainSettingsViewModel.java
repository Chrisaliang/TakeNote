package com.uaes.android.presenter.maintainsecretary;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.uaes.android.domain.MaintainRepository;
import com.uaes.android.domain.Result;
import com.uaes.android.domain.entity.DMMaintainSetting;
import com.uaes.android.domain.usecase.MaintainSettingQuery;
import com.uaes.android.domain.usecase.MaintainSettingUpdate;
import com.uaes.android.presenter.lifecycle.SingleLiveData;

import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

/**
 * Created by ${GY} on 2018/5/7
 * des：
 */
public class MaintainSettingsViewModel extends ViewModel implements MaintainSettingsOnClickListener {
    private static final String TAG = "MaintainSettingsViewMod";
    public final MutableLiveData<Boolean> isAllowPush = new MutableLiveData<>();
    public final MutableLiveData<Integer> selectedWhen = new MutableLiveData<>();
    public final MutableLiveData<Integer> selectedRate = new MutableLiveData<>();
    public final MutableLiveData<Boolean> onSaveStatus = new MutableLiveData<>();
    private final SingleLiveData<Boolean> saveStatus = new SingleLiveData<>();
    public final MutableLiveData<Boolean> showContent = new MutableLiveData<>();


    private Disposable d1;
    private Disposable d2;
    private MaintainSettingQuery maintainSettingQuery;
    private MaintainSettingUpdate maintainSettingUpdate;
    private DMMaintainSetting dmMaintainSetting = new DMMaintainSetting();

    public MaintainSettingsViewModel(MaintainSettingQuery maintainSettingQuery, MaintainSettingUpdate maintainSettingUpdate) {
        this.maintainSettingQuery = maintainSettingQuery;
        this.maintainSettingUpdate = maintainSettingUpdate;
    }

    @Override
    public void onClick(int type) {
        Timber.tag(TAG).w("MaintainSettingsViewModel onclick:%s", type);
        switch (type) {
            case 0:
                //200km/周
                selectedWhen.setValue(0);
                dmMaintainSetting.pushType = MaintainRepository.TYPE_PUSH_200KM;
                break;
            case 1:
                //500km/2周
                selectedWhen.setValue(1);
                dmMaintainSetting.pushType = MaintainRepository.TYPE_PUSH_500KM;
                break;
            case 2:
                //1000km/月
                selectedWhen.setValue(2);
                dmMaintainSetting.pushType = MaintainRepository.TYPE_PUSH_1000KM;
                break;
            case 3:
                //每50km
                selectedRate.setValue(0);
                dmMaintainSetting.pushFrequency = MaintainRepository.PUSH_FREQUENCY_EVERY_50KM;
                break;
            case 4:
                //每次驾驶
                selectedRate.setValue(1);
                dmMaintainSetting.pushFrequency = MaintainRepository.PUSH_FREQUENCY_EVERY_DRIVE;
                break;
            case 5:
                //每天一次
                selectedRate.setValue(2);
                dmMaintainSetting.pushFrequency = MaintainRepository.PUSH_FREQUENCY_EVERY_DAY;
                break;
            case 6:
                //每周一次
                selectedRate.setValue(3);
                dmMaintainSetting.pushFrequency = MaintainRepository.PUSH_FREQUENCY_EVERY_WEEK;
                break;
            case 7:
                updateSettings();
                break;
        }
    }

    @Override
    public void onCheckedChanged(boolean isChecked) {
        Timber.tag(TAG).w("MaintainSettingsViewModel isChecked:%s", isChecked);
        dmMaintainSetting.isAllowedPush = isChecked;
    }

    public void querySettings() {
        onSaveStatus.setValue(true);
        maintainSettingQuery.execute().subscribe(new SingleObserver<Result<DMMaintainSetting>>() {
            @Override
            public void onSubscribe(Disposable disposable) {
                if (d1 != null)
                    d1.dispose();
                d1 = disposable;
            }

            @Override
            public void onSuccess(Result<DMMaintainSetting> dmMaintainSettingResult) {
                Timber.tag(TAG).d(dmMaintainSettingResult.content.toString());
                initView(dmMaintainSettingResult.content);
            }

            @Override
            public void onError(Throwable throwable) {
                Timber.tag(TAG).e(throwable);
            }
        });
    }

    private void updateSettings() {
        Timber.tag(TAG).d("updateSettings:");
        onSaveStatus.setValue(true);
        maintainSettingUpdate.setSetting(dmMaintainSetting);
        maintainSettingUpdate.execute().subscribe(new SingleObserver<Result<Boolean>>() {
            @Override
            public void onSubscribe(Disposable disposable) {
                if (d2 != null)
                    d2.dispose();
                d2 = disposable;
            }

            @Override
            public void onSuccess(Result<Boolean> booleanResult) {
                Timber.tag(TAG).d("updateSettings:onSuccess:%s", booleanResult.content);
                saveStatus.setValue(booleanResult.content);
            }

            @Override
            public void onError(Throwable throwable) {
                Timber.tag(TAG).d(throwable, "updateSettings:onError:%s", throwable.getMessage());
                saveStatus.setValue(false);
            }
        });
    }

    public MutableLiveData<Boolean> getSaveStatus() {
        return saveStatus;
    }

    private void initView(DMMaintainSetting dmMaintainSetting) {
        isAllowPush.setValue(dmMaintainSetting.isAllowedPush);
        selectedWhen.setValue(dmMaintainSetting.pushType);
        selectedRate.setValue(dmMaintainSetting.pushFrequency);
        this.dmMaintainSetting.isAllowedPush = dmMaintainSetting.isAllowedPush;
        this.dmMaintainSetting.pushType = dmMaintainSetting.pushType;
        this.dmMaintainSetting.pushFrequency = dmMaintainSetting.pushFrequency;
        onSaveStatus.setValue(false);
        showContent.setValue(true);
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        unSubscribe();
    }

    public void unSubscribe() {
        if (d1 != null)
            d1.dispose();
        if (d2 != null)
            d2.dispose();
    }
}
