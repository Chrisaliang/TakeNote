package com.uaes.android.presenter.powerdefender.viewmodel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.databinding.ObservableArrayList;
import android.databinding.ObservableBoolean;
import android.databinding.ObservableField;
import android.databinding.ObservableInt;
import android.support.annotation.NonNull;
import android.text.TextUtils;

import com.uaes.android.R;
import com.uaes.android.domain.PowerDefenderRepository;
import com.uaes.android.domain.Result;
import com.uaes.android.domain.entity.DMPowerStatus;
import com.uaes.android.domain.usecase.PowerStatusQuery;
import com.uaes.android.presenter.powerdefender.pojo.CarIndicateEntity;

import java.util.List;
import java.util.Map;

import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

/**
 * Created by diaokaibin@gmail.com on 2018/5/8.
 */
public class CarStatusViewModel extends AndroidViewModel {

    private final String TAG = this.getClass().getSimpleName();

    public final ObservableField<String> status = new ObservableField<>();
    public final ObservableField<String> statusDes = new ObservableField<>();
    public final ObservableBoolean mObservableBoolean = new ObservableBoolean();

    public final ObservableInt mObservableScore = new ObservableInt();
    public final ObservableArrayList<CarIndicateEntity> mEntityObservableArrayList = new ObservableArrayList<>();

    private final PowerStatusQuery mPowerStatusQuery;

    private DMPowerStatus mPowerStatus;
    private Disposable disposable;


    public CarStatusViewModel(@NonNull Application application, PowerStatusQuery powerStatusQuery) {
        super(application);
        this.mPowerStatusQuery = powerStatusQuery;
    }

    public void doQuery() {
        mPowerStatusQuery.execute()
                .subscribe(new SingleObserver<Result<DMPowerStatus>>() {
                    @Override
                    public void onSubscribe(Disposable d) {
                        if (disposable != null)
                            disposable.dispose();
                        disposable = d;
                    }

                    @Override
                    public void onSuccess(Result<DMPowerStatus> status) {
                        Timber.tag(TAG).d(status.toString());
                        upData(status);
                        mPowerStatus = status.content;

                    }

                    @Override
                    public void onError(Throwable throwable) {
                        Timber.tag(TAG).d(throwable);
                    }
                });


    }

    private void upData(Result<DMPowerStatus> status) {
        if (status == null) return;
        DMPowerStatus dmPowerStatus = status.content;
        Map<String, DMPowerStatus.DMSystemPart> systemParts = dmPowerStatus.systemParts;

        // 优良中差
        int overallRating = dmPowerStatus.overallRating;
        if (overallRating == PowerDefenderRepository.OVERALL_RATING_EXCELLENT) {
            this.status.set(getApplication().getString(R.string.power_tv_title_excellent));
            this.statusDes.set(getApplication().getString(R.string.power_tv_message_excellent));
            this.mObservableBoolean.set(false);
            this.mObservableScore.set(1);

        } else if (overallRating == PowerDefenderRepository.OVERALL_RATING_GOOD) {

            this.status.set(getApplication().getString(R.string.power_tv_title_good));
            this.statusDes.set(getApplication().getString(R.string.power_tv_message_good));
            this.mObservableBoolean.set(false);
            this.mObservableScore.set(2);

        } else if (overallRating == PowerDefenderRepository.OVERALL_RATING_QUALIFIED) {

            this.statusDes.set(getApplication().getString(R.string.power_tv_message_middle));
            this.status.set(getApplication().getString(R.string.power_tv_title_middle));
            this.mObservableBoolean.set(true);
            this.mObservableScore.set(3);

        } else if (overallRating == PowerDefenderRepository.OVERALL_RATING_POOR) {

            this.statusDes.set(getApplication().getString(R.string.power_tv_message_bad));
            this.status.set(getApplication().getString(R.string.power_tv_title_bad));
            this.mObservableBoolean.set(true);
            this.mObservableScore.set(4);
        }

        for (int i = 0; i < 8; i++) {
            mEntityObservableArrayList.add(null);
        }
        if (systemParts == null) return;
        for (Map.Entry<String, DMPowerStatus.DMSystemPart> entry : systemParts.entrySet()) {
            CarIndicateEntity carIndicateEntity = new CarIndicateEntity();
            if (entry == null) return;
            DMPowerStatus.DMSystemPart value = entry.getValue();
            int errorCode = value.errorCode;
            if (errorCode == PowerDefenderRepository.ERROR_CODE_OK) {
                carIndicateEntity.carIndicateStatus = PowerDefenderRepository.ERROR_CODE_OK;
            } else if (errorCode == PowerDefenderRepository.ERROR_CODE_WARN) {
                carIndicateEntity.carIndicateStatus = PowerDefenderRepository.ERROR_CODE_WARN;
            } else if (errorCode == PowerDefenderRepository.ERROR_CODE_ERROR) {
                carIndicateEntity.carIndicateStatus = PowerDefenderRepository.ERROR_CODE_ERROR;
            }
            int errorCount = value.errorsNum;
//            int errorCount = value.getErrorCount();
            carIndicateEntity.faultCount = errorCount + getApplication().getString(R.string.power_tv_fault);
            String entryKey = entry.getKey();

            int index = 0;
            if (TextUtils.equals(entryKey, DMPowerStatus.KEY_CODE_LUBRICATION_SYSTEM)) {  // 润滑系统
                index = 0;
            } else if (TextUtils.equals(entryKey, DMPowerStatus.KEY_CODE_AIR_SYSTEM)) {    // 空气系统
                index = 1;

            } else if (TextUtils.equals(entryKey, DMPowerStatus.KEY_CODE_IGNITION_SYSTEM)) {  // 点火系统
                index = 2;

            } else if (TextUtils.equals(entryKey, DMPowerStatus.KEY_CODE_POWER_SUPPLY_SYSTEM)) { // 供电系统
                index = 3;

            } else if (TextUtils.equals(entryKey, DMPowerStatus.KEY_CODE_FUEL_SUPPLY_SYSTEM)) { // 供油系统
                index = 4;

            } else if (TextUtils.equals(entryKey, DMPowerStatus.KEY_CODE_OPERATION_SYSTEM)) { // 操作系统
                index = 5;

            } else if (TextUtils.equals(entryKey, DMPowerStatus.KEY_CODE_THERMAL_MANAGEMENT_SYSTEM)) { // 热管理系统
                index = 6;

            } else if (TextUtils.equals(entryKey, DMPowerStatus.KEY_CODE_EXHAUST_SYSTEM)) {  // 排气系统
                index = 7;
            }
            carIndicateEntity.index = index;
            mEntityObservableArrayList.set(index, carIndicateEntity);
        }


    }

    public List<DMPowerStatus.DMSystemPartError> getDMSPartErrors(String key) {
        if (mPowerStatus != null) {
            if (mPowerStatus.systemParts.containsKey(key)) {
                return mPowerStatus.systemParts.get(key).getErrors();
            }
        }
        return null;
    }

    public void cancleQuery() {
        if (disposable != null)
            disposable.dispose();
    }

}
