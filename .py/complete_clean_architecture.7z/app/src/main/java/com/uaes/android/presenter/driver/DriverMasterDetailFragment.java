package com.uaes.android.presenter.driver;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.amap.api.maps.model.LatLng;
import com.uaes.android.BR;
import com.uaes.android.R;
import com.uaes.android.databinding.DriverMasterFragmentDetailBinding;
import com.uaes.android.databinding.DriverMasterItemDriveDetailBinding;
import com.uaes.android.presenter.BaseFragment;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.inject.Inject;

import timber.log.Timber;

public class DriverMasterDetailFragment extends BaseFragment implements BackListener {

    public static final String FRAGMENT_TYPE = "com.uaes.android.presenter.driver.fragment.type";
    public static final String EXEC_TYPE = "com.uaes.android.presenter.driver.fragment.exec.type";
    private static final String TAG = "DriverManagerDetailFrag";
    DriverMasterFragmentDetailBinding binding;
    @Inject
    ViewModelProvider.Factory factory;
    DriverMasterDetailViewModel viewModel;
    private DetailAdapter adapter;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState == null) {
            adapter = new DetailAdapter();
        }
        viewModel = ViewModelProviders.of(this, factory).get(DriverMasterDetailViewModel.class);
    }

    @Override
    public void popupBack() {
        ((DriverMasterFragment) Objects.requireNonNull(getParentFragment())).backPreviewLevel();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater,
                R.layout.driver_master_fragment_detail, container, false);
        binding.setLifecycleOwner(this);
//        binding.setBackListener(this);
        binding.setVariable(BR.backListener, this);
        viewModel.items.observe(this, new Observer<List<DriverMasterDetailItem>>() {
            @Override
            public void onChanged(@Nullable List<DriverMasterDetailItem> items) {
                adapter.updateAll(items);
            }
        });
        binding.setDetail(viewModel);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        Bundle args = getArguments();
        if (args == null) {
            Timber.tag(TAG).d("onCreate:fragment 类型错误");
            Toast.makeText(getActivity(), "Fragment 类型错误！", Toast.LENGTH_SHORT).show();
            popupBack();
            return;
        }
        String[] titleArr = getResources().getStringArray(R.array.driver_master_detail_title_arr);

        int fragmentType = args.getInt(FRAGMENT_TYPE);
        int execType = args.getInt(EXEC_TYPE);

        viewModel.title.setValue(titleArr[fragmentType]);
        viewModel.setQueryType(fragmentType + 1);
        viewModel.setExecType(execType);

        binding.rvList.setLayoutManager(new LinearLayoutManager(getActivity()));
        binding.rvList.addItemDecoration(
                new DividerItemDecoration(Objects.requireNonNull(getActivity()),
                        DividerItemDecoration.VERTICAL));
        binding.rvList.setAdapter(adapter);
    }

    @Override
    public void onStart() {
        super.onStart();

        viewModel.updateItem();
    }

    private void showMap(LatLng[] value) {
        Fragment fragment = new MapFragment();
        Bundle bundle = new Bundle();
        bundle.putParcelableArray(MapFragment.MAP_LOCATION_ARGS, value);
        fragment.setArguments(bundle);
        Objects.requireNonNull(getParentFragment())
                .getChildFragmentManager()
                .beginTransaction()
                .replace(R.id.driverManagerLayoutContent, fragment)
                .addToBackStack(TAG)
                .commit();
    }

    class DriverDetailViewHolder extends RecyclerView.ViewHolder implements DetailItemClickListener {

        private final DriverMasterItemDriveDetailBinding itemBinding;

        DriverDetailViewHolder(DriverMasterItemDriveDetailBinding itemView) {
            super(itemView.getRoot());
            itemBinding = itemView;
            itemBinding.setLocation(this);
        }

        void bind(DriverMasterDetailItem item) {
            itemBinding.setItem(item);
        }

        @Override
        public void onLocation(LatLng[] value) {
            showMap(value);
        }
    }

    private class DetailAdapter extends RecyclerView.Adapter<DriverDetailViewHolder> {

        private List<DriverMasterDetailItem> data = new ArrayList<>(0);

        @NonNull
        @Override
        public DriverDetailViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            DriverMasterItemDriveDetailBinding itemView = DataBindingUtil.inflate(
                    LayoutInflater.from(parent.getContext()),
                    R.layout.driver_master_item_drive_detail, parent, false);
            return new DriverDetailViewHolder(itemView);
        }

        @Override
        public void onBindViewHolder(@NonNull DriverDetailViewHolder holder, int position) {
            holder.bind(data.get(position));
        }

        @Override
        public int getItemCount() {
            return data.size();
        }

        public void updateAll(List<DriverMasterDetailItem> items) {
            data.clear();
            data.addAll(items);
            notifyDataSetChanged();
        }
    }


}
