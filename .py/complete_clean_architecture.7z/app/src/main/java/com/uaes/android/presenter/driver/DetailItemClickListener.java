package com.uaes.android.presenter.driver;

import com.amap.api.maps.model.LatLng;

public interface DetailItemClickListener {

    /**
     * 将地图点传入地图界面
     *
     * @param value 地图定位点
     */
    void onLocation(LatLng[] value);
}
