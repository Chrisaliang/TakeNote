package com.uaes.android.presenter.driver;

import android.databinding.BindingAdapter;
import android.databinding.BindingMethod;
import android.databinding.BindingMethods;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.LayerDrawable;
import android.support.annotation.DrawableRes;
import android.widget.ImageView;
import android.widget.RatingBar;

@BindingMethods({
        @BindingMethod(type = ImageView.class, attribute = "imageSrc", method = "setSrc"),
        @BindingMethod(type = RatingBar.class, attribute = "ratingTint", method = "setTintRating")
})
public class BindAdapter {

    @BindingAdapter(value = "imageSrc")
    public static void setSrc(ImageView view, @DrawableRes int src) {
        view.setImageResource(src);
    }

    @BindingAdapter(value = "ratingTint")
    public static void setTintRating(RatingBar ratingBar, int rating) {
        ratingBar.setRating(rating);
        ratingBar.setNumStars(5);
//        if (rating <= 2) {
//            ratingBar.setProgressDrawable(ratingBar.getResources()
//                    .getDrawable(R.drawable.driver_master_rating_small_blue));
//            ratingBar.setIndeterminateDrawable(ratingBar.getResources()
//                    .getDrawable(R.drawable.driver_master_rating_small_blue));
//        } else if (rating <= 4) {
//            ratingBar.setProgressDrawable(ratingBar.getResources()
//                    .getDrawable(R.drawable.driver_master_rating_small_yellow));
//            ratingBar.setIndeterminateDrawable(ratingBar.getResources()
//                    .getDrawable(R.drawable.driver_master_rating_small_yellow));
//        } else {
//            ratingBar.setProgressDrawable(ratingBar.getResources()
//                    .getDrawable(R.drawable.driver_master_rating_small_red));
//        }

        int ratingColor;
        if (2 >= rating) {
            ratingColor = Color.parseColor("#0299e8");
        } else if (4 >= rating) {
            ratingColor = Color.parseColor("#f39800");
        } else {
            ratingColor = Color.RED;
        }

        LayerDrawable progressDrawable = (LayerDrawable) ratingBar.getProgressDrawable();
        progressDrawable.getDrawable(2).setColorFilter(ratingColor, PorterDuff.Mode.MULTIPLY);
//        for (int i = 1; i < progressDrawable.getNumberOfLayers(); i++) {
//            Drawable drawable = progressDrawable.getDrawable(i);
//            drawable.setColorFilter(Color.RED, PorterDuff.Mode.DST_IN);
////            DrawableCompat.setTint(drawable, Color.WHITE);
//        }

    }
}
