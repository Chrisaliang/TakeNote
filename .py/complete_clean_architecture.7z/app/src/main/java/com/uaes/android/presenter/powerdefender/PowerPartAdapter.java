package com.uaes.android.presenter.powerdefender;

import android.databinding.DataBindingUtil;
import android.databinding.ViewDataBinding;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.uaes.android.BR;
import com.uaes.android.R;
import com.uaes.android.presenter.powerdefender.pojo.PowerPart;
import com.uaes.android.presenter.powerdefender.viewholder.HistoryFaultBase;
import com.uaes.android.presenter.powerdefender.viewholder.HistoryFaultContent;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Created by diaokaibin@gmail.com on 2018/5/11.
 */
public class PowerPartAdapter extends RecyclerView.Adapter<HistoryFaultBase> {


    private List<PowerPart> dataSets;

    PowerPartAdapter() {
        dataSets = new ArrayList<>();

    }

    @NonNull
    @Override
    public HistoryFaultBase onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        ViewDataBinding binding = DataBindingUtil.inflate(inflater,
                R.layout.item_power_part, parent, false);
        return new HistoryFaultContent(binding);


    }

    @Override
    public void onBindViewHolder(@NonNull HistoryFaultBase holder, int position) {
        if (holder instanceof HistoryFaultContent) {
            holder.getBinding().setVariable(BR.powerPart, dataSets.get(position));
            holder.getBinding().executePendingBindings();
        }
    }

    @Override
    public int getItemViewType(int position) {
        return position;
    }

    @Override
    public int getItemCount() {
        return dataSets.size();
    }

    // operator
    public void appendAll(Collection<PowerPart> collection) {
        dataSets.addAll(collection);
        notifyDataSetChanged();
    }

    public void replaceAll(Collection<PowerPart> collection) {
        dataSets.clear();
        dataSets.addAll(collection);
        notifyDataSetChanged();
    }
}
