package com.uaes.android.domain.entity;

public class DMDriverMasterPage {

    // 急加速
    public int acuteAcc;

    // 急刹车
    public int acuteBreak;

    // 急转弯
    public int acuteTurn;

    // 连续加减速
    public int continueAccAndDec;

    // 夜间驾驶
    public int nightDriver;

    // 页面状态 提示
    public String titleSum;

    // 页面状态 提示 描述
    public String titleDsc;

    public static DMDriverMasterPage empty() {
        DMDriverMasterPage dmDriverMasterPage = new DMDriverMasterPage();
        dmDriverMasterPage.titleDsc = "";
        dmDriverMasterPage.titleSum = "";
//        dmDriverMasterPage.acuteAcc = 0;
//        dmDriverMasterPage.acuteBreak = 0;
//        dmDriverMasterPage.acuteTurn = 0;
//        dmDriverMasterPage.continueAccAndDec = 0;
//        dmDriverMasterPage.nightDriver = 0;
        return dmDriverMasterPage;
    }
}
