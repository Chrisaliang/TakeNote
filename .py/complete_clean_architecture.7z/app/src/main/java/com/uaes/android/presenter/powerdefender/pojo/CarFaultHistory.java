package com.uaes.android.presenter.powerdefender.pojo;

/**
 * Created by diaokaibin@gmail.com on 2018/5/9.
 */
public class CarFaultHistory {

    public String faultTitle;
    public String faultStartTime;
    public String faultStatus;
    public String faultSolutionTime;


    public CarFaultHistory(String faultTitle, String faultStartTime, String faultStatus, String faultSolutionTime) {
        this.faultTitle = faultTitle;
        this.faultStartTime = faultStartTime;
        this.faultStatus = faultStatus;
        this.faultSolutionTime = faultSolutionTime;
    }
}
