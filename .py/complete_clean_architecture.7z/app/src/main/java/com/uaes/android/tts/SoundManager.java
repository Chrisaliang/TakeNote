package com.uaes.android.tts;

import android.content.Context;
import android.media.AudioManager;
import android.media.SoundPool;

import com.uaes.android.R;

/**
 * 播放提示音
 *
 * @author zliang
 */
@Deprecated
class SoundManager {

    // 提示音信息
    private static final int TONE_RATING = 0;
    private static final int MAX_TONES_NUM = 1;
    // configure parameter
    //左音量比例
    private static final float LEFT_VOLUME_RATE = 2f;
    //右音量比例
    private static final float RIGHT_VOLUME_RATE = 2f;
    //播放速度比例
    private static final float PLAY_RATE = 1;
    //循环次数
    private static final int LOOP_TIMES = 0;
    private static SoundManager mInstance;
    private int[] mSoundID = new int[MAX_TONES_NUM];

    private SoundPool mSoundPool;

    private SoundManager(Context context) {
        mSoundPool = new SoundPool(MAX_TONES_NUM, AudioManager.STREAM_MUSIC, 0);
        mSoundID[TONE_RATING] = mSoundPool.load(context, R.raw.tone_retate_ogg, 1);
    }

    static SoundManager getInstance(Context context) {
        if (mInstance == null) {
            mInstance = new SoundManager(context);
        }
        return mInstance;
    }

    /**
     * 播放提示音
     *
     * @param toneType TONE_RATING
     */
    void playSound(int toneType) {
        if ((toneType < 0) || (toneType >= MAX_TONES_NUM)) {
            throw new IllegalArgumentException();
        }

        mSoundPool.play(mSoundID[toneType], LEFT_VOLUME_RATE, RIGHT_VOLUME_RATE,
                0, LOOP_TIMES, PLAY_RATE);
    }

}
