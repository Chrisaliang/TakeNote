package com.uaes.android.presenter.lifecycle;

import android.arch.lifecycle.Observer;
import android.support.annotation.Nullable;

public class EventObserver<T> implements Observer<Event<T>> {

    private EventHandler<T> handler;

    public EventObserver(EventHandler<T> handler) {
        this.handler = handler;
    }

    @Override
    public void onChanged(@Nullable Event<T> event) {
        if (event != null && event.getContentIfNotHandled() != null) {
            handler.handleEvent(event.getContentIfNotHandled());
        }

    }

    public interface EventHandler<T> {
        void handleEvent(T content);
    }
}
