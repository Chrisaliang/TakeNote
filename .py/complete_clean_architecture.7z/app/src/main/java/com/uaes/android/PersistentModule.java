package com.uaes.android;

import android.arch.persistence.room.Room;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.uaes.android.data.room.CacheDao;
import com.uaes.android.data.room.UaesDatabase;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

/**
 * Persistence module
 * */
@Module
abstract class PersistentModule {

    private static final String DB_NAME = "uaes.db";

    @Singleton @Provides
    public static SharedPreferences provideSharedPreferences(App app) {
        return PreferenceManager.getDefaultSharedPreferences(app);
    }

    @Singleton
    @Provides
    public static UaesDatabase provideDatabase(App app) {
        return Room.databaseBuilder(app, UaesDatabase.class, DB_NAME)
                .build();
    }

    @Singleton
    @Provides
    public static CacheDao provideCacheDao(UaesDatabase database) {
        return database.getCacheDao();
    }
}
