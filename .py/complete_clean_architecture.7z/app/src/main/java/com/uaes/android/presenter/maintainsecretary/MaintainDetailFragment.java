package com.uaes.android.presenter.maintainsecretary;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.databinding.MaintainFragmentDetailBinding;
import com.uaes.android.databinding.MaintainItemAdviceDetailsBinding;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import timber.log.Timber;

/**
 * Created by ${GY} on 2018/5/7
 * des：
 */
public class MaintainDetailFragment extends MaintainBaseFragment {

    private MaintainFragmentDetailBinding binding;
    private static final String TAG = "MaintainDetailFragment_";
    private MaintainDetailViewModel maintainDetailViewModel;
    private MaintainDetailsAdapter maintainDetailsAdapter;

    @Inject
    ViewModelProvider.Factory factory;

    private Observer<List<MaintainDetailItem>> listData = new Observer<List<MaintainDetailItem>>() {
        @Override
        public void onChanged(@Nullable List<MaintainDetailItem> maintainDetailItems) {
            if (maintainDetailItems != null) {
                Timber.tag(TAG).d("maintainDetailItems size:" + maintainDetailItems.size() + ",checkedPosition:" + maintainDetailsAdapter.checkedPosition);
            }
            maintainDetailsAdapter.updateData(maintainDetailItems);
            maintainDetailsAdapter.selectItemAt(maintainDetailsAdapter.checkedPosition);
        }
    };


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        maintainDetailViewModel = ViewModelProviders.of(this, factory).get(MaintainDetailViewModel.class);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.maintain_fragment_detail, container, false);
        binding.setLifecycleOwner(this);
        maintainDetailViewModel.getMessageItems().observe(this, listData);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Timber.tag(TAG).d("savedInstanceState :%s", savedInstanceState);
        binding.setNavigator(mNavigator);
        binding.setViewModel(maintainDetailViewModel);
        initAdapter();
    }

    private void initAdapter() {
        Timber.tag(TAG).d("initAdapter maintainDetailsAdapter :%s", maintainDetailsAdapter);
        if (maintainDetailsAdapter == null)
            maintainDetailsAdapter = new MaintainDetailsAdapter(mNavigator);
        binding.lvAdviceMaintainDetailList.setLayoutManager(new LinearLayoutManager(getActivity()));
        binding.lvAdviceMaintainDetailList.setHasFixedSize(true);
        binding.lvAdviceMaintainDetailList.setAdapter(maintainDetailsAdapter);
    }

    @Override
    public void onStart() {
        super.onStart();
        maintainDetailViewModel.queryMaintainStatus();
    }

    @Override
    public void onStop() {
        super.onStop();
        maintainDetailViewModel.unSubscribe();
    }

    private static class MaintainDetailsAdapter extends RecyclerView.Adapter<MaintainDetailViewHolder> {
        private MaintainNavigator mNavigator;
        private List<MaintainDetailItem> dataList;
        private int checkedPosition;

        MaintainDetailsAdapter(MaintainNavigator mNavigator) {
            dataList = new ArrayList<>();
            this.mNavigator = mNavigator;
        }

        @NonNull
        @Override
        public MaintainDetailViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            MaintainItemAdviceDetailsBinding itemBinding = DataBindingUtil
                    .inflate(LayoutInflater.from(parent.getContext()),
                            R.layout.maintain_item_advice_details, parent, false);
            return new MaintainDetailViewHolder(itemBinding, mNavigator, this);
        }

        @Override
        public void onBindViewHolder(@NonNull MaintainDetailViewHolder holder, int position) {
            holder.bind(dataList.get(position));
        }

        @Override
        public int getItemCount() {
            return dataList.size();
        }

        void selectItemAt(int position) {
            if (dataList.size() == 0) {
                checkedPosition = 0;
                return;
            }
            if (position >= dataList.size()) {
                checkedPosition = position = 0;
            }
            checkedPosition = position;
            for (int i = 0; i < dataList.size(); i++) {
                if (i == position) {
                    dataList.get(position).isChoice = true;
                } else {
                    dataList.get(i).isChoice = false;
                }
            }
            notifyDataSetChanged();
        }

        void updateData(List<MaintainDetailItem> maintainDetailItems) {
            dataList.clear();
            dataList.addAll(maintainDetailItems);
            notifyDataSetChanged();
        }
    }

    private static class MaintainDetailViewHolder extends RecyclerView.ViewHolder implements MaintainItemOnClickListener {
        private MaintainItemAdviceDetailsBinding itemBinding;
        private MaintainDetailItem item;
        private MaintainNavigator mNavigator;
        private MaintainDetailsAdapter maintainDetailsAdapter;

        MaintainDetailViewHolder(MaintainItemAdviceDetailsBinding itemBinding, MaintainNavigator mNavigator, MaintainDetailsAdapter maintainDetailsAdapter) {
            super(itemBinding.getRoot());
            this.itemBinding = itemBinding;
            this.mNavigator = mNavigator;
            this.maintainDetailsAdapter = maintainDetailsAdapter;
        }

        void bind(MaintainDetailItem maintainDetailItem) {
            item = maintainDetailItem;
            itemBinding.setItem(item);
            itemBinding.setListener(this);
            itemBinding.executePendingBindings();
        }

        @Override
        public void onClick(int code, int position) {
            Timber.tag(TAG).d(":showTips:" + position + ",ischoice:" + item.isChoice);
            if (!item.isChoice) {
                maintainDetailsAdapter.selectItemAt(position);
            }
            mNavigator.showMaintainContentDetail(code);
        }
    }

}
