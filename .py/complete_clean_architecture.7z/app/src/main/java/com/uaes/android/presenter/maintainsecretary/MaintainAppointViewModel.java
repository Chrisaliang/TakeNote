package com.uaes.android.presenter.maintainsecretary;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;
import android.os.Bundle;

import com.uaes.android.domain.Result;
import com.uaes.android.domain.entity.DM4SShop;
import com.uaes.android.domain.entity.DMLocation;
import com.uaes.android.domain.usecase.S4ShopListQuery;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

/**
 * Created by ${GY} on 2018/5/10
 * des：
 */
public class MaintainAppointViewModel extends ViewModel {
    private static final String TAG = "MaintainAppointViewMode";
    private final MutableLiveData<List<MaintainAppointItem>> dataObserver = new MutableLiveData<>();
    private double currentLongitude;
    private double currentLatitude;
    private S4ShopListQuery s4ShopListQuery;
    private Disposable d;
    private List<MaintainAppointItem> dataList;
    private String currentAddress;

    public MaintainAppointViewModel(S4ShopListQuery s4ShopListQuery) {
        this.s4ShopListQuery = s4ShopListQuery;
    }

    public void queryDriveSchemeData() {
        Timber.tag(TAG).d("queryDriveSchemeData:");
        s4ShopListQuery.execute().subscribe(new SingleObserver<Result<List<DM4SShop>>>() {
            @Override
            public void onSubscribe(Disposable disposable) {
                if (d != null) {
                    d.dispose();
                }
                d = disposable;
            }

            @Override
            public void onSuccess(Result<List<DM4SShop>> listResult) {
                Timber.tag(TAG).d("queryDriveSchemeData onSuccess:size:%s", listResult.content.size());
                updateView(listResult.content);
            }

            @Override
            public void onError(Throwable throwable) {
                Timber.tag(TAG).e(throwable, "onError:%s", throwable.toString());
            }
        });
    }

    private void updateView(List<DM4SShop> content) {
        dataList = new ArrayList<>();
        DMLocation location = s4ShopListQuery.getLocation();
        if (location != null) {
            currentLatitude = location.latitude;
            currentLongitude = location.longitude;
            currentAddress = location.address;
            Timber.tag(TAG).w("currentLatitude:" + currentLatitude + ",currentLongitude:" + currentLongitude);
        }
        for (int i = 0; i < content.size(); i++) {
            MaintainAppointItem maintainAppointItem = new MaintainAppointItem();
            maintainAppointItem.position = i;
            maintainAppointItem.maintainAddress = content.get(i).name;
            maintainAppointItem.maintainPhone = content.get(i).phone;
            maintainAppointItem.latitude = content.get(i).latitude;
            maintainAppointItem.longitude = content.get(i).longitude;
            dataList.add(maintainAppointItem);
        }
        dataObserver.setValue(dataList);
    }

    public MutableLiveData<List<MaintainAppointItem>> getDataObserver() {
        return dataObserver;
    }

    public Bundle getDriveSchemeBundle(int position) {
        Bundle bundle = new Bundle();
        bundle.putString(MaintainConstant.MAINTAIN_CURRENT_ADDRESS, currentAddress);
        bundle.putDouble(MaintainConstant.MAINTAIN_CURRENT_LONGITUDE, currentLongitude);
        bundle.putDouble(MaintainConstant.MAINTAIN_CURRENT_LATITUDE, currentLatitude);
        bundle.putString(MaintainConstant.MAINTAIN_ADDRESS, dataList.get(position).maintainAddress);
        bundle.putDouble(MaintainConstant.MAINTAIN_LONGITUDE, dataList.get(position).longitude);
        bundle.putDouble(MaintainConstant.MAINTAIN_LATITUDE, dataList.get(position).latitude);
        return bundle;
    }

    public void unSubscribe() {
        if (d != null)
            d.dispose();
    }

}
