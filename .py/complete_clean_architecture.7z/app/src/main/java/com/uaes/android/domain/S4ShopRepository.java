package com.uaes.android.domain;

import android.support.annotation.Nullable;

import com.uaes.android.domain.entity.DM4SShop;

import java.util.List;

public interface S4ShopRepository {

    /**
     * 查询4S店
     * @param province 省份名成 中文
     * @param latitude 查询目标地的纬度
     * @param longitude 查询目标地的经度
     */
    @Nullable
    List<DM4SShop> queryList(String province, double latitude, double longitude) throws Exception;

}
