package com.uaes.android.presenter.powerdefender.pojo;

import com.uaes.android.domain.entity.DM4SShop;
import com.uaes.android.domain.entity.DMLocation;

import java.util.List;

/**
 * Created by diaokaibin@gmail.com on 2018/5/16.
 */
public class CarLocation {

    public DMLocation mLocation;
    public List<DM4SShop> mShopList;
}
