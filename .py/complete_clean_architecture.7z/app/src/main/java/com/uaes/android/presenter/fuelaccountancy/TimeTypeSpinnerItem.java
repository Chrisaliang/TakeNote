package com.uaes.android.presenter.fuelaccountancy;

/**
 * @author qingxin.chen
 * Created by qingxin.chen on 2018/5/15.
 */
public class TimeTypeSpinnerItem {

    public ItemType itemType;
    public String textShown;

    TimeTypeSpinnerItem(ItemType itemType, String text) {
        this.textShown = text;
        this.itemType = itemType;
    }

    public enum ItemType {
        MAINITEM, LISTFIRST, LISTOTHER
    }

}
