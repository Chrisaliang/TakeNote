package com.uaes.android.data.mapper;

import com.uaes.android.data.json.MessageMqttJson;
import com.uaes.android.data.room.MessageCenterEntity;
import com.uaes.android.domain.entity.DMMessageCenterItem;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MessageCenterMapper {

    private static final String TARGET_PATTERN = "yyyy-MM-dd HH:mm";
    private SimpleDateFormat sdf;

    public DMMessageCenterItem mapper(MessageCenterEntity entity) {
        DMMessageCenterItem item = new DMMessageCenterItem();
        item.id = entity.id;
        item.msgTime = entity.msgTime;
        item.msgContent = entity.msgContent;
        return item;
    }

    public List<DMMessageCenterItem> mapper(MessageCenterEntity... entities) {
        List<DMMessageCenterItem> items = new ArrayList<>(entities.length * 5 / 3);
        for (MessageCenterEntity entity : entities) {
            items.add(mapper(entity));
        }
        return items;
    }

    public MessageCenterEntity[] mapper(DMMessageCenterItem... items) {
        MessageCenterEntity[] entities = new MessageCenterEntity[items.length];
        for (int i = 0; i < items.length; i++) {
            entities[i] = mapper(items[i]);
        }
        return entities;
    }

    private MessageCenterEntity mapper(DMMessageCenterItem item) {
        MessageCenterEntity entity = new MessageCenterEntity();
        entity.id = item.id;
        entity.msgTime = item.msgTime;
        entity.msgContent = item.msgContent;
        return entity;
    }

    public MessageCenterEntity mapper(MessageMqttJson mqttJson) {
        MessageCenterEntity entity = new MessageCenterEntity();
        entity.msgContent = mqttJson.textContent;
        entity.title = mqttJson.msgTitle;
        entity.msgTime = parseDate(mqttJson.msgTime);
        switch (mqttJson.msgType) {
            case 0:
                entity.msgType = MessageCenterEntity.MESSAGE_TYPE_NOTIFICATION;
                break;
            case 1:
                entity.msgType = MessageCenterEntity.MESSAGE_TYPE_WARNING;
                break;
            case 2:
                entity.msgType = MessageCenterEntity.MESSAGE_TYPE_MALFUNCTION;
                break;
            default:
                entity.msgType = MessageCenterEntity.MESSAGE_TYPE_NOTIFICATION;
                break;
        }

        return entity;
    }

    private String parseDate(long timeStamp) {
        if (sdf == null) sdf = new SimpleDateFormat(TARGET_PATTERN, Locale.CHINA);
        return sdf.format(new Date(timeStamp));
    }

}
