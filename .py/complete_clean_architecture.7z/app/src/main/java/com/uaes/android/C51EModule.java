package com.uaes.android;

import com.uaes.android.common.CarInfoProvider;
import com.uaes.android.common.VinProvider;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

@Module
class C51EModule {

    @Provides
    @Singleton
    static CarInfoProvider provider(App app) {
        return new VinProvider();
    }
}
