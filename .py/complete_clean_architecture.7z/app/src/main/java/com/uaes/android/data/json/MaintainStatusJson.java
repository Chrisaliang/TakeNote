package com.uaes.android.data.json;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * 当前车况保养状态
 * <p>
 * {
 * "msgCode": "10000",
 * "msg": "OK",
 * "content": {
 * "list": ["发动机机油","机油滤清器"],
 * "remainder": {
 * "dataKey": "day",
 * "dataValue": "10"
 * }
 * },
 * "status": 1,
 * "total": 2
 * }
 */
public class MaintainStatusJson {

    /**
     * 剩余保养的值，天数 或者里程 KM
     */
    @SerializedName("remainder")
    public MaintainStatusReminderJson statusReminder;
    /**
     * 推荐保养清单
     */
    @SerializedName("list")
    public List<MaintainContentItemJson> maintainList;

}
