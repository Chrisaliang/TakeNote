package com.uaes.android.domain.usecase;

import com.uaes.android.domain.DriverMasterRepository;
import com.uaes.android.domain.JobThread;
import com.uaes.android.domain.SingleUseCase;
import com.uaes.android.domain.entity.DMDriverMasterPage;

import io.reactivex.Single;
import io.reactivex.functions.Function;

public class DriverMasterQuery extends SingleUseCase<DMDriverMasterPage> {

    private static final int DEFAULT_QUERY_TYPE = 1;

    private int queryType = DEFAULT_QUERY_TYPE;


    private DriverMasterRepository repository;
    private JobThread jobThread;


    public DriverMasterQuery(DriverMasterRepository repository, JobThread jobThread) {
        this.repository = repository;
        this.jobThread = jobThread;
    }

    public void setQueryType(int queryType) {
        this.queryType = queryType;
    }

    @Override
    protected Single<DMDriverMasterPage> buildSingle() {
        return Single.just(repository)
                .map(new Function<DriverMasterRepository, DMDriverMasterPage>() {
                    @Override
                    public DMDriverMasterPage apply(DriverMasterRepository repository) throws Exception {
                        return repository.queryDriverMasterPage(queryType);
                    }
                })
                .subscribeOn(jobThread.provideWorker())
                .observeOn(jobThread.providerUi());
    }
}
