package com.uaes.android.data.mapper;

import com.uaes.android.data.json.CommonResponse;
import com.uaes.android.data.json.PowerDefenderJson;
import com.uaes.android.domain.PowerDefenderRepository;
import com.uaes.android.domain.entity.DMPowerStatus;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import io.reactivex.functions.Function;

/**
 * Created by diaokaibin@gmail.com on 2018/5/29.
 */
public class PowerDefenderMapper implements Function<CommonResponse<PowerDefenderJson>, DMPowerStatus> {

    private static final String TV_GOOD = "优";
    private static final String TV_NICE = "良";
    private static final String TV_MIDDLE = "中";
    private static final String TV_BAD = "差";

    private String keyCode = "";

    @Override
    public DMPowerStatus apply(CommonResponse<PowerDefenderJson> receive) throws Exception {
        DMPowerStatus powerStatus = new DMPowerStatus();
        PowerDefenderJson msgContent = receive.msgContent;
        if (msgContent != null) {
            String powerMark = msgContent.powerMark;
            if (powerMark != null) {

                switch (powerMark) {
                    case TV_GOOD:
                        powerStatus.overallRating = PowerDefenderRepository.OVERALL_RATING_EXCELLENT;
                        break;
                    case TV_NICE:
                        powerStatus.overallRating = PowerDefenderRepository.OVERALL_RATING_GOOD;
                        break;
                    case TV_MIDDLE:
                        powerStatus.overallRating = PowerDefenderRepository.OVERALL_RATING_QUALIFIED;
                        break;
                    case TV_BAD:
                        powerStatus.overallRating = PowerDefenderRepository.OVERALL_RATING_POOR;
                        break;

                    default:
                        break;

                }

            }

            List<HashMap<String, PowerDefenderJson.TypeKey>> powerDetails = msgContent.powerDetails;
            powerStatus.systemParts = new HashMap<>();
            if (powerDetails != null && powerDetails.size() > 0) {

                for (int i = 0; i < powerDetails.size(); i++) {
                    HashMap<String, PowerDefenderJson.TypeKey> typeKeyHashMap = powerDetails.get(i);
                    DMPowerStatus.DMSystemPart systemPart = handleData(typeKeyHashMap);
                    powerStatus.systemParts.put(keyCode, systemPart);

                }

            }
        }
        return powerStatus;
    }


    /**
     * 空气系统  1
     * 供电系统  2
     * 操作系统  3
     * 排气系统  4
     * 润滑系统  5
     * 点火系统  6
     * 供油系统  7
     * 热管理系统 8
     **/
    private DMPowerStatus.DMSystemPart handleData(HashMap<String, PowerDefenderJson.TypeKey> typeKeyHashMap) {

        for (int i = 1; i < 9; i++) {
            boolean containsKey = typeKeyHashMap.containsKey(String.valueOf(i));
            if (containsKey) {
                switch (String.valueOf(i)) {
                    case "1":
                        keyCode = DMPowerStatus.KEY_CODE_AIR_SYSTEM;
                        break;
                    case "2":
                        keyCode = DMPowerStatus.KEY_CODE_POWER_SUPPLY_SYSTEM;

                        break;
                    case "3":
                        keyCode = DMPowerStatus.KEY_CODE_OPERATION_SYSTEM;

                        break;
                    case "4":
                        keyCode = DMPowerStatus.KEY_CODE_EXHAUST_SYSTEM;

                        break;
                    case "5":
                        keyCode = DMPowerStatus.KEY_CODE_LUBRICATION_SYSTEM;

                        break;
                    case "6":
                        keyCode = DMPowerStatus.KEY_CODE_IGNITION_SYSTEM;

                        break;
                    case "7":
                        keyCode = DMPowerStatus.KEY_CODE_FUEL_SUPPLY_SYSTEM;

                        break;
                    case "8":
                        keyCode = DMPowerStatus.KEY_CODE_THERMAL_MANAGEMENT_SYSTEM;

                        break;
                    default:
                        break;

                }

                DMPowerStatus.DMSystemPart dmSystemPart = new DMPowerStatus.DMSystemPart(keyCode);
                PowerDefenderJson.TypeKey typeKey = typeKeyHashMap.get(String.valueOf(i));
                dmSystemPart.errorCode = typeKey.firLvl;
                dmSystemPart.errorsNum = typeKey.problemNum;
                dmSystemPart.errors = new ArrayList<>();

                List<PowerDefenderJson.TypeKey.SeriousProblemsBean> seriousProblems = typeKey.seriousProblems;
                if (seriousProblems != null && seriousProblems.size() > 0) {
                    for (int i1 = 0; i1 < seriousProblems.size(); i1++) {
                        PowerDefenderJson.TypeKey.SeriousProblemsBean problemsBean = seriousProblems.get(i1);
                        DMPowerStatus.DMSystemPartError partError = new DMPowerStatus.DMSystemPartError();
                        partError.errorContent = problemsBean.textcontent;
                        partError.errorSubject = problemsBean.title;
                        dmSystemPart.errors.add(partError);

                    }
                }

                return dmSystemPart;
            }

        }

        return null;

    }
}
