package com.uaes.android.presenter.maintainsecretary;

import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.databinding.MaintainFragmentPhoneAppointmentBinding;

/**
 * Created by ${GY} on 2018/5/10
 * des：电话预约
 */

public class MaintainPhoneAppointFragment extends MaintainBaseFragment implements MaintainPhoneAppointOnClickListener {
    private static final String TAG = "MaintainPhoneAppointFragment_";
    private MaintainFragmentPhoneAppointmentBinding binding;
    private MaintainPhoneViewModel maintainAppointItem;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        maintainAppointItem = ViewModelProviders.of(this).get(MaintainPhoneViewModel.class);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater,
                R.layout.maintain_fragment_phone_appointment,
                container, false);
        binding.setLifecycleOwner(this);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding.setMaintainOnClickListener(this);
        binding.setViewmodel(maintainAppointItem);
        maintainAppointItem.initView(getArguments());
    }

    @Override
    public void onBack() {
        mNavigator.onBack();
    }

    @Override
    public void callPhone(String number) {
        Intent intent = new Intent();
        intent.setAction("com.iflytek.action.CALL");
        intent.putExtra("tel", number);
        startActivity(intent);
    }
}
