package com.uaes.android.data.json;

import com.google.gson.annotations.SerializedName;

/**
 * "name": "中国石化惠忠寺加油站",
 * "ADDRESS": "安惠北里321号",
 * "distance": 3062,
 * "duration": 1200,
 * "rate": 4,
 * "fillTime": null,
 * "brand": "中国石化",
 * "longitude": 116.408697,
 * "latitude": 39.996364
 */
public class FuelStationJson {

    @SerializedName("name")
    public String name;

    @SerializedName("address")
    public String address;

    @SerializedName("distance")
    public int distance;

    @SerializedName("duration")
    public int duration;

    @SerializedName("rate")
    public int rate;

    @SerializedName("fillTime")
    public String fillTime;

    @SerializedName("brand")
    public String brand;

    @SerializedName("longitude")
    public double longitude;

    @SerializedName("latitude")
    public double latitude;
}
