package com.uaes.android.presenter.maintainsecretary;

import android.arch.lifecycle.LiveData;
import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.uaes.android.domain.entity.DMMaintainStatus;
import com.uaes.android.domain.usecase.MaintainStatusQuery;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

/**
 * Created by ${GY} on 2018/5/7
 * des：
 */
public class MaintainDetailViewModel extends ViewModel implements MaintainOnClickListener {
    //    mileage
    private static final String TAG = "MaintainDetailViewModel";
    public final MutableLiveData<Integer> types = new MutableLiveData<>();
    public final MutableLiveData<String> contentValues = new MutableLiveData<>();
    public final MutableLiveData<Boolean> showContent = new MutableLiveData<>();
    public final MutableLiveData<MaintainSurplusDetail> surplusDetail = new MutableLiveData<>();


    private final MutableLiveData<List<MaintainDetailItem>> maintainDetailItemsObserver = new MutableLiveData<>();
    private MaintainStatusQuery maintainStatusQuery;
    private Disposable d;

    public MaintainDetailViewModel(MaintainStatusQuery maintainStatusQuery) {
        this.maintainStatusQuery = maintainStatusQuery;
    }


    public LiveData<List<MaintainDetailItem>> getMessageItems() {
        return maintainDetailItemsObserver;
    }

    public void queryMaintainStatus() {
        maintainStatusQuery.execute().subscribe(new Observer<DMMaintainStatus>() {
            @Override
            public void onSubscribe(Disposable disposable) {
                if (d != null) {
                    d.dispose();
                }
                d = disposable;
            }

            @Override
            public void onNext(DMMaintainStatus dmMaintainStatus) {
                Timber.tag(TAG).d("queryMaintainStatus:onSuccess:%s", dmMaintainStatus.toString());
                updateContent(dmMaintainStatus);
            }

            @Override
            public void onError(Throwable throwable) {
                Timber.tag(TAG).e(throwable, "queryMaintainStatus:onError:%s", throwable.toString());
            }

            @Override
            public void onComplete() {

            }
        });
    }


    /**
     * 展示请求到的数据
     *
     * @param dmMaintainStatus 保养清单条目对应的数据对象
     */
    private void updateContent(DMMaintainStatus dmMaintainStatus) {
        if (dmMaintainStatus == null)
            return;
        if (dmMaintainStatus.maintainList != null && dmMaintainStatus.maintainList.size() > 0)
            maintainDetailItemsObserver.setValue(initData(dmMaintainStatus.maintainList, dmMaintainStatus.maintainCodeList));
        MaintainSurplusDetail maintainSurplusDetail = new MaintainSurplusDetail(dmMaintainStatus.maintainType,
                String.valueOf(dmMaintainStatus.maintainValue));
        types.setValue(dmMaintainStatus.maintainType);
        surplusDetail.setValue(maintainSurplusDetail);
        showContent.setValue(true);
    }

    private ArrayList<MaintainDetailItem> initData(List<String> contentList, List<String> codeList) {
        ArrayList<MaintainDetailItem> dataList = new ArrayList<>();
        for (int i = 0; i < contentList.size(); i++) {
            MaintainDetailItem maintainDetailItem = new MaintainDetailItem(i, contentList.get(i), codeList.get(i), false);
            dataList.add(maintainDetailItem);
        }
        return dataList;
    }

    @Override
    public void onClick(int type) {
//        initContent();
    }


    @Override
    protected void onCleared() {
        super.onCleared();
        unSubscribe();
    }

    public void unSubscribe() {
        if (d != null)
            d.dispose();
    }

}
