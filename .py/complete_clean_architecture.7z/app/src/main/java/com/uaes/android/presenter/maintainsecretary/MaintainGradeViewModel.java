package com.uaes.android.presenter.maintainsecretary;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;
import android.os.Bundle;

import com.uaes.android.domain.Result;
import com.uaes.android.domain.usecase.MaintainRecordRating;
import com.uaes.android.presenter.lifecycle.SingleLiveData;

import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

/**
 * Created by ${GY} on 2018/5/9
 * des：
 */
public class MaintainGradeViewModel extends ViewModel implements MaintainGradeOnClickListener {
    private static final String TAG = "MaintainGradeViewModel_";
    public final MutableLiveData<Float> maintainServicePoint = new MutableLiveData<>();
    public final MutableLiveData<Float> maintainAttitudePoint = new MutableLiveData<>();
    public final MutableLiveData<Float> maintainChargePoint = new MutableLiveData<>();
    public final MutableLiveData<Boolean> onSaveStatus = new MutableLiveData<>();
    public final SingleLiveData<Boolean> saveStatus = new SingleLiveData<>();
    private int servicePoint;
    private int attitudePoint;
    private int chargePoint;
    private MaintainRecordRating maintainRecordRating;
    private String id;
    private Disposable d;


    public MaintainGradeViewModel(MaintainRecordRating maintainRecordRating) {
        this.maintainRecordRating = maintainRecordRating;
    }

    @Override
    public void onRateChanged(int type, float rating) {
        Timber.tag(TAG).w("onRateChanged:TYPE:" + type + ",rating:" + rating);
        switch (type) {
            case 0:
                //服务评分
                servicePoint = (int) rating;
                break;
            case 1:
                //态度评分
                attitudePoint = (int) rating;
                break;
            case 2:
                //价格评分
                chargePoint = (int) rating;
                break;
        }
    }

    public void saveData() {
        Timber.tag(TAG).d("saveData:");
        maintainRecordRating.setRating(id, servicePoint, attitudePoint, chargePoint);
        onSaveStatus.setValue(true);
        maintainRecordRating.execute().subscribe(new SingleObserver<Result<Boolean>>() {
            @Override
            public void onSubscribe(Disposable disposable) {
                if (d != null) {
                    d.dispose();
                }
                d = disposable;
            }

            @Override
            public void onSuccess(Result<Boolean> booleanResult) {
                Timber.tag(TAG).d("saveData:%s", booleanResult.content);
                saveStatus.setValue(booleanResult.content);
            }

            @Override
            public void onError(Throwable throwable) {
                Timber.tag(TAG).e(throwable.toString());
                saveStatus.setValue(false);
            }
        });
    }


    public void initData(Bundle arguments) {
        id = arguments.getString(MaintainConstant.MAINTAIN_HISTORY_POSITION_ITEM_ID);
        servicePoint = (int) arguments.getFloat(MaintainConstant.MAINTAIN_SERVICE_POINT, 0f);
        attitudePoint = (int) arguments.getFloat(MaintainConstant.MAINTAIN_ATTITUDE_POINT, 0f);
        chargePoint = (int) arguments.getFloat(MaintainConstant.MAINTAIN_CHARGE_POINT, 0f);
        maintainServicePoint.setValue((float) servicePoint);
        maintainAttitudePoint.setValue((float) attitudePoint);
        maintainChargePoint.setValue((float) chargePoint);
        onSaveStatus.setValue(false);

    }


    @Override
    protected void onCleared() {
        super.onCleared();
        unSubscribe();
    }

    public void unSubscribe() {
        if (d != null)
            d.dispose();
    }
}
