package com.uaes.android.domain;

import com.uaes.android.domain.entity.DMMessageCenterItem;

public interface DMMsgUpdateListener {

    void onUpdate(DMMessageCenterItem item);
}
