package com.uaes.android.presenter.powerdefender.fragment;

import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.android.databinding.library.baseAdapters.BR;
import com.uaes.android.R;
import com.uaes.android.databinding.FragmentPowerDefenderPhoneBinding;
import com.uaes.android.presenter.powerdefender.PowerConstant;
import com.uaes.android.presenter.powerdefender.PowerDefenderOnClickListener;
import com.uaes.android.presenter.powerdefender.pojo.CallPhone;

import timber.log.Timber;

/**
 * Created by diaokaibin@gmail.com on 2018/5/9.
 */
public class PowerDefenderPhoneFragment extends PowerDefenderBaseFragment implements PowerDefenderOnClickListener {

    private static final String TAG = "DefenderPhoneFragment";
    private FragmentPowerDefenderPhoneBinding mPhoneBinding;
    private CallPhone mPhone;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mPhoneBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_power_defender_phone, container, false);
        mPhoneBinding.setLifecycleOwner(this);
        return mPhoneBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mPhone = new CallPhone();
        mPhoneBinding.setVariable(BR.phoneClick, this);
        Bundle arguments = getArguments();
        if (arguments != null) {
            mPhone.phone = arguments.getString(PowerConstant.BUNDLE_DTAT_TO_PHONE);
            mPhone.address = arguments.getString(PowerConstant.BUNDLE_DTAT_TO_NAME);
        }
        mPhoneBinding.setCallphone(mPhone);

    }

    @Override
    public void onResume() {
        super.onResume();

        String string = mPhoneBinding.tvShop4sPhone.getText().toString();
        SpannableString ss1 = new SpannableString(string);
        ss1.setSpan(new ForegroundColorSpan(Color.WHITE), 0, 5, 0);
        mPhoneBinding.tvShop4sPhone.setText(ss1);
    }

    private void callPhone(String phone) {

        try {
            Intent intent = new Intent();
            intent.setAction("com.iflytek.action.CALL");
            intent.putExtra("tel", phone);
            startActivity(intent);
        } catch (Exception e) {
            Timber.tag(TAG).e(e);
        }

    }

    @Override
    public void onClick(int type) {
        switch (type) {
            case 1:
                mNavigator.onBack();
                break;


            case 2:
                callPhone(mPhone.phone);
                break;
        }
    }
}
