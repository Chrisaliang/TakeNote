package com.uaes.android.presenter.driver;

public interface QueryTypeClickListener {

    void queryType(int type);
}
