package com.uaes.android;

import android.arch.lifecycle.ViewModelProvider;

import com.uaes.android.common.UaesViewModelProviderFactory;
import com.uaes.android.domain.usecase.BatteryStatusSubscription;
import com.uaes.android.domain.usecase.DriverMasterDetailQuery;
import com.uaes.android.domain.usecase.DriverMasterQuery;
import com.uaes.android.domain.usecase.FuelFillRatingUpdate;
import com.uaes.android.domain.usecase.FuelHistoryFillListQuery;
import com.uaes.android.domain.usecase.FuelMonitorQuery;
import com.uaes.android.domain.usecase.FuelScaleQuery;
import com.uaes.android.domain.usecase.FuelScaleRealTimeQuery;
import com.uaes.android.domain.usecase.FuelSettingQuery;
import com.uaes.android.domain.usecase.FuelSettingUpdate;
import com.uaes.android.domain.usecase.GasListQuery;
import com.uaes.android.domain.usecase.MaintainItemDetailQuery;
import com.uaes.android.domain.usecase.MaintainRecordQuery;
import com.uaes.android.domain.usecase.MaintainRecordRating;
import com.uaes.android.domain.usecase.MaintainSettingQuery;
import com.uaes.android.domain.usecase.MaintainSettingUpdate;
import com.uaes.android.domain.usecase.MaintainStatusQuery;
import com.uaes.android.domain.usecase.MessageCenterMsgDelete;
import com.uaes.android.domain.usecase.MessageCenterMsgQuery;
import com.uaes.android.domain.usecase.MessageCenterMsgUpdate;
import com.uaes.android.domain.usecase.PowerReportQuery;
import com.uaes.android.domain.usecase.PowerStatusQuery;
import com.uaes.android.domain.usecase.S4ShopListQuery;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

/**
 * @author qingxin.chen
 * Created by qingxin.chen on 2018/5/7.
 */

@Module
class ViewModelModule {

    @Singleton
    @Provides
    static ViewModelProvider.Factory providerFactory(
            App app,
            FuelScaleQuery case1,
            GasListQuery case2,
            FuelScaleRealTimeQuery case3,
            BatteryStatusSubscription case4,
            MessageCenterMsgQuery case5,
            MessageCenterMsgUpdate case6,
            MessageCenterMsgDelete case7,
            FuelMonitorQuery case8,
            FuelHistoryFillListQuery case9,
            FuelSettingQuery case10,
            FuelSettingUpdate case11,
            DriverMasterDetailQuery case12,
            DriverMasterQuery case13,
            PowerStatusQuery case14,
            PowerReportQuery case15,
            S4ShopListQuery case16,
            MaintainSettingQuery case17,
            MaintainSettingUpdate case18,
            MaintainStatusQuery case19,
            MaintainRecordQuery case20,
            MaintainRecordRating case21,
            FuelFillRatingUpdate case22,
            MaintainItemDetailQuery case23
    ) {
        return new UaesViewModelProviderFactory(
                app, case1, case2, case3, case4,
                case5, case6, case7, case8, case9,
                case22, case10, case11, case12, case13,
                case14, case15, case16, case17, case18,
                case19, case20, case21, case23
        );
    }
}
