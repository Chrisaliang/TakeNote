package com.uaes.android;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

/**
 * Json Converter
 * */
@Module
abstract class JsonModule {

    //2018-05-16 16:57:07
    private static final String PATTERN = "yyyy-MM-dd HH:mm:ss";

    @Provides
    @Singleton
    public static Gson gson() {
        return new GsonBuilder()
                .setDateFormat(PATTERN)
//                .setDateFormat(DateFormat.DEFAULT)
                .serializeNulls()
                .create();
//        return new Gson();
    }
}
