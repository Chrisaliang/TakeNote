package com.uaes.android.data;

import com.uaes.android.data.http.DriverMasterApi;
import com.uaes.android.data.json.CommonResponse;
import com.uaes.android.data.json.DriverMasterDetailJson;
import com.uaes.android.data.json.DriverMasterPageJson;
import com.uaes.android.data.mapper.DriverMasterJsonMapper;
import com.uaes.android.domain.DriverMasterRepository;
import com.uaes.android.domain.entity.DMDriverMasterItem;
import com.uaes.android.domain.entity.DMDriverMasterPage;

import java.util.List;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Response;

public class DriverMasterRepositoryImp implements DriverMasterRepository {

    private final DriverMasterApi api;

    private final DriverMasterJsonMapper mapper;

    public DriverMasterRepositoryImp(DriverMasterApi api) {
        this.api = api;
        mapper = new DriverMasterJsonMapper();
    }

    @Override
    public List<DMDriverMasterItem> queryDetailList(int execType, int targetType) throws Exception {
        Call<CommonResponse<List<DriverMasterDetailJson>>> call =
                api.driverMasterDetail(execType, targetType);
        Response<CommonResponse<List<DriverMasterDetailJson>>> response = call.execute();

        return mapper.map(Objects.requireNonNull(response.body()).msgContent);
    }

    @Override
    public DMDriverMasterPage queryDriverMasterPage(int type) throws Exception {
        Call<CommonResponse<DriverMasterPageJson>> masterPageCall = api.driverMasterPage(type);
        Response<CommonResponse<DriverMasterPageJson>> response = masterPageCall.execute();

        return mapper.map(Objects.requireNonNull(response.body()).msgContent);
    }
}
