package com.uaes.android.presenter.fuelaccountancy;

import android.databinding.ObservableBoolean;
import android.databinding.ObservableDouble;
import android.databinding.ObservableField;
import android.databinding.ObservableInt;
import android.databinding.ObservableLong;

public class FuelAccountancyStationItemViewModel {
    /**
     * 编号显示
     */
    public final ObservableInt stationNum = new ObservableInt();
    /**
     * 加油站名称
     */
    public final ObservableField<String> stationName = new ObservableField<>();
    /**
     * 加油站地址
     */
    public final ObservableField<String> stationCity = new ObservableField<>();
    /**
     * 据加油站时间
     */
    public final ObservableLong time = new ObservableLong();
    /**
     * 据加油站距离
     */
    public final ObservableLong distance = new ObservableLong();
    /**
     * 油品质  1：优 2：良 3：中 4：差
     */
    public final ObservableInt fuelLeave = new ObservableInt();
    /**
     * 页面显示字段（时间，距离，油品质）
     */
    public final ObservableField<String> timeAndDistance = new ObservableField<>();
    /**
     * 纬度
     */
    public final ObservableDouble stationLat = new ObservableDouble();
    /**
     * 经度
     */
    public final ObservableDouble stationLng = new ObservableDouble();
    /**
     * 是否选中
     */
    public final ObservableBoolean isChecked = new ObservableBoolean();

    @Override
    public String toString() {
        return "FuelAccountancyStationItemViewModel{" +
                "stationNum=" + stationNum.get() +
                ", stationName=" + stationName.get() +
                ", stationCity=" + stationCity.get() +
                ", timeAndDistance=" + timeAndDistance.get() +
                ", stationLat=" + stationLat.get() +
                ", stationLng=" + stationLng.get() +
                ", isChecked=" + isChecked.get() +
                '}';
    }


}
