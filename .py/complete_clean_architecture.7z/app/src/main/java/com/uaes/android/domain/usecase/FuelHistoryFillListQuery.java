package com.uaes.android.domain.usecase;

import com.uaes.android.domain.FuelHelperRepository;
import com.uaes.android.domain.JobThread;
import com.uaes.android.domain.SingleUseCase;
import com.uaes.android.domain.entity.DMFuelFillHistory;

import java.util.List;

import io.reactivex.Single;
import io.reactivex.functions.Function;

/**
 * 查询加油历史列表
 */
public class FuelHistoryFillListQuery extends SingleUseCase<List<DMFuelFillHistory>> {

    private FuelHelperRepository fuelHelperRepository;

    private JobThread jobThread;

    private int year;

    public FuelHistoryFillListQuery(FuelHelperRepository fuelHelperRepository, JobThread jobThread) {
        this.fuelHelperRepository = fuelHelperRepository;
        this.jobThread = jobThread;
    }

    @Override
    protected Single<List<DMFuelFillHistory>> buildSingle() {
        return Single.just(fuelHelperRepository).map(new Function<FuelHelperRepository, List<DMFuelFillHistory>>() {
            @Override
            public List<DMFuelFillHistory> apply(FuelHelperRepository repository) throws Exception {
                return repository.queryFuelFillHistory(year);
            }
        }).subscribeOn(jobThread.provideWorker())
                .observeOn(jobThread.providerUi());
    }

    /**
     * 设置查询年份
     */
    public void setYear(int year) {
        this.year = year;
    }
}
