package com.uaes.android.presenter.powerdefender;

import com.uaes.android.presenter.powerdefender.pojo.CarIndicateEntity;

/**
 * Created by diaokaibin@gmail.com on 2018/5/8.
 */
public interface PowerPartOnClickListener {
    void onClick(int type, CarIndicateEntity carIndicateEntity);

}
