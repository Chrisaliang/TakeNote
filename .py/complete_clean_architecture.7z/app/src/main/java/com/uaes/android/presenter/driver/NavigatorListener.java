package com.uaes.android.presenter.driver;

public interface NavigatorListener {
    void backPreviewLevel();
}
