package com.uaes.android.presenter.maintainsecretary;

import android.databinding.BindingAdapter;
import android.databinding.BindingMethod;
import android.databinding.BindingMethods;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.RelativeSizeSpan;
import android.widget.TextView;

import com.uaes.android.domain.MaintainRepository;

@BindingMethods({
        @BindingMethod(type = TextView.class, attribute = "selectedWhen", method = "changeWhenState"),
        @BindingMethod(type = TextView.class, attribute = "selectedRate", method = "changeRateState"),
        @BindingMethod(type = TextView.class, attribute = "differentTextSize", method = "changeTextSize")
})
public class MaintainBindAdapter {

    @BindingAdapter(value = "selectedWhen")
    public static void changeWhenState(TextView view, boolean selected) {
        view.setSelected(selected);
    }

    @BindingAdapter(value = "selectedRate")
    public static void changeRateState(TextView view, boolean selected) {
        view.setSelected(selected);
    }

    @BindingAdapter(value = "differentTextSize")
    public static void changeTextSize(TextView view, MaintainSurplusDetail maintainSurplusDetail) {
        if (maintainSurplusDetail == null || TextUtils.isEmpty(maintainSurplusDetail.value)) return;
        String content;
        int endPosition;
        if ("-1".equals(maintainSurplusDetail.value)) {
            view.setText("");
            return;
        }
        if (maintainSurplusDetail.type == MaintainRepository.TYPE_MAINTAIN_DAY) {
            content = maintainSurplusDetail.value + "天";
            endPosition = content.length() - 1;
        } else {
            content = maintainSurplusDetail.value + "KM";
            endPosition = content.length() - 2;
        }

        SpannableString ss1 = new SpannableString(content);
        ss1.setSpan(new RelativeSizeSpan(2f), 0, endPosition, 0);
        view.setText(ss1);
    }
}
