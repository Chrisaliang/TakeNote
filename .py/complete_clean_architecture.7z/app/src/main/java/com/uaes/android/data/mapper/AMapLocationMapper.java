package com.uaes.android.data.mapper;

import android.support.annotation.NonNull;

import com.amap.api.location.AMapLocation;
import com.uaes.android.domain.entity.DMLocation;

import io.reactivex.functions.Function;

public class AMapLocationMapper implements Function<AMapLocation, DMLocation> {
    @Override
    public DMLocation apply(@NonNull AMapLocation input) {
        DMLocation dmLocation = new DMLocation();
        dmLocation.address = input.getAddress();
        dmLocation.city = input.getCity();
        dmLocation.cityCode = input.getCityCode();
        dmLocation.country = input.getCountry();
        dmLocation.isSucceed = true;
        dmLocation.latitude = input.getLatitude();
        dmLocation.longitude = input.getLongitude();
        dmLocation.province = input.getProvince();
        return dmLocation;
    }
}
