package com.uaes.android.common;

import android.app.Application;
import android.arch.lifecycle.ViewModel;
import android.arch.lifecycle.ViewModelProvider;
import android.support.annotation.NonNull;

import com.uaes.android.domain.usecase.BatteryStatusSubscription;
import com.uaes.android.domain.usecase.DriverMasterDetailQuery;
import com.uaes.android.domain.usecase.DriverMasterQuery;
import com.uaes.android.domain.usecase.FuelFillRatingUpdate;
import com.uaes.android.domain.usecase.FuelHistoryFillListQuery;
import com.uaes.android.domain.usecase.FuelMonitorQuery;
import com.uaes.android.domain.usecase.FuelScaleQuery;
import com.uaes.android.domain.usecase.FuelScaleRealTimeQuery;
import com.uaes.android.domain.usecase.FuelSettingQuery;
import com.uaes.android.domain.usecase.FuelSettingUpdate;
import com.uaes.android.domain.usecase.GasListQuery;
import com.uaes.android.domain.usecase.MaintainItemDetailQuery;
import com.uaes.android.domain.usecase.MaintainRecordQuery;
import com.uaes.android.domain.usecase.MaintainRecordRating;
import com.uaes.android.domain.usecase.MaintainSettingQuery;
import com.uaes.android.domain.usecase.MaintainSettingUpdate;
import com.uaes.android.domain.usecase.MaintainStatusQuery;
import com.uaes.android.domain.usecase.MessageCenterMsgDelete;
import com.uaes.android.domain.usecase.MessageCenterMsgQuery;
import com.uaes.android.domain.usecase.MessageCenterMsgUpdate;
import com.uaes.android.domain.usecase.PowerReportQuery;
import com.uaes.android.domain.usecase.PowerStatusQuery;
import com.uaes.android.domain.usecase.S4ShopListQuery;
import com.uaes.android.presenter.batteryhelper.BatteryHelperViewModel;
import com.uaes.android.presenter.driver.DriverMasterDetailViewModel;
import com.uaes.android.presenter.driver.DriverMasterViewModel;
import com.uaes.android.presenter.fuelaccountancy.FuelAccountancyConsumeViewModel;
import com.uaes.android.presenter.fuelaccountancy.FuelAccountancyDetailViewModel;
import com.uaes.android.presenter.fuelaccountancy.FuelAccountancyFuelHistoryViewModel;
import com.uaes.android.presenter.fuelaccountancy.FuelAccountancySettingViewModel;
import com.uaes.android.presenter.fuelaccountancy.FuelAccountancyStationViewModel;
import com.uaes.android.presenter.maintainsecretary.MaintainAppointViewModel;
import com.uaes.android.presenter.maintainsecretary.MaintainContentViewModel;
import com.uaes.android.presenter.maintainsecretary.MaintainDetailViewModel;
import com.uaes.android.presenter.maintainsecretary.MaintainGradeViewModel;
import com.uaes.android.presenter.maintainsecretary.MaintainHistoryViewModel;
import com.uaes.android.presenter.maintainsecretary.MaintainSettingsViewModel;
import com.uaes.android.presenter.message.MessageCenterViewModel;
import com.uaes.android.presenter.powerdefender.viewmodel.AutoRepairViewModel;
import com.uaes.android.presenter.powerdefender.viewmodel.CarStatusViewModel;
import com.uaes.android.presenter.powerdefender.viewmodel.FaultHistoryViewModel;

/**
 * @author qingxin.chen
 * Created by qingxin.chen on 2018/5/7.
 */
public class UaesViewModelProviderFactory implements ViewModelProvider.Factory {

    private FuelScaleQuery fuelScaleQuery;

    private FuelScaleRealTimeQuery fuelScaleRealTimeQuery;

    private GasListQuery gasListQuery;

    private FuelMonitorQuery fuelMonitorQuery;

    private BatteryStatusSubscription batteryStatusSubscription;

    private Application application;

    private MessageCenterMsgQuery msgQuery;

    private MessageCenterMsgUpdate msgUpdate;

    private MessageCenterMsgDelete msgDelete;

    private DriverMasterDetailQuery driverMasterDetailQuery;

    private DriverMasterQuery driverMasterQuery;

    private FuelHistoryFillListQuery fuelHistoryFillListQuery;

    private FuelFillRatingUpdate ratingUpdate;

    private FuelSettingQuery fuelSettingQuery;

    private FuelSettingUpdate fuelSettingUpdate;

    private PowerStatusQuery mPowerStatusQuery;

    private PowerReportQuery mReportQuery;

    private S4ShopListQuery mShopListQuery;

    private MaintainSettingQuery maintainSettingQuery;

    private MaintainSettingUpdate maintainSettingUpdate;

    private MaintainStatusQuery maintainStatusQuery;

    private MaintainRecordQuery maintainRecordQuery;

    private MaintainRecordRating maintainRecordRating;

    private MaintainItemDetailQuery maintainItemDetailQuery;


    public UaesViewModelProviderFactory(
            Application application,
            FuelScaleQuery fuelScaleQuery,
            GasListQuery gasListQuery,
            FuelScaleRealTimeQuery fuelScaleRealTimeQuery,
            BatteryStatusSubscription batteryStatusSubscription,
            MessageCenterMsgQuery msgQuery,
            MessageCenterMsgUpdate msgUpdate,
            MessageCenterMsgDelete msgDelete,
            FuelMonitorQuery fuelMonitorQuery,
            FuelHistoryFillListQuery fuelHistoryFillListQuery,
            FuelFillRatingUpdate ratingUpdate,
            FuelSettingQuery fuelSettingQuery,
            FuelSettingUpdate fuelSettingUpdate,
            DriverMasterDetailQuery driverMasterDetailQuery,
            DriverMasterQuery driverMasterQuery,
            PowerStatusQuery powerStatusQuery,
            PowerReportQuery powerReportQuery,
            S4ShopListQuery shopListQuery,
            MaintainSettingQuery maintainSettingQuery,
            MaintainSettingUpdate maintainSettingUpdate,
            MaintainStatusQuery maintainStatusQuery,
            MaintainRecordQuery maintainRecordQuery,
            MaintainRecordRating maintainRecordRating,
            MaintainItemDetailQuery maintainItemDetailQuery

    ) {
        this.application = application;
        this.gasListQuery = gasListQuery;
        this.fuelScaleQuery = fuelScaleQuery;
        this.fuelScaleRealTimeQuery = fuelScaleRealTimeQuery;
        this.batteryStatusSubscription = batteryStatusSubscription;
        this.msgQuery = msgQuery;
        this.msgUpdate = msgUpdate;
        this.fuelMonitorQuery = fuelMonitorQuery;
        this.msgDelete = msgDelete;
        this.fuelHistoryFillListQuery = fuelHistoryFillListQuery;
        this.ratingUpdate = ratingUpdate;
        this.fuelSettingQuery = fuelSettingQuery;
        this.fuelSettingUpdate = fuelSettingUpdate;
        this.driverMasterDetailQuery = driverMasterDetailQuery;
        this.driverMasterQuery = driverMasterQuery;
        this.mPowerStatusQuery = powerStatusQuery;
        this.mReportQuery = powerReportQuery;
        this.mShopListQuery = shopListQuery;
        this.maintainSettingQuery = maintainSettingQuery;
        this.maintainSettingUpdate = maintainSettingUpdate;
        this.maintainStatusQuery = maintainStatusQuery;
        this.maintainRecordQuery = maintainRecordQuery;
        this.maintainRecordRating = maintainRecordRating;
        this.maintainItemDetailQuery = maintainItemDetailQuery;

    }

    @SuppressWarnings("unchecked")
    @NonNull
    @Override
    public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
        if (modelClass.isAssignableFrom(FuelAccountancyDetailViewModel.class)) {
            return (T) new FuelAccountancyDetailViewModel(fuelScaleQuery, fuelScaleRealTimeQuery);
        } else if (modelClass.isAssignableFrom(FuelAccountancyConsumeViewModel.class)) {
            return (T) new FuelAccountancyConsumeViewModel(fuelMonitorQuery);
        } else if (modelClass.isAssignableFrom(FuelAccountancyFuelHistoryViewModel.class)) {
            return (T) new FuelAccountancyFuelHistoryViewModel(fuelHistoryFillListQuery, ratingUpdate);
        } else if (modelClass.isAssignableFrom(BatteryHelperViewModel.class)) {
            return (T) new BatteryHelperViewModel(application, batteryStatusSubscription);
        } else if (modelClass.isAssignableFrom(MessageCenterViewModel.class)) {
            return (T) new MessageCenterViewModel(msgQuery, msgUpdate, msgDelete);
        } else if (modelClass.isAssignableFrom(DriverMasterDetailViewModel.class)) {
            return (T) new DriverMasterDetailViewModel(driverMasterDetailQuery);
        } else if (modelClass.isAssignableFrom(FuelAccountancySettingViewModel.class)) {
            return (T) new FuelAccountancySettingViewModel(fuelSettingQuery, fuelSettingUpdate);
        } else if (modelClass.isAssignableFrom(DriverMasterViewModel.class)) {
            return (T) new DriverMasterViewModel(driverMasterQuery);
        } else if (modelClass.isAssignableFrom(CarStatusViewModel.class)) {
            return (T) new CarStatusViewModel(application, mPowerStatusQuery);
        } else if (modelClass.isAssignableFrom(FaultHistoryViewModel.class)) {
            return (T) new FaultHistoryViewModel(application, mReportQuery);
        } else if (modelClass.isAssignableFrom(FuelAccountancyStationViewModel.class)) {
            return (T) new FuelAccountancyStationViewModel(gasListQuery);
        } else if (modelClass.isAssignableFrom(AutoRepairViewModel.class)) {
            return (T) new AutoRepairViewModel(mShopListQuery);
        } else if (modelClass.isAssignableFrom(MaintainSettingsViewModel.class)) {
            return (T) new MaintainSettingsViewModel(maintainSettingQuery, maintainSettingUpdate);
        } else if (modelClass.isAssignableFrom(MaintainDetailViewModel.class)) {
            return (T) new MaintainDetailViewModel(maintainStatusQuery);
        } else if (modelClass.isAssignableFrom(MaintainHistoryViewModel.class)) {
            return (T) new MaintainHistoryViewModel(maintainRecordQuery);
        } else if (modelClass.isAssignableFrom(MaintainGradeViewModel.class)) {
            return (T) new MaintainGradeViewModel(maintainRecordRating);
        } else if (modelClass.isAssignableFrom(MaintainAppointViewModel.class)) {
            return (T) new MaintainAppointViewModel(mShopListQuery);
        } else if (modelClass.isAssignableFrom(MaintainContentViewModel.class)) {
            return (T) new MaintainContentViewModel(maintainItemDetailQuery);
        }
        throw new IllegalArgumentException("not support the class:" + modelClass);
    }
}
