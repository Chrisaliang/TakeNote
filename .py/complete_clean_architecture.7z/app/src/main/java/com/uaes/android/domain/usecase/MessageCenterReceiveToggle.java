package com.uaes.android.domain.usecase;

import com.uaes.android.domain.JobThread;
import com.uaes.android.domain.MessageCenterRepository;
import com.uaes.android.domain.MessageReceiveInterpolator;
import com.uaes.android.domain.SingleUseCase;

import io.reactivex.Single;
import io.reactivex.functions.Function;

public class MessageCenterReceiveToggle extends SingleUseCase<Boolean> {

    private MessageCenterRepository repository;

    private JobThread jobThread;

    private static final MessageReceiveInterpolator DEFAULT_INTERPOLATOR = new MessageReceiveInterpolator() {
        @Override
        public boolean receiveMsg(String msgType) {
            return true;
        }
    };

    private MessageReceiveInterpolator interpolator = DEFAULT_INTERPOLATOR;

    public MessageCenterReceiveToggle(MessageCenterRepository repository, JobThread jobThread) {
        this.repository = repository;
        this.jobThread = jobThread;
    }

    @SuppressWarnings("unused")
    public void setInterpolator(MessageReceiveInterpolator interpolator) {
        this.interpolator = interpolator;
    }


    @Override
    protected Single<Boolean> buildSingle() {
        return Single.just(repository)
                .map(new Function<MessageCenterRepository, Boolean>() {
                    @Override
                    public Boolean apply(MessageCenterRepository repository) {
                        repository.setReceive(interpolator);
                        return true;
                    }
                })
                .observeOn(jobThread.providerUi())
                .subscribeOn(jobThread.provideWorker());
    }
}
