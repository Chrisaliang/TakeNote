package com.uaes.android.presenter.fuelaccountancy;

import android.annotation.SuppressLint;
import android.content.Context;
import android.database.DataSetObserver;
import android.databinding.DataBindingUtil;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SpinnerAdapter;

import com.uaes.android.R;
import com.uaes.android.databinding.FuelAccountancyDetailSpinnerListItemBinding;

import java.util.List;

/**
 * @author qingxin.chen
 * Created by qingxin.chen on 2018/5/15.
 */
public class FuelTimeTypeSpinnerAdapter implements SpinnerAdapter {

    LayoutInflater inflater;
    private List<String> timesType;

    FuelTimeTypeSpinnerAdapter(List<String> timesType, Context mContext) {
        this.timesType = timesType;
        inflater = LayoutInflater.from(mContext);
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        final FuelAccountancyDetailSpinnerListItemBinding spinnerBinding = DataBindingUtil.inflate(inflater, R.layout.fuel_accountancy_detail_spinner_list_item, parent, false);
        if (position == 0) {
            spinnerBinding.setSpinnerItem(new TimeTypeSpinnerItem(TimeTypeSpinnerItem.ItemType.LISTFIRST, timesType.get(position)));
        } else {
            spinnerBinding.setSpinnerItem(new TimeTypeSpinnerItem(TimeTypeSpinnerItem.ItemType.LISTOTHER, timesType.get(position)));
        }
        return spinnerBinding.getRoot();
    }

    @Override
    public void registerDataSetObserver(DataSetObserver observer) {

    }

    @Override
    public void unregisterDataSetObserver(DataSetObserver observer) {

    }

    @Override
    public int getCount() {
        return timesType.size();
    }

    @Override
    public Object getItem(int position) {
        return timesType.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public boolean hasStableIds() {
        return true;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        @SuppressLint("ViewHolder") FuelAccountancyDetailSpinnerListItemBinding binding = DataBindingUtil.inflate(inflater, R.layout.fuel_accountancy_detail_spinner_list_item, parent, false);
        binding.setSpinnerItem(new TimeTypeSpinnerItem(TimeTypeSpinnerItem.ItemType.MAINITEM, timesType.get(position)));
        return binding.getRoot();
    }

    @Override
    public int getItemViewType(int position) {
        return 1;
    }

    @Override
    public int getViewTypeCount() {
        return 1;
    }

    @Override
    public boolean isEmpty() {
        return false;
    }


}
