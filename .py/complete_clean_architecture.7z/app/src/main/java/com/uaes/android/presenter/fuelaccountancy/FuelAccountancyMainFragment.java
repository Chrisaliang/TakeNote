package com.uaes.android.presenter.fuelaccountancy;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;

import java.util.Objects;

/**
 * @author qingxin.chen
 * Created by qingxin.chen on 2018/5/7.
 */
public class FuelAccountancyMainFragment extends FuelAccountancyFragment {

    public static final String FUEL_EXTRA_SELECTED_ITEM = "com.uaes.android.presenter.fuelaccountancy.FuelAccountancyMainFragment";

    //    private String[] mTitles;
    private TabLayout mTabLayout;
    private Fragment[] fragments;
    private static final String TAG = "FuelAccountancyMainFrag";
    private static int selectedItem;
    private static boolean isFirst = true;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        fragments = new Fragment[]{new FuelConsumeFragment(), new FuelDetailFragment(), new FuelStationFragment(), new FuelHistoryFragment()};
        isFirst = false;

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fuel_accountancy_main_fragment, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
//        mTitles = Objects.requireNonNull(getContext()).getResources().getStringArray(R.array.fuel_accountancy_titles);
        mTabLayout = view.findViewById(R.id.fuel_main_tab_layout);
//        if (savedInstanceState != null) {
//            selectedItem = savedInstanceState.getInt(FUEL_EXTRA_SELECTED_ITEM);
//            Timber.tag(TAG).d("savedInstanceState  != null " + selectedItem);
//        }

//        Timber.tag(TAG).d("onViewCreated   selectedItem " + selectedItem);
        initTabLayout();

        view.findViewById(R.id.fuel_main_go_set_iv).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //跳转到setting
                navigator.goToSetting();
            }
        });
    }


    @Override
    public void onStart() {
        super.onStart();
        if (selectedItem != mTabLayout.getSelectedTabPosition() || !isFirst) {
            itemSelect(selectedItem);
            Objects.requireNonNull(mTabLayout.getTabAt(selectedItem)).select();
        } else {
            itemSelect(0);
        }
    }


    //    @Override
//    public void onSaveInstanceState(@NonNull Bundle outState) {
//        super.onSaveInstanceState(outState);
//        outState.putInt(FUEL_EXTRA_SELECTED_ITEM, selectedItem);
//        Timber.tag(TAG).d("保存  " + selectedItem);
//    }

    private void initTabLayout() {
        mTabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                itemSelect(tab.getPosition());
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

//        mTabLayout.addTab(mTabLayout.newTab().setText(mTitles[0]));
//        mTabLayout.addTab(mTabLayout.newTab().setText(mTitles[1]));
//        mTabLayout.addTab(mTabLayout.newTab().setText(mTitles[2]));
//        mTabLayout.addTab(mTabLayout.newTab().setText(mTitles[3]));
    }

    private void itemSelect(int position) {
        Fragment fragment = null;
        if (position < fragments.length && position >= 0) {
            fragment = fragments[position];
        }
        if (fragment != null) {
            getChildFragmentManager().beginTransaction()
                    .replace(R.id.fuel_main_frame, fragment)
//                    .addToBackStack(String.valueOf(position))
                    .commit();
        }
    }


}
