package com.uaes.android.presenter.fuelaccountancy;

/**
 * @author qingxin.chen
 * Created by qingxin.chen on 2018/5/7.
 */
public interface FuelAccountancyRatingChangeListener {

    /**
     *
     * */
    void onRateChanged(float rating);

}
