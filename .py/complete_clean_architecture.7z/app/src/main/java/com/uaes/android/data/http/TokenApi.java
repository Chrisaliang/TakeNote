package com.uaes.android.data.http;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

/**
 * Created by hand on 2017/11/7.
 * Token query
 */
public interface TokenApi {
    @GET("car/v1/carAuth/viewAuth")
    Call<TokenResponse> getToken(@Query("accessKey") String vinCode);
}
