package com.uaes.android.data;


import com.uaes.android.App;
import com.uaes.android.R;
import com.uaes.android.data.http.HttpBatteryApi;
import com.uaes.android.data.json.BatteryStatusJson;
import com.uaes.android.data.json.BatteryVolJson;
import com.uaes.android.data.json.CommonResponse;
import com.uaes.android.data.mapper.BatteryStatusJsonMapper;
import com.uaes.android.domain.BatteryRepository;
import com.uaes.android.domain.entity.DMBatteryStatus;

import java.util.Objects;

import retrofit2.Call;
import retrofit2.Response;

public class BatteryRepositoryImp implements BatteryRepository {

    private static final int[] BATTERY_DESCRIPTIONS = new int[]{
            R.string.battery_helper_status_description_1,
            R.string.battery_helper_status_description_2,
            R.string.battery_helper_status_description_3,
            R.string.battery_helper_status_description_4,
    };


    private HttpBatteryApi api;

    private App app;

    public BatteryRepositoryImp(App app, HttpBatteryApi api) {
        this.api = api;
        this.app = app;
    }

    @Override
    public DMBatteryStatus queryBatteryStatus() throws Exception {
        Call<CommonResponse<BatteryStatusJson>> callStatus = api.queryBatterStatus();
        Response<CommonResponse<BatteryStatusJson>> response = callStatus.execute();
        return BatteryStatusJsonMapper.map(
                Objects.requireNonNull(response.body()).msgContent);
    }

    @Override
    public DMBatteryStatus queryBatteryVol() throws Exception {

        Call<CommonResponse<BatteryVolJson>> callVol = api.queryBatteryVol();
        Response<CommonResponse<BatteryVolJson>> response = callVol.execute();
        return BatteryStatusJsonMapper.map(Objects.requireNonNull(response.body()).msgContent);
    }

//    <string name="battery_helper_status_description_1">老化且不足</string>
//    <string name="battery_helper_status_description_2">老化且充足</string>
//    <string name="battery_helper_status_description_3">电量不足，建议立即启动发动机。</string>
//    <string name="battery_helper_status_description_4">蓄电池正常,请放心驾驶。</string>

    // isStatus true 老化
    // isLife  true 充足

    @SuppressWarnings("RedundantThrows")
    @Override
    public String queryBatteryDescription(boolean isStatus, boolean isVol) throws Exception {
        int description = 0;
        if (!isStatus) {
            description += 2;
        }
        if (isVol) {
            description += 1;
        }
        return app.getString(BATTERY_DESCRIPTIONS[description]);
    }
}
