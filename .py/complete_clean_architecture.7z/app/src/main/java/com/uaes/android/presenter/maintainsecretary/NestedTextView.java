package com.uaes.android.presenter.maintainsecretary;

import android.content.Context;
import android.support.annotation.Nullable;
import android.support.v7.widget.AppCompatTextView;
import android.util.AttributeSet;
import android.view.MotionEvent;

/**
 * Created by ${GY} on 2018/5/14
 * des：
 */
public class NestedTextView extends AppCompatTextView {
    public NestedTextView(Context context) {
        super(context);
    }

    public NestedTextView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }

    public NestedTextView(Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        getParent().requestDisallowInterceptTouchEvent(true);
        return super.dispatchTouchEvent(ev);
    }

}
