package com.uaes.android.presenter.maintainsecretary;

public interface MaintainItemOnClickListener {

    void onClick(int type, int position);
}
