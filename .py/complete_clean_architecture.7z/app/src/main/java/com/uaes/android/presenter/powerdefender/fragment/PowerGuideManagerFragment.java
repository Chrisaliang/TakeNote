package com.uaes.android.presenter.powerdefender.fragment;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.presenter.BaseFragment;
import com.uaes.android.presenter.powerdefender.PowerNavigator;

/**
 * Created by diaokaibin@gmail.com on 2018/6/5.
 */
public class PowerGuideManagerFragment extends BaseFragment implements PowerNavigator {

    private PowerDefenderFragment mPowerDefenderFragment = new PowerDefenderFragment();
    private PowerDefenderComponentFragment mPowerDefenderComponentFragment = new PowerDefenderComponentFragment();
    private PowerDefenderFaultHistoryFragment mDefenderFaultHistoryFragment = new PowerDefenderFaultHistoryFragment();
    private PowerDefenderNearByFragment mPowerDefenderNearByFragment = new PowerDefenderNearByFragment();
    private PowerDefenderPhoneFragment mPowerDefenderPhoneFragment = new PowerDefenderPhoneFragment();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_power_defender_guide, container, false);
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (savedInstanceState == null) {
            getChildFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fl_power_content, mPowerDefenderFragment)
                    .commit();
        }
    }

    @Override
    public void onAttachFragment(Fragment childFragment) {
        super.onAttachFragment(childFragment);
        if (childFragment instanceof PowerDefenderBaseFragment) {
            ((PowerDefenderBaseFragment) childFragment).mNavigator = this;
        }
    }


    @Override
    public void goNearByShop() {
        setFragment(mPowerDefenderNearByFragment, null, null);
    }

    @Override
    public void goComponentDetails(Bundle bundle, String type) {
        setFragment(mPowerDefenderComponentFragment, bundle, type);
    }

    @Override
    public void goPhoneCall(Bundle bundle) {
        setFragment(mPowerDefenderPhoneFragment, bundle, null);
    }


    @Override
    public void goHistoryFault(String type) {
        setFragment(mDefenderFaultHistoryFragment, null, type);
    }

    @Override
    public void onBack() {
        getChildFragmentManager().popBackStack(null, 0);
    }

    private void setFragment(Fragment fragment, Bundle bundle, String type) {
        if (bundle != null) {
            fragment.setArguments(bundle);
        }
        getChildFragmentManager()
                .beginTransaction()
                .replace(R.id.fl_power_content, fragment)
                .addToBackStack(null)
                .commit();
    }
}
