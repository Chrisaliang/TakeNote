package com.uaes.android.presenter.powerdefender.viewmodel;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.uaes.android.domain.Result;
import com.uaes.android.domain.entity.DM4SShop;
import com.uaes.android.domain.usecase.S4ShopListQuery;
import com.uaes.android.presenter.powerdefender.pojo.CarLocation;

import java.util.List;

import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

/**
 * Created by diaokaibin@gmail.com on 2018/5/9.
 */
public class AutoRepairViewModel extends ViewModel {
    private static final String TAG = "AutoRepairViewModel";
    public MutableLiveData<CarLocation> carDatas = new MutableLiveData<>();
    private S4ShopListQuery mShopListQuery;
    private Disposable mDisposable;

    public AutoRepairViewModel(S4ShopListQuery shopListQuery) {
        this.mShopListQuery = shopListQuery;
    }

    public void doQuery() {
        mShopListQuery.execute().subscribe(new SingleObserver<Result<List<DM4SShop>>>() {
            @Override
            public void onSubscribe(Disposable d) {
                if (mDisposable != null)
                    mDisposable.dispose();
                mDisposable = d;
            }

            @Override
            public void onSuccess(Result<List<DM4SShop>> result) {

                CarLocation carLocation = new CarLocation();
                carLocation.mLocation = mShopListQuery.getLocation();
                carLocation.mShopList = result.content;
                carDatas.setValue(carLocation);

            }

            @Override
            public void onError(Throwable throwable) {
                Timber.tag(TAG).d(throwable);
            }
        });
    }


    public void cancleQuery() {
        if (mDisposable != null)
            mDisposable.dispose();
    }


}
