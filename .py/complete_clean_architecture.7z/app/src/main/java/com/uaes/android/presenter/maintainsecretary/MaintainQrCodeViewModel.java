package com.uaes.android.presenter.maintainsecretary;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.MutableLiveData;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.support.annotation.NonNull;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;

import java.util.Hashtable;

import timber.log.Timber;

/**
 * Created by ${GY} on 2018/5/8
 * des：
 */
public class MaintainQrCodeViewModel extends AndroidViewModel {
    private static final String TAG = "MaintainQRcodeViewModel";

    private final MutableLiveData<Bitmap> qrCodeImageObserver = new MutableLiveData<>();

    public MaintainQrCodeViewModel(@NonNull Application application) {
        super(application);
    }


    //填充二维码
    public void createQRCode() {
        String url = "https://www.baidu.com/";
        Hashtable<EncodeHintType, Object> hints = new Hashtable<>();
        hints.put(EncodeHintType.CHARACTER_SET, "utf-8");
        hints.put(EncodeHintType.MARGIN, 0);
        BitMatrix matrix = null;
        try {

            matrix = new MultiFormatWriter().encode(url, BarcodeFormat.QR_CODE, getSize(), getSize(), hints);
        } catch (WriterException e) {
            e.printStackTrace();
        }
        int width = 0;
        int height = 0;
        if (matrix != null) {
            width = matrix.getWidth();
            height = matrix.getHeight();
        }
        Timber.tag(TAG).d("width:" + width + ",height:" + height);
        int[] pixels = new int[width * height];
        for (int y = 0; y < height; y++) {
            for (int x = 0; x < width; x++) {
                if (matrix.get(x, y)) {
                    pixels[y * width + x] = Color.BLACK;
                } else {
                    pixels[y * width + x] = Color.WHITE;
                }
            }
        }
        Bitmap bitmap = Bitmap.createBitmap(width, height,
                Bitmap.Config.ARGB_8888);
        bitmap.setPixels(pixels, 0, width, 0, 0, width, height);
        qrCodeImageObserver.setValue(bitmap);
    }

    public MutableLiveData<Bitmap> getQrCodeImageObserver() {
        return qrCodeImageObserver;
    }

    private int getSize() {
        float scale = getApplication().getResources().getDisplayMetrics().density;
        Timber.tag(TAG).d("scale:" + scale + ",size1:" + (int) ((float) 280 * scale + 0.5f));
        return (int) ((float) 280 * scale + 0.5f);
    }
}
