package com.uaes.android.domain.usecase;

import com.uaes.android.domain.FuelHelperRepository;
import com.uaes.android.domain.JobThread;
import com.uaes.android.domain.SingleUseCase;
import com.uaes.android.domain.entity.DMFuelFillHistory;

import io.reactivex.Single;
import io.reactivex.functions.Function;

/**
 * 更新加油记录评价
 */
public class FuelFillRatingUpdate extends SingleUseCase<DMFuelFillHistory> {

    private FuelHelperRepository repository;

    private DMFuelFillHistory history;

    private JobThread jobThread;

    public FuelFillRatingUpdate(FuelHelperRepository repository, JobThread jobThread) {
        this.repository = repository;
        this.jobThread = jobThread;
    }

    @Override
    protected Single<DMFuelFillHistory> buildSingle() {
        return Single.just(repository).map(new Function<FuelHelperRepository, DMFuelFillHistory>() {
            @Override
            public DMFuelFillHistory apply(FuelHelperRepository repository) throws Exception {
                return repository.setFuelAccount(history);
            }
        }).subscribeOn(jobThread.provideWorker()).observeOn(jobThread.providerUi());
    }

    public void setHistory(DMFuelFillHistory item) {
        history = item;
    }
}
