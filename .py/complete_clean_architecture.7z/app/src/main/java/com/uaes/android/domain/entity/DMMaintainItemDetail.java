package com.uaes.android.domain.entity;

/**
 * Created by ${GY} on 2018/5/29
 * des：
 */
public class DMMaintainItemDetail {

    /**
     * 保养详情标题
     */
    public String title;

    /**
     * 保养详情内容
     */
    public String content;
}
