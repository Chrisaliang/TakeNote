package com.uaes.android.data.room;

public interface Tables {

    interface MessageCenter {
        /**
         * 消息中心表名
         */
        String TABLE_NAME = "messageCenter";

        /**
         * 消息时间
         */
        String COLUMN_TIME = "msgTime";

        /**
         * 消息时间戳
         */
        String COLUMN_TIME_STAMP = "msgTimeStamp";

        /**
         * 消息内容
         */
        String COLUMN_CONTENT = "msgContent";

        /**
         * 消息类型
         */
        String COLUMN_TYPE = "TYPE";

        /**
         * 消息 json
         */
        String COLUMN_JSON = "contentJson";
    }
}
