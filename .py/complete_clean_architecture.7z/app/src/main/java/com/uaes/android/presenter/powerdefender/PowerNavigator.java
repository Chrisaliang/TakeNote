package com.uaes.android.presenter.powerdefender;

import android.os.Bundle;

/**
 * Created by diaokaibin@gmail.com on 2018/6/5.
 */
public interface PowerNavigator {


    void goNearByShop();

    void goComponentDetails(Bundle bundle, String type);

    void goPhoneCall(Bundle bundle);

    void goHistoryFault(String type);

    void onBack();
}
