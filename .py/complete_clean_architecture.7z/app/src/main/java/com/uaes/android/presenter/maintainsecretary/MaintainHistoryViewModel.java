package com.uaes.android.presenter.maintainsecretary;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.uaes.android.domain.Result;
import com.uaes.android.domain.entity.DMMaintainRecord;
import com.uaes.android.domain.usecase.MaintainRecordQuery;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

/**
 * Created by ${GY} on 2018/5/8
 * des：
 */
public class MaintainHistoryViewModel extends ViewModel {
    private static final String TAG = "MaintainHistoryViewMode";
    private final MutableLiveData<List<MaintainHistoryItem>> maintainHistoryDataObserver = new MutableLiveData<>();
    private MaintainRecordQuery maintainRecordQuery;
    private Disposable d;

    public MaintainHistoryViewModel(MaintainRecordQuery maintainRecordQuery) {
        this.maintainRecordQuery = maintainRecordQuery;
    }

    public MutableLiveData<List<MaintainHistoryItem>> getMaintainHistoryDataObserver() {
        return maintainHistoryDataObserver;
    }


    public void queryMaintainHistory() {
        maintainRecordQuery.execute().subscribe(new SingleObserver<Result<List<DMMaintainRecord>>>() {
            @Override
            public void onSubscribe(Disposable disposable) {
                if (d != null) {
                    d.dispose();
                }
                d = disposable;
            }
            @Override
            public void onSuccess(Result<List<DMMaintainRecord>> listResult) {
                Timber.tag(TAG).d("queryMaintainHistory:onSuccess:size:%s", listResult.content.size());
                updateView(listResult.content);
            }
            @Override
            public void onError(Throwable throwable) {
                Timber.tag(TAG).e(throwable, "queryMaintainHistory:onError:%s", throwable.toString());
            }
        });
    }
    private void updateView(List<DMMaintainRecord> data) {
        List<MaintainHistoryItem> maintainHistoryItems = new ArrayList<>();
        for (int i = 0; i < data.size(); i++) {
            MaintainHistoryItem maintainHistoryItem = new MaintainHistoryItem();
            maintainHistoryItem.maintainIsComment = data.get(i).isRating();
            maintainHistoryItem.id = data.get(i).id;
            maintainHistoryItem.maintainDate = data.get(i).time;
            maintainHistoryItem.maintainAddress = data.get(i).name;
            maintainHistoryItem.maintainPoint = new DecimalFormat("0.0").format(data.get(i).getRating());
            maintainHistoryItem.maintainShowContent = false;
            maintainHistoryItem.maintainMiles = String.valueOf((data.get(i).mile));
            if (data.get(i).maintainContents.size() > 0) {
                StringBuilder stringBuilder = new StringBuilder();
                for (int i1 = 0; i1 < data.get(i).maintainContents.size(); i1++) {
                    stringBuilder.append(data.get(i).maintainContents.get(i1));
                    stringBuilder.append("\n");
                }
                maintainHistoryItem.maintainContent1 = stringBuilder.toString();
            }
            maintainHistoryItem.maintainPosition = i;
            maintainHistoryItem.maintainServicePoint = data.get(i).serviceRating;
            maintainHistoryItem.maintainAttitudePoint = data.get(i).attitudeRating;
            maintainHistoryItem.maintainChargePoint = data.get(i).transparencyOfFeesRate;
            maintainHistoryItems.add(maintainHistoryItem);
        }
        maintainHistoryDataObserver.setValue(maintainHistoryItems);
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        if (d != null)
            d.dispose();
    }
}
