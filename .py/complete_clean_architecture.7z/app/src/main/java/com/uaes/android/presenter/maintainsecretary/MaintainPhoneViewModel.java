package com.uaes.android.presenter.maintainsecretary;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;
import android.databinding.ObservableInt;
import android.os.Bundle;

/**
 * Created by ${GY} on 2018/5/8
 * des：
 */
public class MaintainPhoneViewModel extends ViewModel {
    private static final String TAG = "MaintainPhoneViewModel_";
    public final MutableLiveData<String> maintainAddress = new MutableLiveData<>();
    public final MutableLiveData<String> maintainPhone = new MutableLiveData<>();
    public final ObservableInt position = new ObservableInt();

    public void initView(Bundle arguments) {
        if (arguments != null) {
            maintainAddress.setValue(arguments.getString(MaintainConstant.MAINTAIN_ADDRESS));
            maintainPhone.setValue(arguments.getString(MaintainConstant.MAINTAIN_PHONE));
        }
    }
}
