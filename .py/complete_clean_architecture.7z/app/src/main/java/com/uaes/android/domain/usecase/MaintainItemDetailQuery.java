package com.uaes.android.domain.usecase;

import com.uaes.android.domain.JobThread;
import com.uaes.android.domain.MaintainRepository;
import com.uaes.android.domain.SingleUseCase;
import com.uaes.android.domain.entity.DMMaintainItemDetail;

import io.reactivex.Single;
import io.reactivex.functions.Function;

/**
 * Created by ${GY} on 2018/5/29
 * des：
 */
public class MaintainItemDetailQuery extends SingleUseCase<DMMaintainItemDetail> {
    private MaintainRepository repository;

    private JobThread jobThread;
    private int type;

    public MaintainItemDetailQuery(MaintainRepository repository, JobThread jobThread) {
        this.repository = repository;
        this.jobThread = jobThread;
    }

    public void setType(int type) {
        this.type = type;
    }

    @Override
    protected Single<DMMaintainItemDetail> buildSingle() {
        return Single.just(repository).map(new Function<MaintainRepository, DMMaintainItemDetail>() {
            @Override
            public DMMaintainItemDetail apply(MaintainRepository repository) throws Exception {
                return repository.queryDMMaintainItemDetail(type);
            }
        }).subscribeOn(jobThread.provideWorker()).observeOn(jobThread.providerUi());
    }
}
