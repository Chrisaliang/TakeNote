package com.uaes.android.data.mapper;

import com.uaes.android.data.json.FuelFillRecordJson;
import com.uaes.android.domain.entity.DMFuelFillHistory;

import java.util.ArrayList;
import java.util.List;

public class FuelFillRecoirdMapper {

    public static List<DMFuelFillHistory> map(List<FuelFillRecordJson> list) {
        List<DMFuelFillHistory> l = new ArrayList<>();
        for (FuelFillRecordJson item : list) {
            l.add(map(item));
        }
        return l;
    }

    public static DMFuelFillHistory map(FuelFillRecordJson json) {
        DMFuelFillHistory item = new DMFuelFillHistory();
        item.volume = Float.valueOf(json.fillAmount);
        item.rating = (int) json.evaluate;
        item.date = json.fillStartDay;
        item.address = json.gasStationName;
        item.id = json.eventId;
        item.isComment = item.rating != 0;
        return item;
    }
}
