package com.uaes.android.presenter.fuelaccountancy;

import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;

import com.github.mikephil.charting.charts.PieChart;
import com.uaes.android.R;
import com.uaes.android.databinding.FuelAccountancyMainFragmentFuelDetailsBinding;

import java.util.ArrayList;
import java.util.Collections;

import javax.inject.Inject;

/**
 * @author qingxin.chen
 * Created by qingxin.chen on 2018/5/7.
 */
public class FuelDetailFragment extends FuelAccountancyFragment {

    @Inject
    ViewModelProvider.Factory factory;

    FuelAccountancyMainFragmentFuelDetailsBinding binding;
    FuelAccountancyDetailViewModel fuelAccountancyDetailViewModel;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        fuelAccountancyDetailViewModel = ViewModelProviders.of(this, factory).get(FuelAccountancyDetailViewModel.class);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.fuel_accountancy_main_fragment_fuel_details, container, false);
        binding.setLifecycleOwner(this);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding.setViewModel(fuelAccountancyDetailViewModel);
        initPieChart();
        initSpinner();
        fuelAccountancyDetailViewModel.init();
    }

    private void initPieChart() {
        PieChart mPieChart
                = binding.fuelMainPichart;
        mPieChart.setNoDataText("");
        mPieChart.setUsePercentValues(true);
        mPieChart.getDescription().setEnabled(false);
        mPieChart.setExtraOffsets(30, 15, 30, 15);
        mPieChart.setDragDecelerationFrictionCoef(0.95f);
        mPieChart.setDrawHoleEnabled(false);
        mPieChart.setRotationEnabled(true);
        mPieChart.setHighlightPerTapEnabled(true);
        mPieChart.setRotationEnabled(true);
        mPieChart.getLegend().setEnabled(false);

        mPieChart.setEntryLabelColor(Color.WHITE);
        mPieChart.setEntryLabelTextSize(20f);
        mPieChart.highlightValue(null);


    }

    private void initSpinner() {
        Spinner spinner = binding.fuelAccountancyDetailSpinner;
        String[] strs = getResources().getStringArray(R.array.fuel_accountancy_detail_times_type);
        ArrayList<String> timesType = new ArrayList<>();
        Collections.addAll(timesType, strs);
        SpinnerAdapter adapter = new FuelTimeTypeSpinnerAdapter(timesType, getContext());
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                fuelAccountancyDetailViewModel.onSelected(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }



}
