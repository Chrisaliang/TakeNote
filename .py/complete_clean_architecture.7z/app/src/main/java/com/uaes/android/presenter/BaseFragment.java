package com.uaes.android.presenter;

import dagger.android.support.DaggerFragment;

/**
 * 添加 通信连接失效 对话框
 */
public abstract class BaseFragment extends DaggerFragment {

}
