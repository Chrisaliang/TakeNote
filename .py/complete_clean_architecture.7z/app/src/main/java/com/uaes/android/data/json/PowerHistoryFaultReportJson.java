package com.uaes.android.data.json;

import com.google.gson.annotations.SerializedName;

/**
 * Created by diaokaibin@gmail.com on 2018/6/4.
 */
public class PowerHistoryFaultReportJson {

    @SerializedName("vin")
    public String vin;
    @SerializedName("pCode")
    public String pCode;
    @SerializedName("timeHapRec")
    public String timeHapRec;
    @SerializedName("timeHealRec")
    public String timeHealRec;
    @SerializedName("fltlvl")
    public String fltlvl;
    @SerializedName("flthis")
    public boolean flthis;
    @SerializedName("fltdlt")
    public boolean fltdlt;
    @SerializedName("title")
    public String title;

}
