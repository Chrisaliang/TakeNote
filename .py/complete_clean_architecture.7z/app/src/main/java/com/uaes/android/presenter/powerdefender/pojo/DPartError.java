package com.uaes.android.presenter.powerdefender.pojo;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by diaokaibin@gmail.com on 2018/5/16.
 */
public class DPartError implements Parcelable {
    public static final Parcelable.Creator<DPartError> CREATOR = new Parcelable.Creator<DPartError>() {
        @Override
        public DPartError createFromParcel(Parcel source) {
            return new DPartError(source);
        }

        @Override
        public DPartError[] newArray(int size) {
            return new DPartError[size];
        }
    };
    /**
     * 错误主题
     */
    public String errorSubject;
    /**
     * 错误内容
     */
    public String errorContent;

    public DPartError() {
    }

    protected DPartError(Parcel in) {
        this.errorSubject = in.readString();
        this.errorContent = in.readString();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.errorSubject);
        dest.writeString(this.errorContent);
    }
}
