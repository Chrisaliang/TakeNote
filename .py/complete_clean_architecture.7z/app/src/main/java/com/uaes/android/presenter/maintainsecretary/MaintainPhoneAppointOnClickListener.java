package com.uaes.android.presenter.maintainsecretary;

public interface MaintainPhoneAppointOnClickListener {

    void onBack();

    void callPhone(String number);
}
