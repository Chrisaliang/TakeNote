package com.uaes.android.data.json;

import com.google.gson.annotations.SerializedName;

/**
 * 当前车况保养状态
 * <p>
 * {
 * "msgCode": "10000",
 * "msg": "OK",
 * "content": {
 * "list": ["发动机机油","机油滤清器"],
 * "remainder": {
 * "dataKey": "day",
 * "dataValue": "10"
 * }
 * },
 * "status": 1,
 * "total": 2
 * }
 */
public class MaintainStatusReminderJson {

    /**
     * 剩余保养数值表示的值类型
     */
    @SerializedName("dataKey")
    public String maintainType;
    /**
     * 剩余保养的值，代表了天数 或者里程 KM
     */
    @SerializedName("dataValue")
    public String maintainValue;

}
