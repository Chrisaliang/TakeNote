package com.uaes.android.presenter.maintainsecretary;

public interface MaintainGradeOnClickListener {

    void onRateChanged(int type, float rating);
}
