package com.uaes.android.presenter.message;

public class MessageCenterMsgItem {

    /**
     * 消息id
     */
    public long id;

    /**
     * 消息时间
     */
    public String msgTime;

    /**
     * 消息内容
     */
    public String msgContent;
}
