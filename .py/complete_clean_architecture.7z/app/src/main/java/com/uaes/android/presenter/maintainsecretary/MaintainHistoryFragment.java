package com.uaes.android.presenter.maintainsecretary;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.method.ScrollingMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.databinding.MaintainFragmentHistoryBinding;
import com.uaes.android.databinding.MaintainItemHistoryBinding;

import java.util.ArrayList;
import java.util.List;

import javax.inject.Inject;

import timber.log.Timber;

/**
 * Created by ${GY} on 2018/5/7
 * des：
 */
public class MaintainHistoryFragment extends MaintainBaseFragment implements MaintainOnClickListener {
    private static final String TAG = "MaintainHistoryFragment";
    private MaintainFragmentHistoryBinding binding;
    private MaintainHistoryViewModel maintainHistoryViewModel;
    private MaintainHistoryAdapter maintainHistoryAdapter;
    @Inject
    ViewModelProvider.Factory factory;
    private Observer<List<MaintainHistoryItem>> listObserver = new Observer<List<MaintainHistoryItem>>() {
        @Override
        public void onChanged(@Nullable List<MaintainHistoryItem> maintainHistoryItems) {
            maintainHistoryAdapter.updateALL(maintainHistoryItems);
        }
    };

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        maintainHistoryViewModel = ViewModelProviders.of(this, factory).get(MaintainHistoryViewModel.class);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater,
                R.layout.maintain_fragment_history, container, false);
        binding.setLifecycleOwner(this);
        Timber.tag(TAG).w("MaintainHistoryFragment_onCreateView");
        maintainHistoryViewModel.getMaintainHistoryDataObserver().observe(this, listObserver);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding.setMaintainOnclickListener(this);
        binding.setMaintainHistoryViewModel(maintainHistoryViewModel);
        initAdapter();
    }

    @Override
    public void onStart() {
        super.onStart();
        Timber.tag(TAG).d("MaintainHistoryFragment_onStart");
        maintainHistoryViewModel.queryMaintainHistory();
    }

    private void initAdapter() {
        if (maintainHistoryAdapter == null)
            maintainHistoryAdapter = new MaintainHistoryAdapter(mNavigator);
        binding.rclMatainHistory.setLayoutManager(new LinearLayoutManager(getActivity()));
        binding.rclMatainHistory.setAdapter(maintainHistoryAdapter);
    }

    @Override
    public void onClick(int type) {
        switch (type) {
            case 0:
                //close
                mNavigator.onBack();
                break;
            case 1:
                //打开二维码
                mNavigator.showQRCode();
                break;
        }
    }


    private static class MaintainHistoryAdapter extends RecyclerView.Adapter<MaintainHistoryViewHolder> {
        private List<MaintainHistoryItem> dataList;
        private MaintainNavigator mNavigator;

        MaintainHistoryAdapter(MaintainNavigator mNavigator) {
            dataList = new ArrayList<>();
            this.mNavigator = mNavigator;
        }

        @NonNull
        @Override
        public MaintainHistoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            MaintainItemHistoryBinding itembinding = DataBindingUtil.inflate(
                    LayoutInflater.from(parent.getContext()),
                    R.layout.maintain_item_history, parent, false);
            return new MaintainHistoryViewHolder(itembinding, this);
        }

        @Override
        public void onBindViewHolder(@NonNull MaintainHistoryViewHolder holder, int position) {
            holder.bind(dataList.get(position), mNavigator);
        }

        @Override
        public int getItemCount() {
            return dataList.size();
        }

        void updateALL(List<MaintainHistoryItem> maintainHistoryItems) {
            dataList.clear();
            dataList.addAll(maintainHistoryItems);
            Timber.tag(TAG).w("dataList.size:%s", dataList.size());
            notifyDataSetChanged();
        }

        void selectAtPosition(int position) {
            Timber.tag(TAG).w("MaintainAppointViewHolder:onClick:%s", position);
            for (int i = 0; i < dataList.size(); i++) {
                if (i == position) {
                    dataList.get(position).maintainShowContent = !dataList.get(position).maintainShowContent;
                }
            }
            notifyDataSetChanged();
        }
    }

    private static class MaintainHistoryViewHolder extends RecyclerView.ViewHolder
            implements MaintainItemOnClickListener {
        private MaintainHistoryAdapter maintainHistoryAdapter;
        private MaintainItemHistoryBinding itemBinding;

        MaintainHistoryViewHolder(MaintainItemHistoryBinding itemBinding, MaintainHistoryAdapter maintainHistoryAdapter) {
            super(itemBinding.getRoot());
            this.itemBinding = itemBinding;
            this.maintainHistoryAdapter = maintainHistoryAdapter;
            itemBinding.tvMaintainContent1.setMovementMethod(ScrollingMovementMethod.getInstance());
        }

        void bind(MaintainHistoryItem maintainHistoryItem, MaintainNavigator mNavigator) {
            itemBinding.setMaintainHistoryItem(maintainHistoryItem);
            itemBinding.setViewListener(this);
            itemBinding.setNavigator(mNavigator);
            itemBinding.executePendingBindings();
        }


        @Override
        public void onClick(int type, int position) {
            Timber.tag(TAG).w("MaintainAppointViewHolder:onClick:%s", type);
            switch (type) {
                case 0:
                    maintainHistoryAdapter.selectAtPosition(position);
                    break;
            }
        }
    }
}
