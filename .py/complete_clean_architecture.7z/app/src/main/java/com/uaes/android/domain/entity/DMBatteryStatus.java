package com.uaes.android.domain.entity;

/**
 * 电池状态
 */
public class DMBatteryStatus {
    /**
     * 电量是否充足
     * true - 充足
     * false - 不充足
     */
    public boolean isBatteryLifeFull;

    /**
     * 电池是否老化
     */
    public boolean isAgeing;

    /**
     * 描述文字
     */
    public String hintDescription;

    public DMBatteryStatus(boolean isBatteryLifeFull, boolean isAgeing, String hintDescription) {
        this.isBatteryLifeFull = isBatteryLifeFull;
        this.isAgeing = isAgeing;
        this.hintDescription = hintDescription;
    }

    public DMBatteryStatus() {

    }

    @Override
    public String toString() {
        return "DMBatteryStatus{" +
                "isBatteryLifeFull=" + isBatteryLifeFull +
                ", isAgeing=" + isAgeing +
                ", hintDescription='" + hintDescription + '\'' +
                '}';
    }
}
