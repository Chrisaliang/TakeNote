package com.uaes.android.data.http;

import com.uaes.android.data.json.TokenResponse;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

/**
 * Created by aber on 2/13/2018.
 * 更新token
 */

public interface TokenRefreshApi {

    @FormUrlEncoded
    @POST("oauth/oauth/token")
    Call<TokenResponse> refreshToken(@Field("grant_type") String grantType,
                                     @Field("refresh_token") String refreshToken);
}
