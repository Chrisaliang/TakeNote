package com.uaes.android.domain.usecase;

import com.uaes.android.domain.FuelHelperRepository;
import com.uaes.android.domain.JobThread;
import com.uaes.android.domain.SingleUseCase;
import com.uaes.android.domain.entity.DMFuelScale;

import io.reactivex.Single;
import io.reactivex.functions.Function;

/**
 * 根据类型查询用油明细，单词查询
 */
public class FuelScaleQuery extends SingleUseCase<DMFuelScale> {

    private FuelHelperRepository repository;

    private int type;

    private JobThread jobThread;

    public FuelScaleQuery(FuelHelperRepository repository, JobThread jobThread) {
        this.repository = repository;
        this.jobThread = jobThread;
    }

    @Override
    protected Single<DMFuelScale> buildSingle() {
        return Single.just(repository).map(new Function<FuelHelperRepository, DMFuelScale>() {
            @Override
            public DMFuelScale apply(FuelHelperRepository fuelHelperRepository) throws Exception {
                return fuelHelperRepository.queryFuelScale(type);
            }
        }).onErrorReturnItem(new DMFuelScale(0, 0, 0, 0))
                .observeOn(jobThread.providerUi())
                .subscribeOn(jobThread.provideWorker());
    }

    public void setType(int type) {
        this.type = type;
    }
}
