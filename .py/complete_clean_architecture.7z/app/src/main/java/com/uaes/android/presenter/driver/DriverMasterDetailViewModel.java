package com.uaes.android.presenter.driver;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.uaes.android.domain.Result;
import com.uaes.android.domain.entity.DMDriverMasterItem;
import com.uaes.android.domain.usecase.DriverMasterDetailQuery;

import java.util.List;

import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

public class DriverMasterDetailViewModel extends ViewModel implements SingleObserver<Result<List<DMDriverMasterItem>>> {

    private static final String TAG = "DriverManagerDetailView";

    public final MutableLiveData<List<DriverMasterDetailItem>> items = new MutableLiveData<>();

    private final DriverMasterDetailListMapper mapper = new DriverMasterDetailListMapper();

    public final MutableLiveData<String> title = new MutableLiveData<>();

    private DriverMasterDetailQuery driverMasterDetailQuery;

    private Disposable disposable;

    public DriverMasterDetailViewModel(DriverMasterDetailQuery driverMasterDetailQuery) {
        this.driverMasterDetailQuery = driverMasterDetailQuery;
    }

    public void updateItem() {
        driverMasterDetailQuery.execute().subscribe(this);
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        checkDisposable();
    }

    private void checkDisposable() {
        if (disposable != null && !disposable.isDisposed())
            disposable.dispose();
    }

    @Override
    public void onSubscribe(Disposable d) {
        checkDisposable();
        disposable = d;
    }

    @Override
    public void onSuccess(Result<List<DMDriverMasterItem>> items) {
        this.items.setValue(mapper.apply(items.content));
    }

    @Override
    public void onError(Throwable e) {
        Timber.tag(TAG).e(e);
    }

    public void setQueryType(int queryType) {
        driverMasterDetailQuery.setQueryType(queryType);
    }

    public void setExecType(int execType) {
        driverMasterDetailQuery.setExecType(execType);
    }
}
