package com.uaes.android.data.json;

import com.google.gson.annotations.SerializedName;

/**
 * Created by hand on 2017/11/7.
 * Holder
 */

/*
* {"access_token":"b9489897-8c54-4de9-9bab-78cc7cb36106",
* "token_type":"bearer",
* "refresh_token":"eb828c54-082b-4568-af56-aaaac2a82d3d",
* "expires_in":38472,
* "scope":"default"}
* */
@SuppressWarnings("WeakerAccess")
public class TokenResponse {
    @SerializedName("access_token")
    public String access_token;
    @SerializedName("token_type")
    public String token_type;
    @SerializedName("refresh_token")
    public String refresh_token;
    @SerializedName("expires_in")
    public int expires_in;
    @SerializedName("scope")
    public String scope;
}
