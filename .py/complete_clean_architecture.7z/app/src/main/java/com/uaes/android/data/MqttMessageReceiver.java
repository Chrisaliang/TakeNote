package com.uaes.android.data;

import android.content.Context;
import android.content.Intent;
import android.support.v4.content.LocalBroadcastManager;

import com.google.gson.Gson;
import com.uaes.android.common.Intents;
import com.uaes.android.data.json.MessageMqttJson;
import com.uaes.android.data.mapper.MessageCenterMapper;
import com.uaes.android.data.room.CacheDao;
import com.uaes.android.data.room.MessageCenterEntity;
import com.uaes.android.domain.MessageCenterRepository;

import javax.inject.Inject;

import dagger.android.DaggerBroadcastReceiver;
import io.reactivex.Single;
import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import timber.log.Timber;

import static com.uaes.android.data.AliPushMessageReceiver.sendNotification;
import static com.uaes.android.data.AliPushMessageReceiver.sendToVoiceSpeak;

public class MqttMessageReceiver extends DaggerBroadcastReceiver {

    private static final String TAG = "MqttMessageReceiver";
    @Inject
    Gson gson;
    @Inject
    MessageCenterRepository repository;
    @Inject
    CacheDao cacheDao;
    private static final MessageCenterMapper mapper = new MessageCenterMapper();
    private Disposable disposable;

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        String extraJson = intent.getStringExtra(Intents.KEY_MQTT_CTR);
        MessageMqttJson mqttJson = gson.fromJson(extraJson, MessageMqttJson.class);
        Timber.tag(TAG).e("action: %s, mqttMessage: %s", intent.getAction(), extraJson);
        sendToVoiceSpeak(context, mqttJson.voiceContent, mqttJson.textContent);
        saveMsgToDb(context, mapper.mapper(mqttJson));
        Intent local = new Intent(Intents.ACTION_POWER_TRAIN_GUARD);
        LocalBroadcastManager.getInstance(context).sendBroadcast(local);
    }


    private void saveMsgToDb(Context context, MessageCenterEntity msg) {

        Single.just(msg)
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(new SingleObserver<MessageCenterEntity>() {
                    @Override
                    public void onSubscribe(Disposable d) {
                        disposable = d;
                    }

                    @Override
                    public void onSuccess(MessageCenterEntity entity) {
                        cacheDao.insertMessageCenter(entity);
                        disposable.dispose();
                        repository.onSaveMessage(mapper.mapper(entity));
                    }

                    @Override
                    public void onError(Throwable e) {
                        Timber.tag(TAG).e(e);
                        if (disposable != null)
                            disposable.dispose();
                    }
                });
        sendNotification(context, msg);
    }


}
