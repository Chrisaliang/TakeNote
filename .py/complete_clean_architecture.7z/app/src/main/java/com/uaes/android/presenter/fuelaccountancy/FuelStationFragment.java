package com.uaes.android.presenter.fuelaccountancy;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TabLayout;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.amap.api.navi.model.NaviLatLng;
import com.uaes.android.R;
import com.uaes.android.databinding.FuelAccountancyFragmentFuelstationBinding;
import com.uaes.android.domain.entity.DMLocation;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.inject.Inject;

import timber.log.Timber;

public class FuelStationFragment extends FuelAccountancyBaseFragment implements FuelAccountancyStationOnClickListener {
    private static final String TAG = "FuelStationFragment";

    @Inject
    ViewModelProvider.Factory factory;

    private FuelAccountancyFragmentFuelstationBinding binding;
    private FuelAccountancyStationViewModel stationViewModel;
    private FuelAccountancyStationAdapter stationAdapter;
    private List<FuelAccountancyStationItemViewModel> fuelAccountancyStationItemViewModels;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        stationAdapter = new FuelAccountancyStationAdapter();
        stationViewModel = ViewModelProviders.of(this, factory).get(FuelAccountancyStationViewModel.class);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.fuel_accountancy_fragment_fuelstation, container, false);
        binding.setLifecycleOwner(this);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding.setStationViewModel(stationViewModel);
        binding.fuelAccountancyStationTab.addOnTabSelectedListener(this);
        binding.setOnClickListener(this);

        initAdapter();
    }

    @Override
    public void onStart() {
        super.onStart();
        initStationObserver();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (binding.fuelAccountancyStationTab != null)
            binding.fuelAccountancyStationTab.removeOnTabSelectedListener(this);
    }

    private void initAdapter() {
        binding.recycleViewStation.setLayoutManager(new LinearLayoutManager(getActivity()));
        binding.recycleViewStation.addItemDecoration(new DividerItemDecoration(Objects.requireNonNull(getActivity()),
                DividerItemDecoration.VERTICAL));
        //default station adapter
        binding.recycleViewStation.setAdapter(stationAdapter);
    }

    private void initStationObserver() {
        //get net data
        stationViewModel.initStationList();
        stationViewModel.getStationListObservable().observe(this, new Observer<List<FuelAccountancyStationItemViewModel>>() {
            @Override
            public void onChanged(@Nullable List<FuelAccountancyStationItemViewModel> stationItemViewModels) {
                stationAdapter.updateStationAll(stationItemViewModels);

                //定位点坐标
                dmLocation = stationViewModel.locationLiveData.getValue();
                Timber.tag(TAG).d("location is ：" + dmLocation.latitude + "," + dmLocation.longitude);

                //编号
                fuelAccountancyStationItemViewModels = stationViewModel.selectStation(0);
                for (int i = 1; i <= fuelAccountancyStationItemViewModels.size(); i++) {
                    fuelAccountancyStationItemViewModels.get(i - 1).stationNum.set(i);
                }
                stationAdapter.updateStationAll(fuelAccountancyStationItemViewModels);
                stationViewModel.stationViewModels.get(0).isChecked.set(true);
            }
        });
    }

    @Override
    public void onTabSelected(TabLayout.Tab tab) {
        switch (tab.getPosition()) {
            case 0:
                fuelAccountancyStationItemViewModels = stationViewModel.selectStation(0);
                break;
            case 1:
                fuelAccountancyStationItemViewModels = stationViewModel.selectStation(1);
                break;
            case 2:
                fuelAccountancyStationItemViewModels = stationViewModel.selectStation(2);
                break;
            default:
                break;
        }
        for (int i = 1; i <= fuelAccountancyStationItemViewModels.size(); i++) {
            fuelAccountancyStationItemViewModels.get(i - 1).stationNum.set(i);
        }
        stationAdapter.updateStationAll(fuelAccountancyStationItemViewModels);
    }


    @Override
    public void onCalculateRouteFailure(int i) {
        super.onCalculateRouteFailure(i);
        Timber.tag(TAG).e("onCalculateRouteFailure : %s", i);
    }

    @Override
    public void onClick(int type) {
        switch (type) {
            case 0://行车方案界面
                stationViewModel.isStation.setValue(false);
                initDrivePlan();
                break;
            case 1://返回加油站列表
                stationViewModel.isStation.setValue(true);
                binding.recycleViewStation.setAdapter(stationAdapter);
                break;
        }
    }

    private DMLocation dmLocation;
    //初始化行车方案的adapter

    private final List<NaviLatLng> naviStart = new ArrayList<>();
    private final List<NaviLatLng> naviEnd = new ArrayList<>();

    private void initDrivePlan() {
        //获取到选中的加油站
        FuelAccountancyStationItemViewModel stationItemViewModel = getSelectItemStation();
        if (stationItemViewModel != null) {

            //联合电子：121.634065,31.272911
            if (naviStart.size() > 0) naviStart.clear();
            NaviLatLng latLngStart = new NaviLatLng(dmLocation.latitude, dmLocation.longitude);
//            NaviLatLng latLngStart = new NaviLatLng(31.245318,121.508043);
            naviStart.add(latLngStart);

            //东方明珠：121.508043,31.245318
            //金茂大厦：121.512323,31.240984
            if (naviEnd.size() > 0) naviEnd.clear();
            NaviLatLng latLngEnd = new NaviLatLng(stationItemViewModel.stationLat.get(), stationItemViewModel.stationLng.get());
            naviEnd.add(latLngEnd);

            Intent intent = new Intent();
            intent.setAction("AUTONAVI_STANDARD_BROADCAST_RECV");
            intent.putExtra("KEY_TYPE", 10007);
            intent.putExtra("EXTRA_SNAME", dmLocation.address);
            intent.putExtra("EXTRA_SLON", dmLocation.longitude);
            intent.putExtra("EXTRA_SLAT", dmLocation.latitude);
            intent.putExtra("EXTRA_DNAME", stationItemViewModel.stationName.get());
            intent.putExtra("EXTRA_DLON", stationItemViewModel.stationLng.get());
            intent.putExtra("EXTRA_DLAT", stationItemViewModel.stationLat.get());
            intent.putExtra("EXTRA_DEV", 0);
            intent.putExtra("EXTRA_M", 0);
            Objects.requireNonNull(getContext()).sendBroadcast(intent);

        } else {
            Toast.makeText(getContext(), "please select a station for plan", Toast.LENGTH_SHORT).show();
        }
    }

    //开始导航
    private void startNavigation() {
        Intent intent = new Intent();
        intent.setAction("AUTONAVI_STANDARD_BROADCAST_RECV");
        intent.putExtra("KEY_TYPE", 10007);
      /*  intent.putExtra("EXTRA_SNAME", currentAddress);
        intent.putExtra("EXTRA_SLON", currentLongitude);
        intent.putExtra("EXTRA_SLAT", currentLatitude);
        intent.putExtra("EXTRA_DNAME", address);
        intent.putExtra("EXTRA_DLON", longitude);
        intent.putExtra("EXTRA_DLAT", latitude);*/
        intent.putExtra("EXTRA_DEV", 0);
        intent.putExtra("EXTRA_M", 0);
        Objects.requireNonNull(getContext()).sendBroadcast(intent);
    }

    private final List<String> tempRoad = new ArrayList<>();

    //获取选中加油站
    private FuelAccountancyStationItemViewModel getSelectItemStation() {
        FuelAccountancyStationItemViewModel itemViewModel = null;
        if (fuelAccountancyStationItemViewModels == null) return null;

        for (FuelAccountancyStationItemViewModel fuelAccountancyStationItemViewModel : fuelAccountancyStationItemViewModels) {
            if (fuelAccountancyStationItemViewModel.isChecked.get()) {
                itemViewModel = fuelAccountancyStationItemViewModel;
            }
        }
        return itemViewModel;
    }


}
