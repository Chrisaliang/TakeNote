package com.uaes.android.domain.usecase;

import android.support.annotation.Nullable;

import com.uaes.android.domain.JobThread;
import com.uaes.android.domain.LocationRepository;
import com.uaes.android.domain.S4ShopRepository;
import com.uaes.android.domain.SingleUseCase;
import com.uaes.android.domain.entity.DM4SShop;
import com.uaes.android.domain.entity.DMLocation;

import java.util.List;

import io.reactivex.Single;
import io.reactivex.functions.Function;

/**
 * 查询4s店列表查询
 */
public class S4ShopListQuery extends SingleUseCase<List<DM4SShop>> {

    private LocationRepository repository;

    private S4ShopRepository s4ShopRepository;

    private JobThread jobThread;

    private DMLocation location;

    public S4ShopListQuery(LocationRepository repository, S4ShopRepository s4ShopRepository, JobThread jobThread) {
        this.repository = repository;
        this.s4ShopRepository = s4ShopRepository;
        this.jobThread = jobThread;
    }

    @Override
    protected Single<List<DM4SShop>> buildSingle() {
        return repository.create().flatMap(new Function<DMLocation, Single<List<DM4SShop>>>() {
            @Override
            public Single<List<DM4SShop>> apply(DMLocation dmLocation) {
                location = dmLocation;
                return Single.just(dmLocation).map(new Function<DMLocation, List<DM4SShop>>() {
                    @Override
                    public List<DM4SShop> apply(DMLocation location) throws Exception {
                        return s4ShopRepository.queryList(location.province, location.latitude, location.longitude);
                    }
                }).subscribeOn(jobThread.provideWorker()).observeOn(jobThread.providerUi());
            }
        });
    }

    @Nullable
    public DMLocation getLocation() {
        return location;
    }
}
