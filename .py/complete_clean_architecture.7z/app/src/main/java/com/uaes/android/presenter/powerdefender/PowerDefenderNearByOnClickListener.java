package com.uaes.android.presenter.powerdefender;

/**
 * Created by diaokaibin@gmail.com on 2018/5/11.
 */
public interface PowerDefenderNearByOnClickListener {

    void onClickPos(int type, int pos);
}
