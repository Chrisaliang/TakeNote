package com.uaes.android.presenter.maintainsecretary;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.uaes.android.domain.Result;
import com.uaes.android.domain.entity.DMMaintainItemDetail;
import com.uaes.android.domain.usecase.MaintainItemDetailQuery;

import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

/**
 * Created by ${GY} on 2018/5/11
 * des：
 */
public class MaintainContentViewModel extends ViewModel {
    private static final String TAG = "MaintainContentViewMode";
    public final MutableLiveData<String> contentObserver = new MutableLiveData<>();
    public final MutableLiveData<String> titleObserver = new MutableLiveData<>();

    private MaintainItemDetailQuery maintainItemDetailQuery;
    private Disposable d;

    public MaintainContentViewModel(MaintainItemDetailQuery maintainItemDetailQuery) {
        this.maintainItemDetailQuery = maintainItemDetailQuery;
    }


    public void queryMaintainItemDetail(int type) {
        maintainItemDetailQuery.setType(type);
        maintainItemDetailQuery.execute().subscribe(new SingleObserver<Result<DMMaintainItemDetail>>() {
            @Override
            public void onSubscribe(Disposable disposable) {
                if (d != null) {
                    d.dispose();
                }
                d = disposable;
            }

            @Override
            public void onSuccess(Result<DMMaintainItemDetail> dmMaintainItemDetailResult) {
                titleObserver.setValue(dmMaintainItemDetailResult.content.title);
                contentObserver.setValue(dmMaintainItemDetailResult.content.content);
            }

            @Override
            public void onError(Throwable throwable) {
                Timber.tag(TAG).e(throwable);
            }
        });
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        unSubscribe();
    }

    public void unSubscribe() {
        if (d != null) {
            d.dispose();
        }
    }
}
