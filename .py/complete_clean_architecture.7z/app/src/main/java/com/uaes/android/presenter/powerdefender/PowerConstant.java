package com.uaes.android.presenter.powerdefender;

/**
 * Created by diaokaibin@gmail.com on 2018/5/11.
 */
public interface PowerConstant {

    String PHONE = "power_phone";
    String ADDRESS = "power_shop_address";
    String BUNDLE_DTAT_TO_PART = "com.uaes.android.presenter.powerdefender.PowerDefenderFragment";
    String BUNDLE_DTAT_TO_PART_TYPE = "com.uaes.android.presenter.powerdefender.PowerDefenderFragment.Type";
    String BUNDLE_DTAT_TO_PHONE = "com.uaes.android.presenter.powerdefender.PowerDefenderFragment.Phone";
    String BUNDLE_DTAT_TO_NAME = "com.uaes.android.presenter.powerdefender.PowerDefenderFragment.Name";
    String BUNDLE_DTAT_TO_LONGITUDE = "com.uaes.android.presenter.powerdefender.PowerDefenderFragment.LONGITUDE ";
    String BUNDLE_DTAT_TO_LATITUDE = "com.uaes.android.presenter.powerdefender.PowerDefenderFragment.LATITUDE ";
}
