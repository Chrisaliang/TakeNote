package com.uaes.android.domain.usecase;

import com.uaes.android.domain.FuelHelperRepository;
import com.uaes.android.domain.JobThread;
import com.uaes.android.domain.entity.DMFuelScale;

import java.util.concurrent.TimeUnit;

import io.reactivex.Observable;
import io.reactivex.functions.Function;

/**
 * 时实查询用油明细
 */
public class FuelScaleRealTimeQuery {

    private static final String TAG = "FuelScaleRealTimeQuery";

    private static final long DEFAULT_DELAY = 3;

    private FuelHelperRepository repository;

    private JobThread jobThread;

    @SuppressWarnings("FieldCanBeLocal")
    private long delay = DEFAULT_DELAY;

    private DMFuelScale last = new DMFuelScale(0, 0, 0, 0);

    public FuelScaleRealTimeQuery(FuelHelperRepository repository, JobThread jobThread) {
        this.repository = repository;
        this.jobThread = jobThread;
    }

    public Observable<DMFuelScale> execute() {
        return Observable.interval(0, delay, TimeUnit.SECONDS, jobThread.provideWorker())
                .flatMap(new Function<Long, Observable<DMFuelScale>>() {
                    @Override
                    public Observable<DMFuelScale> apply(Long aLong) throws Exception {
                        return Observable.just(repository).map(new Function<FuelHelperRepository, DMFuelScale>() {
                            @Override
                            public DMFuelScale apply(FuelHelperRepository repository) throws Exception {
                                DMFuelScale local = repository.queryFuelScale(FuelHelperRepository.TYPE_FUEL_REAL_TIME);
                                if (local == null) {
                                    local = new DMFuelScale(0, 0, 0, 0);
                                }
                                last = local;
                                return local;
                            }
                        }).onErrorReturnItem(last)
                                .subscribeOn(jobThread.provideWorker());
                    }
                }).observeOn(jobThread.providerUi());
    }
}
