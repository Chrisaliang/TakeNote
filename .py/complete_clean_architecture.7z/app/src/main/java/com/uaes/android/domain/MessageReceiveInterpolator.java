package com.uaes.android.domain;

public interface MessageReceiveInterpolator {

    boolean receiveMsg(String msgType);
}
