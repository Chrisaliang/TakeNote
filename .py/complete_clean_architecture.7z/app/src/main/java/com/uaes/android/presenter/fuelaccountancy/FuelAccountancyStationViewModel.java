package com.uaes.android.presenter.fuelaccountancy;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.uaes.android.domain.Result;
import com.uaes.android.domain.entity.DMGas;
import com.uaes.android.domain.entity.DMLocation;
import com.uaes.android.domain.usecase.GasListQuery;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;


public class FuelAccountancyStationViewModel extends ViewModel {
    private static final String TAG = "FuelAccountancyStationV";

    private final MutableLiveData<List<FuelAccountancyStationItemViewModel>> stationListObservable = new MutableLiveData<>();
    public final MutableLiveData<Boolean> isStation = new MutableLiveData<>();
    public final MutableLiveData<DMLocation> locationLiveData = new MutableLiveData<>();


    public final List<FuelAccountancyStationItemViewModel> stationViewModels = new ArrayList<>();

    private final GasListQuery gasListQuery;
    private Disposable disposableGasListQuery;

    public FuelAccountancyStationViewModel(GasListQuery gasListQuery) {
        this.gasListQuery = gasListQuery;
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        if (disposableGasListQuery != null)
            disposableGasListQuery.dispose();
    }

    //get net data for station list
    public void initStationList() {
        isStation.setValue(true);

        gasListQuery.execute().subscribe(new SingleObserver<Result<List<DMGas>>>() {
            @Override
            public void onSubscribe(Disposable d) {
                if (disposableGasListQuery != null)
                    disposableGasListQuery.dispose();
                disposableGasListQuery = d;
            }

            @Override
            public void onSuccess(Result<List<DMGas>> listResult) {
                locationLiveData.setValue(gasListQuery.getLocation());
                updateStationList(listResult.content);
                Timber.tag(TAG).d("content:%s", listResult.content);
            }

            @Override
            public void onError(Throwable e) {
                Timber.tag(TAG).e(e);
            }
        });
    }

    //set net data
    private void updateStationList(List<DMGas> gasList) {
        stationViewModels.clear();
        for (int i = 0; i < gasList.size(); i++) {
            FuelAccountancyStationItemViewModel stationItemViewModel = new FuelAccountancyStationItemViewModel();
            stationItemViewModel.stationNum.set(i + 1);
            stationItemViewModel.stationName.set(gasList.get(i).name);
            stationItemViewModel.stationCity.set(gasList.get(i).brand + "-" + gasList.get(i).address);

            long duration = gasList.get(i).duration;
            stationItemViewModel.time.set(duration);

            long distance = gasList.get(i).distance;
            stationItemViewModel.distance.set(distance);

            int rate = gasList.get(i).rate;
            stationItemViewModel.fuelLeave.set(rate);

            stationItemViewModel.timeAndDistance.set(getTimeString(duration) + "-" + getTotalLenString(distance) + "-" + getGasRate(rate));

            stationItemViewModel.stationLat.set(gasList.get(i).latitude);
            stationItemViewModel.stationLng.set(gasList.get(i).longitude);

            Timber.tag(TAG).d("init stationItemViewModel:%s", stationItemViewModel.toString());

            stationViewModels.add(stationItemViewModel);

        }
        stationListObservable.setValue(stationViewModels);
    }


    public MutableLiveData<List<FuelAccountancyStationItemViewModel>> getStationListObservable() {
        return stationListObservable;
    }



    public List<FuelAccountancyStationItemViewModel> selectStation(int type) {
        return updateStationOrder(type, stationViewModels);
    }

    //排序 0：距离最短  1：时间最短  2：评级最小（最优）
    private List<FuelAccountancyStationItemViewModel> updateStationOrder(final int type, List<FuelAccountancyStationItemViewModel> stationViewModels) {
        Collections.sort(stationViewModels, new Comparator<FuelAccountancyStationItemViewModel>() {
            @Override
            public int compare(FuelAccountancyStationItemViewModel o1, FuelAccountancyStationItemViewModel o2) {
                switch (type) {
                    case 0:
                        return (int) (o1.distance.get() - o2.distance.get());
                    case 1:
                        return (int) (o1.time.get() - o2.time.get());
                    case 2:
                        return o1.fuelLeave.get() - o2.fuelLeave.get();
                }
                return -1;
            }
        });
        return stationViewModels;
    }

    //评级转换
    private String getGasRate(int rate) {
        switch (rate) {
            case 1:
                return "差";
            case 2:
                return "中";
            case 3:
                return "良";
            case 4:
                return "优";
            default:
                return "未知";

        }
    }

    //距离转换
    private String getTotalLenString(long distance) {
        if (distance < 0) return "";
        if (distance < 1000) return distance + "米";
        else return new DecimalFormat("#.0").format(distance / 1000.0) + "公里";
    }

    //时间转换
    private String getTimeString(long second) {
        if (second < 0) return "";
        StringBuilder time = new StringBuilder("");
        if (second < 60) return time.append(second).append("秒").toString();
        int minutes = (int) Math.round(second / 60.0);
        if (minutes < 60) return time.append(minutes).append("分钟").toString();
        else {
            int hour = minutes / 60;
            time.append(hour).append("小时");
            if (minutes % 60 != 0) time.append(minutes % 60).append("分钟");
        }
        return time.toString();
    }


}