package com.uaes.android.presenter.message;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.databinding.MessageCenterFragmentMainBinding;
import com.uaes.android.databinding.MessageCenterItemMessageBinding;
import com.uaes.android.presenter.BaseFragment;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.inject.Inject;

import timber.log.Timber;

public class MessageCenterFragment extends BaseFragment
        implements QueryTypeListener, UpdateMessageListener {

    private static final String TAG = "MessageCenterFragment";

    MessageCenterFragmentMainBinding binding;
    @Inject
    ViewModelProvider.Factory factory;
    private MessageAdapter adapter;
    private MessageCenterViewModel viewModel;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        adapter = new MessageAdapter();
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.message_center_fragment_main,
                container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding.setLifecycleOwner(this);
        binding.setClickListener(this);
        viewModel = ViewModelProviders.of(this, factory).get(MessageCenterViewModel.class);
//        viewModel.selected.set(0);
        binding.setMsgType(viewModel);
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
//        binding.recyclerView.addItemDecoration(new OutsideBarDecoration());
        binding.recyclerView.addItemDecoration(
                new DividerItemDecoration(Objects.requireNonNull(getActivity()), DividerItemDecoration.VERTICAL)
        );
        binding.recyclerView.setAdapter(adapter);

        viewModel.getMessageItems().observe(this, new Observer<List<MessageCenterMsgItem>>() {
            @Override
            public void onChanged(@Nullable List<MessageCenterMsgItem> items) {
                adapter.updateAll(items);
            }
        });
        viewModel.getUpdateMessageItem().observe(this, new Observer<MessageCenterMsgItem>() {
            @Override
            public void onChanged(@Nullable MessageCenterMsgItem item) {
                adapter.updateFirst(item);
            }
        });

        new ItemTouchHelper(new ItemTouchHelper.Callback() {
            @Override
            public int getMovementFlags(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder) {
//                return makeMovementFlags(0, ItemTouchHelper.RIGHT) |
//                        makeMovementFlags(0, ItemTouchHelper.LEFT);
                return 0;
            }

            @Override
            public boolean onMove(RecyclerView recyclerView, RecyclerView.ViewHolder viewHolder, RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(RecyclerView.ViewHolder viewHolder, int direction) {
                if (viewHolder instanceof MessageViewHolder)
                    adapter.removePosition(viewHolder.getAdapterPosition());
            }
        }).attachToRecyclerView(binding.recyclerView);
    }

    @Override
    public void onStart() {
        super.onStart();

        viewModel.updateMessage();

        viewModel.subscribe();
    }

    @Override
    public void onStop() {
        super.onStop();
        viewModel.unSubscribe();
    }

    @Override
    public void onClick(int type) {
        viewModel.updateMessage(type);
    }

    @Override
    public void onItemUpdate(MessageCenterMsgItem item) {
        adapter.updateFirst(item);
    }

    private static class MessageViewHolder extends RecyclerView.ViewHolder {

        private final MessageCenterItemMessageBinding itemBinding;

        MessageViewHolder(MessageCenterItemMessageBinding binding) {
            super(binding.getRoot());
            itemBinding = binding;
        }

        public void bind(MessageCenterMsgItem item) {
            itemBinding.setMsgItem(item);
            itemBinding.executePendingBindings();
        }
    }

    private class MessageAdapter extends RecyclerView.Adapter<MessageViewHolder> {

        private List<MessageCenterMsgItem> data;

        MessageAdapter() {
            data = new ArrayList<>(0);
        }

        @NonNull
        @Override
        public MessageViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater inflater = LayoutInflater.from(parent.getContext());
            MessageCenterItemMessageBinding binding = DataBindingUtil
                    .inflate(inflater, R.layout.message_center_item_message, parent, false);
            return new MessageViewHolder(binding);
        }

        @Override
        public void onBindViewHolder(@NonNull MessageViewHolder holder, int position) {
            holder.bind(data.get(position));
        }

        @Override
        public int getItemCount() {
            return data.size();
        }

        public void updateAll(List<MessageCenterMsgItem> items) {
            Timber.tag(TAG).d("data set count is %d", items.size());
            data.clear();
            data.addAll(items);
            notifyDataSetChanged();
            Timber.tag(TAG).d("after data set count is %d", data.size());
        }

        @SuppressWarnings("unused")
        public void insertPosition(MessageCenterMsgItem item, int position) {
            data.add(position, item);
            notifyItemInserted(position);
        }

        void updateFirst(MessageCenterMsgItem item) {
            data.add(0, item);
            notifyItemInserted(0);
        }

        public void removePosition(int position) {
            Timber.tag(TAG).d("swipe position is %d", position);
            viewModel.removeItem(data.get(position));
            data.remove(position);
            notifyItemRemoved(position);
        }
    }

}
