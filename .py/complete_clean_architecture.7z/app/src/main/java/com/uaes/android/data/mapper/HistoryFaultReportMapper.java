package com.uaes.android.data.mapper;

import com.uaes.android.data.json.CommonResponse;
import com.uaes.android.data.json.PowerHistoryFaultReportJson;
import com.uaes.android.domain.entity.DMPowerReport;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.functions.Function;

/**
 * Created by diaokaibin@gmail.com on 2018/6/4.
 */
public class HistoryFaultReportMapper implements Function<CommonResponse<List<PowerHistoryFaultReportJson>>, List<DMPowerReport>> {
    @Override
    public List<DMPowerReport> apply(CommonResponse<List<PowerHistoryFaultReportJson>> receive) throws Exception {

        List<DMPowerReport> reportList = new ArrayList<>();
        List<PowerHistoryFaultReportJson> content = receive.msgContent;
        if (content != null) {
            for (int i = 0; i < content.size(); i++) {
                DMPowerReport report = new DMPowerReport();
                PowerHistoryFaultReportJson reportJson = content.get(i);
                report.problemDescription = reportJson.title;
                report.date = reportJson.timeHapRec;
                report.isResolved = reportJson.flthis;
                report.resolvedDate = reportJson.timeHealRec;
                reportList.add(report);
            }

            return reportList;
        }

        return null;
    }
}
