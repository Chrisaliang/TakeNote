package com.uaes.android.data;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.uaes.android.App;
import com.uaes.android.data.http.HttpFuelHelper;
import com.uaes.android.data.http.SettingApi;
import com.uaes.android.data.json.CommonResponse;
import com.uaes.android.data.json.FuelFillRecordJson;
import com.uaes.android.data.json.FuelMonitorJson;
import com.uaes.android.data.json.FuelScale;
import com.uaes.android.data.json.FuelSettingsJson;
import com.uaes.android.data.json.FuelStationJson;
import com.uaes.android.data.json.GeneralAttributeSent;
import com.uaes.android.data.json.JsonRequestBody;
import com.uaes.android.data.mapper.DataFuelScaleMapper;
import com.uaes.android.data.mapper.FuelFillRecoirdMapper;
import com.uaes.android.data.mapper.FuelMonitorMapper;
import com.uaes.android.data.mapper.JsonGasStationMapper;
import com.uaes.android.domain.FuelHelperRepository;
import com.uaes.android.domain.aggregation.ARFuelMonitor;
import com.uaes.android.domain.entity.DMFuelFillHistory;
import com.uaes.android.domain.entity.DMFuelScale;
import com.uaes.android.domain.entity.DMFuelSetting;
import com.uaes.android.domain.entity.DMGas;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import retrofit2.Call;
import retrofit2.Response;

public class FuelHelperRepositoryImp implements FuelHelperRepository {
    private static final String TAG = "FuelHelperRepositoryImp";

    private static final String[] QUERY_KEYS = new String[]{
            "realTime", "week", "mon", "hundred", "thousand", "all"
    };

    private HttpFuelHelper api;

    private SettingApi settingApi;

    private DataFuelScaleMapper fuelScaleMapper = new DataFuelScaleMapper();

    private FuelMonitorMapper monitorMapper = new FuelMonitorMapper();

    private Gson gson;

    @SuppressWarnings("FieldCanBeLocal")
    private App app;

    public FuelHelperRepositoryImp(HttpFuelHelper api, SettingApi settingApi, App app, Gson gson) {
        this.api = api;
        this.settingApi = settingApi;
        this.app = app;
        this.gson = gson;
    }

    @Override
    public DMFuelScale queryFuelScale(int type) throws Exception {
        Response<CommonResponse<FuelScale>> response
                = api.getFuelScale(QUERY_KEYS[type]).execute();
        if (response.isSuccessful()) {
            return fuelScaleMapper.apply(Objects.requireNonNull(response.body()).msgContent);
        } else {
            return null;
        }
    }

    @Override
    public boolean updateFuelSetting(DMFuelSetting dmFuelSetting) throws Exception {
        Call<CommonResponse<GeneralAttributeSent>> call = settingApi.lowFuelWarningSent(JsonRequestBody.createFuelSettingUpdate(gson, dmFuelSetting.gasQuery, dmFuelSetting.fuelThreshold));
        Response<CommonResponse<GeneralAttributeSent>> execute = call.execute();
        GeneralAttributeSent msgContent = Objects.requireNonNull(execute.body()).msgContent;
        for (GeneralAttributeSent.GeneralAttribute item : msgContent.attributeList) {
            if (item.attributeType.equals("gasQuery") &&
                    dmFuelSetting.gasQuery != Integer.valueOf(item.attributeValue)) {
                return false;
            } else if (item.attributeType.equals("CSthreshold") &&
                    dmFuelSetting.fuelThreshold != Integer.valueOf(item.attributeValue)) {
                return false;
            }
        }
        return true;
    }

    @Override
    public DMFuelSetting queryFuelSetting() throws Exception {
        Call<CommonResponse<FuelSettingsJson>> generalAttributeReceiveCall = settingApi.lowFuelWarningReceive(JsonRequestBody.createFuelSettingQuery(gson));
        Response<CommonResponse<FuelSettingsJson>> execute = generalAttributeReceiveCall.execute();
        DMFuelSetting setting = new DMFuelSetting();
        FuelSettingsJson fuelSettingsJson = Objects.requireNonNull(execute.body()).msgContent;
        if (fuelSettingsJson != null) {
            setting.fuelThreshold = Integer.valueOf(fuelSettingsJson.threShold);
            setting.gasQuery = Integer.valueOf(fuelSettingsJson.type);

        }
        return setting;
    }

    @Override
    public List<DMGas> queryGasList(double longitude, double latitude, int strategy) throws Exception {
        Call<CommonResponse<List<FuelStationJson>>> station = api.getStation(longitude + "," + latitude, strategy);
        Response<CommonResponse<List<FuelStationJson>>> execute = station.execute();
        List<FuelStationJson> json = Objects.requireNonNull(execute.body()).msgContent;
        List<DMGas> dmGases = new ArrayList<>();
        for (FuelStationJson item : json) {
            dmGases.add(JsonGasStationMapper.map(item));
        }
        return dmGases;
    }

    @Override
    public ARFuelMonitor queryFuelMonitor() throws Exception {
        Call<CommonResponse<FuelMonitorJson>> call = api.getMonitor();
        Response<CommonResponse<FuelMonitorJson>> response = call.execute();
        return monitorMapper.apply(Objects.requireNonNull(response.body()));
    }

    @Override
    public List<DMFuelFillHistory> queryFuelFillHistory(int year) throws Exception {
        CommonResponse<List<FuelFillRecordJson>> body = api.getFillRecord(String.valueOf(year)).execute().body();
        return FuelFillRecoirdMapper.map(Objects.requireNonNull(body).msgContent);
    }

    @Override
    public DMFuelFillHistory setFuelAccount(DMFuelFillHistory fuelBookkeeping) throws Exception {
        Response<JsonObject> execute = api.setFuelAccount(fuelBookkeeping.id, fuelBookkeeping.rating).execute();
        if (execute.isSuccessful()) {
            return fuelBookkeeping;
        } else {
            return null;
        }
    }

    @Override
    public List<String> getYears() throws Exception {
        return Objects.requireNonNull(api.queryAvailableYears().execute().body()).msgContent;
    }
}
