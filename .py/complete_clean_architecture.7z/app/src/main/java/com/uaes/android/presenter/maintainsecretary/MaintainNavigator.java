package com.uaes.android.presenter.maintainsecretary;

import android.os.Bundle;

/**
 * Created by ${GY} on 2018/5/11
 * des：
 * 业务接口,
 */
public interface MaintainNavigator {
    /**
     * 跳转到一键预约
     */
    void showMaintainPoint();

    /**
     * 跳转到保养设置
     */
    void showSetting();

    /**
     * 跳转保养历史
     */
    void showHistory();

    /**
     * 跳转保养详情
     * @param code 条目
     */
    void showMaintainContentDetail(int code);

    /**
     * 打开二维码
     */
    void showQRCode();

    /**
     * 打开评分页面
     */
    void showGrade(Bundle bundle);

    /**
     * 打开电话预约页面
     */
    void showPhoneAppoint(Bundle bundle);

    /**
     * 打开高德地图导航页面
     */
    void showDriveScheme(Bundle bundle);

    /**
     * 回退
     */
    void onBack();
}
