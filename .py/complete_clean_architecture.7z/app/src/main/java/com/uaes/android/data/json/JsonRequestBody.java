package com.uaes.android.data.json;

import android.support.annotation.NonNull;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.uaes.android.domain.FuelHelperRepository;
import com.uaes.android.domain.entity.DMMaintainRating;

import java.io.IOException;

import javax.annotation.Nullable;

import okhttp3.MediaType;
import okhttp3.RequestBody;
import okio.BufferedSink;

/**
 * Created by aber on 1/25/2018.
 * Json Request body
 */

public class JsonRequestBody extends RequestBody {

    private static final MediaType JSON_TYPE = MediaType.parse("application/json");

    private final String jsonString;

    private JsonRequestBody(String jsonString) {
        this.jsonString = jsonString;
    }

    public static JsonRequestBody createFuelSettingUpdate(Gson gson, @FuelHelperRepository.GasFilter int type, int range) {
        JsonObject jsonObject = new JsonObject();
        JsonArray jsonArray = new JsonArray();
        JsonObject itemType = new JsonObject();
        itemType.addProperty("attributeType", "gasQuery");
        itemType.addProperty("attributeValue", String.valueOf(type));
        jsonArray.add(itemType);

        JsonObject itemRange = new JsonObject();
        itemRange.addProperty("attributeType", "CSthreshold");
        itemRange.addProperty("attributeValue", String.valueOf(range));
        jsonArray.add(itemRange);
        jsonObject.add("attributeList", jsonArray);
        return new JsonRequestBody(gson.toJson(jsonObject));
    }

    public static JsonRequestBody createFuelSettingQuery(Gson gson) {
        JsonArray jsonArray = new JsonArray();
        jsonArray.add("CSthreshold");
        jsonArray.add("gasQuery");
        return new JsonRequestBody(gson.toJson(jsonArray));
    }

    public static JsonRequestBody createMaintainSettingUpdate(Gson gson, boolean isPush, int pushType, int pushFrequency) {
        JsonObject json = new JsonObject();
        json.addProperty("pushFlag", isPush);
        json.addProperty("pushTimeType", String.valueOf(pushType + 1));
        json.addProperty("pushFrequency", String.valueOf(pushFrequency + 1));
        return new JsonRequestBody(gson.toJson(json));
    }

    public static JsonRequestBody createMaintainRatingUpdate(Gson gson, DMMaintainRating rating) {
        JsonObject json = new JsonObject();
        json.addProperty("recordId", Integer.parseInt(rating.id));
        json.addProperty("efficientService", rating.serviceRating);
        json.addProperty("friendlyAttitude", rating.attitudeRating);
        json.addProperty("transparentFees", rating.transparencyOfFeesRate);
        return new JsonRequestBody(gson.toJson(json));
    }

    @Nullable
    @Override
    public MediaType contentType() {
        return JSON_TYPE;
    }

    @Override
    public void writeTo(@NonNull BufferedSink sink) throws IOException {
        sink.writeUtf8(jsonString);
    }

    public String getJson() {
        return jsonString;
    }
}
