package com.uaes.android.presenter.fuelaccountancy;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.github.mikephil.charting.data.BarEntry;
import com.uaes.android.domain.Result;
import com.uaes.android.domain.entity.DMFuelFillHistory;
import com.uaes.android.domain.usecase.FuelFillRatingUpdate;
import com.uaes.android.domain.usecase.FuelHistoryFillListQuery;
import com.uaes.android.presenter.lifecycle.SingleLiveData;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import io.reactivex.functions.Function;
import timber.log.Timber;

/**
 * @author qingxin.chen
 * Created by qingxin.chen on 2018/5/11.
 */
public class FuelAccountancyFuelHistoryViewModel extends ViewModel
        implements FuelAccountancyOnSelectListener,
        FuelAcountancyHistoryOnYearSlideListener,
        FuelAccountancyRatingChangeListener {

    private static final String TAG = "FuelAccountancyFuelHist";

    public final MutableLiveData<List<BarEntry>> fuelHistoryBarEntry = new MutableLiveData<>();
    public final MutableLiveData<DMFuelFillHistory> dmFuelFillHistory = new MutableLiveData<>();
    @SuppressWarnings("WeakerAccess")
    public final MutableLiveData<Integer> selectStatus = new MutableLiveData<>();
    public final ArrayList<Integer> years = new ArrayList<>();
    public final MutableLiveData<Integer> rightYearIndex = new MutableLiveData<>();

    public final MutableLiveData<Boolean> showComment = new MutableLiveData<>();
    public int numShownItem;

    private DMFuelFillHistory tempFillHistory = new DMFuelFillHistory();

    public final SingleLiveData<String> msgTips = new SingleLiveData<>();

    private Disposable fuelHistoryDisposable;
    private FuelHistoryFillListQuery fuelHistoryFillListQuery;

    private FuelFillRatingUpdate ratingUpdate;


    public FuelAccountancyFuelHistoryViewModel(FuelHistoryFillListQuery query,
                                               FuelFillRatingUpdate ratingUpdate) {
        this.fuelHistoryFillListQuery = query;
        this.ratingUpdate = ratingUpdate;
        initYears();

        //当显示的年数没有超过3时，则selectStatus为总年数减一，为的是选中最右边的年份
        numShownItem = years.size() > 3 ? 2 : years.size() - 1;
        selectStatus.setValue(numShownItem);
        rightYearIndex.setValue(years.size() - 1);
        query.setYear(years.get(years.size() - 1));
    }

    private void initYears() {
        Calendar calendar = Calendar.getInstance();

        int nowYear = calendar.get(Calendar.YEAR);
        int mEarlistYear = 2014;
        //TODO query the year from server
        for (int year = mEarlistYear; year <= nowYear; year++) {
            years.add(year);
        }
    }

    public void init() {
        showComment.setValue(false);
        fuelHistoryFillListQuery.execute().map(new Function<Result<List<DMFuelFillHistory>>, List<BarEntry>>() {
            @Override
            public List<BarEntry> apply(Result<List<DMFuelFillHistory>> listResult) {
                List<BarEntry> entries = new ArrayList<>();
                for (int i = 0; i < listResult.content.size(); i++) {
                    entries.add(new BarEntry(i, listResult.content.get(i).volume, listResult.content.get(i)));
                }
                return entries;
            }
        }).subscribe(new SingleObserver<List<BarEntry>>() {
            @Override
            public void onSubscribe(Disposable d) {
                if (fuelHistoryDisposable != null) {
                    fuelHistoryDisposable.dispose();
                }
                fuelHistoryDisposable = d;
            }

            @Override
            public void onSuccess(List<BarEntry> barEntries) {
                Timber.tag(TAG).d(barEntries.toString());
                fuelHistoryBarEntry.setValue(barEntries);
            }

            @Override
            public void onError(Throwable e) {
                Timber.tag(TAG).e(e);
            }
        });

    }

    @Override
    protected void onCleared() {
        super.onCleared();
        if (fuelHistoryDisposable != null) {
            fuelHistoryDisposable.dispose();
        }
    }

    public void updateUI(DMFuelFillHistory dmFuelFillHistory) {
        showComment.setValue(true);
        if (dmFuelFillHistory == null) return;
        if (!dmFuelFillHistory.isComment) {
            dmFuelFillHistory.rating = 0;
        }
        this.dmFuelFillHistory.setValue(dmFuelFillHistory);
        tempFillHistory = dmFuelFillHistory;
    }

    @SuppressWarnings("ConstantConditions")
    @Override
    public void onSelected(int type) {
        if (selectStatus.getValue() == null || selectStatus.getValue() == type)
            return;
        selectStatus.setValue(type);

        //selectedYear
        int selectdYear = years.get(rightYearIndex.getValue() - numShownItem + selectStatus.getValue());
        Timber.tag(TAG).d(String.valueOf(selectdYear));
        fuelHistoryFillListQuery.setYear(selectdYear);
        init();
    }

    @Override
    public void onRateChanged(float rating) {
        if (tempFillHistory != null)
            tempFillHistory.rating = (int) rating;
    }

    @Override
    public void onDirectionClick(DirectionType type) {
        switch (type) {
            case LEFT:
                //noinspection ConstantConditions
                rightYearIndex.setValue(rightYearIndex.getValue() - 1);
                //noinspection ConstantConditions
                selectStatus.setValue(selectStatus.getValue() + 1);
                break;
            case RIGHT:
                //noinspection ConstantConditions
                rightYearIndex.setValue(rightYearIndex.getValue() + 1);
                //noinspection ConstantConditions
                selectStatus.setValue(selectStatus.getValue() - 1);
                break;
            default:
                break;
        }
    }

    private Disposable ratingDisposable;

    public void saveRating() {
        if (tempFillHistory.rating <= 0) {
            msgTips.setValue("评分至少一颗星!!!");
            return;
        }
        ratingUpdate.setHistory(tempFillHistory);
        ratingUpdate.execute().subscribe(new SingleObserver<Result<DMFuelFillHistory>>() {
            @Override
            public void onSubscribe(Disposable d) {
                if (ratingDisposable != null)
                    ratingDisposable.dispose();
                ratingDisposable = d;
            }

            @Override
            public void onSuccess(Result<DMFuelFillHistory> dmFuelFillHistoryResult) {
                Timber.tag(TAG).d("保存结果: %s", dmFuelFillHistoryResult.content);

                msgTips.setValue("评价成功");
                tempFillHistory.isComment = true;
                updateUI(dmFuelFillHistoryResult.content);
            }

            @Override
            public void onError(Throwable e) {
                Timber.tag(TAG).e(e);
                dmFuelFillHistory.setValue(dmFuelFillHistory.getValue());
            }
        });
    }
}
