package com.uaes.android.tts;

import android.content.Context;

import com.iflytek.autofly.audioservice.aidl.Balance;
import com.iflytek.autofly.audioservice.util.AudioManager;
import com.iflytek.autofly.audioservice.util.AudioServiceCons.AudioChannel;
import com.iflytek.autofly.audioservice.util.AudioServiceCons.MicMode;
import com.iflytek.autofly.audioservice.util.IAudioListener;
import com.iflytek.autofly.utils.FlyLog;

/**
 * channel control
 *
 * @author Administrator
 */
@Deprecated
public class ChannelControl {

    /**
     * the syn obj of ChannelControl
     */
    private static ChannelControl mControl;
    private final String TAG = "ChannelControl";
    /**
     * phone channel
     */
    private final int AUDIO_CHANNEL_PHONE = AudioChannel.BT_TEL;
    /**
     * local channel manager
     */
    private AudioManager mAudioManager = null;
    /**
     * activity context
     */
    private Context mContext;
    /**
     * audiomanager listener
     */
    private IAudioListener mListener = new IAudioListener() {

        @Override
        public void onVolumeChanged(int arg0, int arg1) {
            // TODO Auto-generated method stub

        }

        @Override
        public void onServiceStatusChanged(int arg0) {
            // TODO Auto-generated method stub

        }

        @Override
        public void onMuteChanged(boolean arg0) {
            // TODO Auto-generated method stub

        }

        @Override
        public void onLoudnessCompensationChanged(boolean arg0) {
            // TODO Auto-generated method stub

        }

        @Override
        public void onEqChanged(int arg0, int arg1) {
            // TODO Auto-generated method stub

        }

        @Override
        public void onAudioChannel() {
            // TODO Auto-generated method stub

        }

        @Override
        public void onBalanceChanged(Balance arg0) {
            // TODO Auto-generated method stub

        }

        @Override
        public void onChannelGainChanged(int arg0, int arg1) {
            // TODO Auto-generated method stub

        }

        @Override
        public void onKeyToneChanged(boolean arg0) {
            // TODO Auto-generated method stub

        }

        @Override
        public void onLoudnessChanged(int arg0, int arg1, int arg2) {
            // TODO Auto-generated method stub

        }

        @Override
        public void onNaviMixChanged(boolean arg0) {
            // TODO Auto-generated method stub

        }

        @Override
        public void onNaviMixScaleChanged(int arg0) {
            // TODO Auto-generated method stub

        }

        @Override
        public void onVolumeOnSpeedChanged(boolean arg0) {
            // TODO Auto-generated method stub

        }

        @Override
        public void onScreenOffMuteChanged(boolean arg0) {
            // TODO Auto-generated method stub

        }

        @Override
        public void onReverseMuteChanged(boolean arg0) {
            // TODO Auto-generated method stub

        }
    };

    private ChannelControl(Context context) {
        mContext = context;
        // 初始化
        checkManager(context);

        if (null == mAudioManager) {
            FlyLog.i(TAG, "--> ChannelControl error!");
            throw new RuntimeException("audio manager is not initialized");
        }

    }

    public static ChannelControl getInstance(Context context) {

        if (mControl == null) {
            synchronized (ChannelControl.class) {
                if (mControl == null)
                    mControl = new ChannelControl(context);
            }
        }
        return mControl;
    }

    /**
     * 打开电话通道
     */
    public void startPhone() {

        FlyLog.i(TAG, "startPhone channel");
        checkManager(mContext);
        if (null != mAudioManager) {
            mAudioManager.switchChannel(AUDIO_CHANNEL_PHONE);
            mAudioManager.setMicMode(MicMode.PASS_BY);
        } else {
            FlyLog.i(TAG, "startPhone mAudioManager = null");
        }

    }

    // /**
    // * 打开TTs通道
    // */
    // public void startPlayTTS() {
    //
    // FLog.d(TAG, "startPlayTTS channel");
    // checkManager();
    // // 切换音频通道
    // try {
    // // 参数二为优先级
    // mIRRCtrlManager.switchAudioOut(RRAudioChannel.AUDIO_CHANNEL_DEF,
    // AUDIO_OPRITY_TTS);
    // } catch (RemoteException e) {
    // // TODO Auto-generated catch block
    // e.printStackTrace();
    // }
    //
    // }
    //
    // /**
    // * 关闭TTs通道
    // */
    // public void stopPlayTTS() {
    //
    // FLog.d(TAG, "stopPlayTTS channel");
    // try {
    // mIRRCtrlManager.switchAudioOut(AUDIO_CLOSE_BASE
    // + RRAudioChannel.AUDIO_CHANNEL_DEF, AUDIO_OPRITY_TTS);
    // } catch (RemoteException e) {
    // // TODO Auto-generated catch block
    // e.printStackTrace();
    // }
    //
    // }

    /**
     * 关闭电话通道
     */
    public void stopPhone() {

        FlyLog.i(TAG, "stopPhone channel");
        checkManager(mContext);
        if (null != mAudioManager) {
            if (mAudioManager.getCurrentChannel() == AUDIO_CHANNEL_PHONE) {
                FlyLog.i(TAG, "close phone channel");
                int ret = mAudioManager.closeChannel(AUDIO_CHANNEL_PHONE);
                FlyLog.d(TAG, "stopPhone: ret = " + ret);
            }
            mAudioManager.setMicMode(MicMode.WAKEUP);
        } else {
            FlyLog.i(TAG, "startPhone mAudioManager = null");
        }

    }

    /**
     * 获取控制器 checkManager:(这里用一句话描述这个方法的作用). <br/>
     * (方法详述，简单方法可以省略) <br/>
     */
    private void checkManager(Context context) {

        if (null == mAudioManager) {
            if (null != context) {
                FlyLog.i(TAG,
                        "checkManager context != null And create instance");
                mAudioManager = AudioManager.getInstance();
                if (mAudioManager == null) {
                    mAudioManager = AudioManager.registerListener(context,
                            mListener);
                }
            } else {
                FlyLog.i(TAG, "checkManager context = null");
            }
        }

    }

}
