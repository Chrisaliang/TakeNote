package com.uaes.android.data.json;

import com.google.gson.annotations.SerializedName;

/**
 * 保养秘书配置
 *
 * {
 "msgCode": "10000",
 "msg": "OK",
 "content": {
 "pushFlag": false,
 "pushTimeType": "1",
 "pushFrequency": "1"
 },
 "status": 1,
 "total": 1
 }
 */
public class MaintainSettingJson {
    /**
     * 是否接收推送
     */
    @SerializedName("pushFlag")
    public boolean isAllowedPush;

    /**
     * 距离保养多久开始接受推送
     */
    @SerializedName("pushTimeType")
    public int pushType;

    /**
     * 推送频率
     */
    @SerializedName("pushFrequency")
    public int pushFrequency;

    public MaintainSettingJson(boolean isAllowedPush, int pushType, int pushFrequency) {
        this.isAllowedPush = isAllowedPush;
        this.pushType = pushType;
        this.pushFrequency = pushFrequency;
    }

    public MaintainSettingJson() {
    }
}
