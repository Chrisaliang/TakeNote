package com.uaes.android.data.mapper;

import android.content.Context;
import android.support.annotation.NonNull;

import com.uaes.android.R;
import com.uaes.android.data.json.BatteryStatusJson;
import com.uaes.android.data.json.BatteryVolJson;
import com.uaes.android.domain.entity.DMBatteryStatus;

public class BatteryStatusJsonMapper {

    private static final int[] BATTERY_DESCRIPTIONS = new int[]{
            R.string.battery_helper_status_description_1,
            R.string.battery_helper_status_description_2,
            R.string.battery_helper_status_description_3,
            R.string.battery_helper_status_description_4,
    };

    public static DMBatteryStatus map(@NonNull BatteryStatusJson input, @NonNull BatteryVolJson volJson, Context context) {
        final boolean vol = volJson.state;
        final boolean status = input.state;
        int description = 0;
        if (vol) {
            description += 2;
        }
        if (status) {
            description += 1;
        }
        return new DMBatteryStatus(vol, !status, context.getString(BATTERY_DESCRIPTIONS[description]));
    }

    public static DMBatteryStatus map(@NonNull BatteryStatusJson input) {
        final boolean status = input.state;
        return new DMBatteryStatus(false, !status, null);
    }


    public static DMBatteryStatus map(@NonNull BatteryVolJson volJson) {
        final boolean vol = volJson.state;
        return new DMBatteryStatus(vol, false, null);
    }
}
