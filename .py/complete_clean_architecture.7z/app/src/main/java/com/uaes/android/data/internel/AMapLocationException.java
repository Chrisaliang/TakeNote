package com.uaes.android.data.internel;

class AMapLocationException extends IllegalStateException {
    AMapLocationException(int errorCode, String errorInfo) {
    }
}
