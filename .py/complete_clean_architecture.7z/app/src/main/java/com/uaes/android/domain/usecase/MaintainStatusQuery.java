package com.uaes.android.domain.usecase;

import com.uaes.android.domain.JobThread;
import com.uaes.android.domain.MaintainRepository;
import com.uaes.android.domain.entity.DMMaintainStatus;

import java.util.concurrent.TimeUnit;

import io.reactivex.Observable;
import io.reactivex.ObservableSource;
import io.reactivex.functions.Function;

/**
 * 保养状态查询
 */
public class MaintainStatusQuery {

    private MaintainRepository repository;

    private JobThread jobThread;

    public MaintainStatusQuery(MaintainRepository repository, JobThread jobThread) {
        this.repository = repository;
        this.jobThread = jobThread;
    }

  /*  @Override
    protected Single<DMMaintainStatus> buildSingle() {
        return Single.just(repository).map(new Function<MaintainRepository, DMMaintainStatus>() {
            @Override
            public DMMaintainStatus apply(MaintainRepository repository) throws Exception {
                return repository.queryStatus();
            }
        }).subscribeOn(jobThread.provideWorker()).observeOn(jobThread.providerUi());
    }*/

    public Observable<DMMaintainStatus> execute() {
        return Observable.just(repository).flatMap(new Function<MaintainRepository, ObservableSource<DMMaintainStatus>>() {

            @SuppressWarnings("RedundantThrows")
            @Override
            public ObservableSource<DMMaintainStatus> apply(final MaintainRepository repository) throws Exception {
                return Observable.interval(0, 30, TimeUnit.SECONDS, jobThread.provideWorker())
                        .map(new Function<Long, DMMaintainStatus>() {
                            @Override
                            public DMMaintainStatus apply(Long aLong) throws Exception {
                                return repository.queryStatus();
                            }
                        })
                        .onErrorReturn(new Function<Throwable, DMMaintainStatus>() {
                            @Override
                            public DMMaintainStatus apply(Throwable throwable) throws Exception {
                                return null;
                            }
                        })
                        .observeOn(jobThread.providerUi());
            }
        }).subscribeOn(jobThread.provideWorker());
    }
}
