package com.uaes.android.domain.usecase;

import com.uaes.android.domain.JobThread;
import com.uaes.android.domain.PowerDefenderRepository;
import com.uaes.android.domain.SingleUseCase;
import com.uaes.android.domain.entity.DMPowerReport;

import java.util.List;

import io.reactivex.Single;
import io.reactivex.functions.Function;

public class PowerReportQuery extends SingleUseCase<List<DMPowerReport>> {

    private PowerDefenderRepository repository;

    private JobThread jobThread;

    public PowerReportQuery(PowerDefenderRepository repository, JobThread jobThread) {
        this.repository = repository;
        this.jobThread = jobThread;
    }

    @Override
    protected Single<List<DMPowerReport>> buildSingle() {
        return Single.just(repository).map(new Function<PowerDefenderRepository, List<DMPowerReport>>() {
            @Override
            public List<DMPowerReport> apply(PowerDefenderRepository repository) throws Exception {
                return repository.queryPowerReport();
            }
        }).subscribeOn(jobThread.provideWorker()).observeOn(jobThread.providerUi());
    }
}
