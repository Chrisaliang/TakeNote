package com.uaes.android.presenter.batteryhelper;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.MutableLiveData;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.v4.content.LocalBroadcastManager;

import com.uaes.android.R;
import com.uaes.android.common.Intents;
import com.uaes.android.domain.entity.DMBatteryStatus;
import com.uaes.android.domain.usecase.BatteryStatusSubscription;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

public class BatteryHelperViewModel extends AndroidViewModel {

    private static final String TAG = "BatteryHelperViewModel";
    /**
     * 电量检测
     */
    public final MutableLiveData<String> batteryNum = new MutableLiveData<>();
    /**
     * 电量检测级别：0:白色，1：红色
     */
    public final MutableLiveData<Boolean> batteryNumType = new MutableLiveData<>();
    /**
     * 中间图片类型：
     * 0：battery_helper_battery_no.png
     * 1：battery_helper_battery_old.png
     * 2：battery_helper_battery_healthy.png
     */
    public final MutableLiveData<Drawable> batteryType = new MutableLiveData<>();
    /**
     * 健康监测
     */
    public final MutableLiveData<String> batteryHealthy = new MutableLiveData<>();
    /**
     * 健康检测级别：0:白色，1：红色
     */
    public final MutableLiveData<Boolean> batteryHealthyType = new MutableLiveData<>();
    /**
     * 整体描述
     */
    public final MutableLiveData<String> batteryDetail = new MutableLiveData<>();

    private final BatteryStatusSubscription batteryStatusSubscription;

    private Disposable disposable;


    public BatteryHelperViewModel(@NonNull Application application, BatteryStatusSubscription batteryStatusSubscription) {
        super(application);
        this.batteryStatusSubscription = batteryStatusSubscription;
    }

    public void subscription() {
        batteryStatusSubscription.execute()
                .subscribe(new Observer<DMBatteryStatus>() {
                    @Override
                    public void onSubscribe(Disposable d) {
                        if (disposable != null)
                            disposable.dispose();
                        disposable = d;
                    }

                    @Override
                    public void onNext(DMBatteryStatus dmBatteryStatus) {
                        Timber.tag(TAG).d(dmBatteryStatus.toString());
                        update(dmBatteryStatus);
                    }

                    @Override
                    public void onError(Throwable e) {
                        Timber.tag(TAG).e(e);
                        LocalBroadcastManager.getInstance(getApplication()).sendBroadcast(new Intent(Intents.ACTION_NETWORK_ERROR));
                    }

                    @Override
                    public void onComplete() {

                    }
                });
    }

    public void unSubscribe() {
        if (disposable != null)
            disposable.dispose();
    }

    //get net data
    private void update(DMBatteryStatus dmBatteryStatus) {
        Resources res = getApplication().getResources();
        batteryNum.setValue(dmBatteryStatus.isBatteryLifeFull ?
                res.getString(R.string.battery_helper_fragment_tv_battery_normal) :
                res.getString(R.string.battery_helper_fragment_tv_battery_low)
        );
        batteryNumType.setValue(dmBatteryStatus.isBatteryLifeFull);
        if (dmBatteryStatus.isBatteryLifeFull && !dmBatteryStatus.isAgeing) {
            batteryType.setValue(res.getDrawable(R.drawable.battery_helper_battery_healthy));
        } else if (dmBatteryStatus.isBatteryLifeFull && dmBatteryStatus.isAgeing) {
            batteryType.setValue(res.getDrawable(R.drawable.battery_helper_battery_old));
        } else {
            batteryType.setValue(res.getDrawable(R.drawable.battery_helper_battery_no));
        }
        batteryHealthy.setValue(dmBatteryStatus.isAgeing ?
                res.getString(R.string.battery_helper_fragment_tv_battery_healthy_oid) :
                res.getString(R.string.battery_helper_fragment_tv_battery_healthy_good)
        );
        batteryHealthyType.setValue(dmBatteryStatus.isAgeing);
        batteryDetail.setValue(dmBatteryStatus.hintDescription);
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        unSubscribe();
    }
}
