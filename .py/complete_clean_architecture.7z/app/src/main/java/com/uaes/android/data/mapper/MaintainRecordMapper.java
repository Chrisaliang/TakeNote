package com.uaes.android.data.mapper;

import com.uaes.android.data.json.CommonResponse;
import com.uaes.android.data.json.MaintainRecordJson;
import com.uaes.android.domain.entity.DMMaintainRecord;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.functions.Function;

/**
 * Created by ${GY} on 2018/5/21
 * des：
 */
public class MaintainRecordMapper implements Function<CommonResponse<List<MaintainRecordJson>>, ArrayList<DMMaintainRecord>> {


    @Override
    public ArrayList<DMMaintainRecord> apply(CommonResponse<List<MaintainRecordJson>> listCommonResponse) {
        ArrayList<DMMaintainRecord> dmMaintainRecords = new ArrayList<>();
        List<MaintainRecordJson> maintainRecordJsons = listCommonResponse.msgContent;
        if (maintainRecordJsons == null)
            maintainRecordJsons = new ArrayList<>();
        for (int i = 0; i < maintainRecordJsons.size(); i++) {
            DMMaintainRecord dmMaintainRecord = new DMMaintainRecord();
            dmMaintainRecord.id = maintainRecordJsons.get(i).id;
            dmMaintainRecord.name = maintainRecordJsons.get(i).name;
            dmMaintainRecord.mile = maintainRecordJsons.get(i).mile;
            dmMaintainRecord.time = maintainRecordJsons.get(i).time;
            dmMaintainRecord.attitudeRating = maintainRecordJsons.get(i).attitudeRating;
            dmMaintainRecord.serviceRating = maintainRecordJsons.get(i).serviceRating;
            dmMaintainRecord.transparencyOfFeesRate = maintainRecordJsons.get(i).transparencyOfFeesRate;
            ArrayList<String> contentList = new ArrayList<>();
            for (int i1 = 0; i1 < maintainRecordJsons.get(i).maintainContents.size(); i1++) {
                contentList.add(maintainRecordJsons.get(i).maintainContents.get(i1).content);
            }
            dmMaintainRecord.maintainContents = contentList;
            dmMaintainRecords.add(dmMaintainRecord);
        }
        return dmMaintainRecords;
    }
}
