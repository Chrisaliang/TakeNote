package com.uaes.android.presenter.maintainsecretary;

import android.os.Bundle;

/**
 * Created by ${GY} on 2018/5/8
 * des：
 */
public class MaintainHistoryItem {
    private static final String TAG = "MaintainHistoryItemView_";
    public String id;
    public String maintainDate;
    public String maintainAddress;
    public String maintainPoint;

    public String maintainMiles;

    public String maintainContent1;

    public float maintainServicePoint;
    public float maintainChargePoint;
    public float maintainAttitudePoint;
    public int maintainPosition;

    public boolean maintainShowContent;
    public boolean maintainIsComment;


    public Bundle getArguments() {
        Bundle bundle = new Bundle();
        bundle.putFloat(MaintainConstant.MAINTAIN_SERVICE_POINT, maintainServicePoint);
        bundle.putFloat(MaintainConstant.MAINTAIN_ATTITUDE_POINT, maintainAttitudePoint);
        bundle.putFloat(MaintainConstant.MAINTAIN_CHARGE_POINT, maintainChargePoint);
        bundle.putString(MaintainConstant.MAINTAIN_HISTORY_POSITION_ITEM_ID, id);
        return bundle;
    }
}
