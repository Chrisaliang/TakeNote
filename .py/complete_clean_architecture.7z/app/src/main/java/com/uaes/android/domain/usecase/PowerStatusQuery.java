package com.uaes.android.domain.usecase;

import com.uaes.android.domain.JobThread;
import com.uaes.android.domain.PowerDefenderRepository;
import com.uaes.android.domain.SingleUseCase;
import com.uaes.android.domain.entity.DMPowerStatus;

import io.reactivex.Single;
import io.reactivex.functions.Function;

public class PowerStatusQuery extends SingleUseCase<DMPowerStatus> {

    private PowerDefenderRepository repository;

    private JobThread jobThread;

    public PowerStatusQuery(PowerDefenderRepository repository, JobThread jobThread) {
        this.repository = repository;
        this.jobThread = jobThread;
    }

    @Override
    protected Single<DMPowerStatus> buildSingle() {
        return Single.just(repository).map(new Function<PowerDefenderRepository, DMPowerStatus>() {
            @Override
            public DMPowerStatus apply(PowerDefenderRepository powerDefenderRepository) throws Exception {
                return repository.queryPowerStatus();
            }
        }).subscribeOn(jobThread.provideWorker()).observeOn(jobThread.providerUi());
    }
}
