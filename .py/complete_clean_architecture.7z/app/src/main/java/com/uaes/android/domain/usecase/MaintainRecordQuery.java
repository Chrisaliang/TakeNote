package com.uaes.android.domain.usecase;

import com.uaes.android.domain.JobThread;
import com.uaes.android.domain.MaintainRepository;
import com.uaes.android.domain.SingleUseCase;
import com.uaes.android.domain.entity.DMMaintainRecord;

import java.util.List;

import io.reactivex.Single;
import io.reactivex.functions.Function;

/**
 * 保养秘书- 保养记录查询
 */
public class MaintainRecordQuery extends SingleUseCase<List<DMMaintainRecord>> {

    private MaintainRepository repository;

    private JobThread jobThread;

    public MaintainRecordQuery(MaintainRepository repository, JobThread jobThread) {
        this.repository = repository;
        this.jobThread = jobThread;
    }

    @Override
    protected Single<List<DMMaintainRecord>> buildSingle() {
        return Single.just(repository).map(new Function<MaintainRepository, List<DMMaintainRecord>>() {
            @Override
            public List<DMMaintainRecord> apply(MaintainRepository repository) throws Exception {
                return repository.queryRecord();
            }
        }).subscribeOn(jobThread.provideWorker()).observeOn(jobThread.providerUi());
    }
}
