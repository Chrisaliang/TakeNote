package com.uaes.android.domain;

import android.support.annotation.IntDef;

import com.uaes.android.domain.aggregation.ARFuelMonitor;
import com.uaes.android.domain.entity.DMFuelFillHistory;
import com.uaes.android.domain.entity.DMFuelScale;
import com.uaes.android.domain.entity.DMFuelSetting;
import com.uaes.android.domain.entity.DMGas;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.List;

/**
 * 用油会计
 */
public interface FuelHelperRepository {

    int TYPE_FUEL_REAL_TIME = 0;
    /**
     * 近一周
     */
    int TYPE_FUEL_SCALE_WEEK = 1;
    /**
     * 近一月
     */
    int TYPE_FUEL_SCALE_MONTH = 2;
    /**
     * 近100KM
     */
    int TYPE_FUEL_SCALE_100KM = 3;

    /**
     * 近1000KM
     */
    int TYPE_FUEL_SCALE_1000KM = 4;

    /**
     * 出厂至今
     */
    int TYPE_FUEL_SCALE_ALL = 5;

    @Retention(RetentionPolicy.SOURCE)
    @IntDef({
            TYPE_FUEL_SCALE_100KM, TYPE_FUEL_SCALE_1000KM,
            TYPE_FUEL_SCALE_MONTH, TYPE_FUEL_SCALE_WEEK,
            TYPE_FUEL_SCALE_ALL, TYPE_FUEL_REAL_TIME
    })
    @interface FuelScaleType {
    }

    /**
     * 按照评价最优的顺序查询加油站列表
     */
    int STRATEGY_GAS_RATE = 2;

    /**
     * 按照耗时最短顺序查询加油站列表
     */
    int STRATEGY_GAS_DURATION = 1;

    /**
     * 按照距离最短顺序查询加油站列表
     */
    int STRATEGY_GAS_DISTANCE = 0;

    @Retention(RetentionPolicy.SOURCE)
    @IntDef(
            {STRATEGY_GAS_RATE, STRATEGY_GAS_DURATION, STRATEGY_GAS_DISTANCE}
    )
    @interface GasQueryStrategy {
    }

    /**
     * 加油站查询查询全部类型，包括中石油中石化
     */
    int FILTER_GAS_ALL = 0;
    /**
     * 只查询中石油
     */
    int FILTER_GAS_CNPC = 1;
    /**
     * 只查询中石化
     */
    int FILTER_GAS_SINOPEC = 2;

    @Retention(RetentionPolicy.SOURCE)
    @IntDef({
            FILTER_GAS_ALL, FILTER_GAS_CNPC, FILTER_GAS_SINOPEC
    })
    @interface GasFilter {
    }

    /**
     * 根据设置的类型来请求用油明细
     *
     * @param type using {@link #TYPE_FUEL_SCALE_100KM}, {@link #TYPE_FUEL_SCALE_1000KM}
     *             {@link #TYPE_FUEL_SCALE_MONTH},{@link #TYPE_FUEL_SCALE_WEEK},
     *             {@link #TYPE_FUEL_SCALE_ALL,}
     */
    DMFuelScale queryFuelScale(@FuelScaleType int type) throws Exception;

    /**
     * 更新用油会计配置
     *
     * @param dmFuelSetting 配置
     */
    boolean updateFuelSetting(DMFuelSetting dmFuelSetting) throws Exception;

    /**
     * 读取当前已经生效的配置
     *
     * @return 返回当前生效的配置
     */
    DMFuelSetting queryFuelSetting() throws Exception;

    /**
     * 请求加油站列表
     *
     * @param latitude  请求的查询中心点纬度.
     * @param longitude 请求的查询中心点的经度.
     * @param strategy  请求策略, 使用{@link #STRATEGY_GAS_DISTANCE},
     *                  {@link #STRATEGY_GAS_DURATION}
     *                  {@link #STRATEGY_GAS_RATE}
     * @return 返回最近的加油站列表
     */
    List<DMGas> queryGasList(double longitude, double latitude, @GasQueryStrategy int strategy) throws Exception;

    /**
     * 获取 用油监控 数据
     */
    ARFuelMonitor queryFuelMonitor() throws Exception;

    /**
     * 获取加油历史列表
     * @param year 查询得年份
     */
    List<DMFuelFillHistory> queryFuelFillHistory(int year) throws Exception;

    /**
     * 针对某次加油记录评分
     */
    DMFuelFillHistory setFuelAccount(DMFuelFillHistory updateItem) throws Exception;

    /**
     * 查询用油记录的可用年份
     */
    List<String> getYears() throws Exception;
}
