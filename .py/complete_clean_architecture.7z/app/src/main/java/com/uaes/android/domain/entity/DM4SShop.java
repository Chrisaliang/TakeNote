package com.uaes.android.domain.entity;

/**
 * 保养站点 (4s店)
 */
public class DM4SShop {
    /**
     * 店名
     */
    public String name;
    /**
     * 电话
     */
    public String phone;
    /**
     * 地址
     */
    public String address;
    /**
     * 坐标经度
     */
    public double longitude;
    /**
     * 坐标纬度
     */
    public double latitude;
}
