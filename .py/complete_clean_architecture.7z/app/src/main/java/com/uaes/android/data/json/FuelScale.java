package com.uaes.android.data.json;

import android.support.annotation.StringDef;

import com.google.gson.annotations.SerializedName;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Fuelscale
 * {
     "msgCode": "10000",
     "msg": "OK",
     "content": {
     dataKey: ["idleUse", "acUse", "driverUse", "otherUse"],
     dataValue: ["10", "17", "69", "4"]
     },
     "status": 1,
     "total": 0
    }
 * */
@SuppressWarnings("ALL")
public class FuelScale {
    /**
     * 怠速消耗
     * */
    public static final String KEY_IDLE_USE = "idleUse";
    /**
     * 空调消耗
     * */
    public static final String KEY_AC_USE = "acUse";
    /**
     * 驾驶消耗
     * */
    public static final String KEY_DRIVER_USE = "driverUse";
    /**
     * 其他消耗
     * */
    public static final String KEY_OTHER_USE = "otherUse";

    @Retention(RetentionPolicy.SOURCE)
    @StringDef({KEY_AC_USE,KEY_DRIVER_USE,KEY_IDLE_USE,KEY_OTHER_USE})
    public @interface KEYS{}

    /**
     * 用油消耗分类
     * */
    @SerializedName("dataKey")
    public String[] dataKey;
    /**
     * 该分类下对应的百分比值字符串
     * */
    @SerializedName("dataValue")
    public String[] dataValue;

    @SerializedName("nowDate")
    public String nowDate;

    @SerializedName("acUse")
    public float acUse;

    @SerializedName("driverUse")
    public float driverUse;

    @SerializedName("idleUse")
    public float idleUse;

    @SerializedName("otherUse")
    public float otherUse;


    public String getValueByKey(@KEYS String key) {
        if (dataKey == null) return null;
        if (key == null) return null;
        for (int i = 0; i < dataKey.length; i++) {
            if (key.equals(dataKey[i])) {
                return dataValue[i];
            }
        }
        return null;
    }

}
