package com.uaes.android.data.mapper;

import android.support.annotation.NonNull;

import com.google.common.base.Function;
import com.uaes.android.data.json.CommonResponse;
import com.uaes.android.data.json.FuelMonitorJson;
import com.uaes.android.domain.aggregation.ARFuelMonitor;
import com.uaes.android.domain.entity.DMAccumulativeFuelConsumption;
import com.uaes.android.domain.entity.DMFuelConsumptionOfDay;
import com.uaes.android.domain.entity.DMFuelScale;

import java.util.Arrays;
import java.util.Comparator;

public class FuelMonitorMapper implements Function<CommonResponse<FuelMonitorJson>, ARFuelMonitor> {

    @Override
    public ARFuelMonitor apply(@NonNull CommonResponse<FuelMonitorJson> input) {
        ARFuelMonitor arFuelMonitor = new ARFuelMonitor();
        arFuelMonitor.rank = input.msgContent.economicRank;

        if (input.msgContent.km.dataKey != null) {
            arFuelMonitor.accumulativeFuelConsumptions
                    = new DMAccumulativeFuelConsumption[input.msgContent.km.dataKey.length];
            for (int i = 0; i < input.msgContent.km.dataKey.length; i++) {
                arFuelMonitor.accumulativeFuelConsumptions[i] =
                        new DMAccumulativeFuelConsumption(
                                Integer.valueOf(input.msgContent.km.dataKey[i]),
                                Float.valueOf(input.msgContent.km.dataValue[i])
                        );
            }
        }

        if (input.msgContent.week.dataKey != null) {
            arFuelMonitor.fuelConsumptionOfDay = new DMFuelConsumptionOfDay[input.msgContent.week.dataKey.length];
            for (int i = 0; i < input.msgContent.week.dataKey.length; i++) {
                arFuelMonitor.fuelConsumptionOfDay[i] =
                        new DMFuelConsumptionOfDay(input.msgContent.week.dataKey[i],
                                Float.valueOf(input.msgContent.week.dataValue[i]),
                                new DMFuelScale(
                                        input.msgContent.week.fuelScales[i].idleUse,
                                        input.msgContent.week.fuelScales[i].acUse,
                                        input.msgContent.week.fuelScales[i].driverUse,
                                        input.msgContent.week.fuelScales[i].otherUse
                                )
                        );
            }
            Arrays.sort(arFuelMonitor.fuelConsumptionOfDay, new Comparator<DMFuelConsumptionOfDay>() {
                @Override
                public int compare(DMFuelConsumptionOfDay o1, DMFuelConsumptionOfDay o2) {
                    return o1.date.compareTo(o2.date);
                }
            });
        }
        return arFuelMonitor;
    }
}
