package com.uaes.android.data.http;

import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import android.text.TextUtils;

import com.google.gson.Gson;
import com.uaes.android.ServiceEnvironment;
import com.uaes.android.common.CarInfoProvider;

import java.io.IOException;

import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * Created by hand on 2017/11/7.
 */

public class HapAuthorizationInterceptor implements Interceptor {

    private static final String KEY_TOKEN = "com.uaes.android.data.http.HapAuthorizationInterceptor.TOKEN";

    private static final String REFRESH_TOKEN = "com.uaes.android.data.http.REFRESH_TOKEN";

    private static final String TOKEN_URL = ServiceEnvironment.BASE_URL + "/car/v1/carAuth/viewAuth?accessKey=";

    private static final String DUMMY_TOKEN = "f22e2de2-f697-46a3-bf9d-0b5bd92e6b57";

    private final SharedPreferences sp;

    private String mToken;

    private OkHttpClient okHttpClient;

    private Gson gson = new Gson();

    private CarInfoProvider authProvider;

    public HapAuthorizationInterceptor(SharedPreferences sharedPreferences, CarInfoProvider authProvider) {
        sp = sharedPreferences;
        this.authProvider = authProvider;
        okHttpClient = new OkHttpClient.Builder().build();
    }

    @Override
    public Response intercept(@NonNull Chain chain) throws IOException {
        if (mToken == null)
            mToken = sp.getString(KEY_TOKEN, null);
        Request newRequest;
        if (TextUtils.isEmpty(mToken)) {
            return chain.proceed(chain.request());
        } else {
            Request.Builder builder = chain.request().newBuilder()
                    .addHeader("Authorization", "Bearer " + mToken);
            newRequest = builder.build();
            return chain.proceed(newRequest);
        }
    }

    public void inValid() {
        sp.edit().remove(KEY_TOKEN).remove(REFRESH_TOKEN)
                .apply();
        mToken = null;
    }
}
