package com.uaes.android.domain;


import android.support.annotation.IntDef;

import com.uaes.android.domain.entity.DMMessageCenterItem;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.List;

import io.reactivex.FlowableEmitter;

/**
 * 消息中心
 */
public interface MessageCenterRepository {

    /**
     * 全部消息
     */
    int MESSAGE_CENTER_QUERY_ALL = 0;

    /**
     * 故障消息
     */
    int MESSAGE_CENTER_QUERY_MALFUNCTION = 1;

    /**
     * 预警消息
     */
    int MESSAGE_CENTER_QUERY_WARNING = 2;

    /**
     * 通知消息
     */
    int MESSAGE_CENTER_QUERY_NOTIFICATION = 3;


    @Retention(RetentionPolicy.SOURCE)
    @IntDef({
            MESSAGE_CENTER_QUERY_ALL, MESSAGE_CENTER_QUERY_MALFUNCTION,
            MESSAGE_CENTER_QUERY_WARNING, MESSAGE_CENTER_QUERY_NOTIFICATION
    })
    @interface MsgType {
    }

    /**
     * 是否接收消息
     *
     * @param msgParaType 指定接收类型 (沿用一期消息推送类型)
     * @return #code true 接收消息
     * #code false 不接收消息
     */
    boolean isReceive(String msgParaType);

    /**
     * 设置是否接收消息
     *
     * @param interpolator 设置器，设置是否接收指定类型的消息
     */
    void setReceive(MessageReceiveInterpolator interpolator);

    /**
     * 根据传入查询类型获取消息列表
     *
     * @param type 查询类型
     * @return 消息列表
     */
    List<DMMessageCenterItem> queryMessage(@MsgType int type);

//    /**
//     * 更新消息
//     *
//     * @return 新添加的消息
//     */
//    Observable<MessageCenterMsgItem> updateMessage();

//    /**
//     * 更新消息
//     *
//     * @param listener 注册监听器通知消息更新
//     */
//    @Deprecated
//    void updateMessage(DMMsgUpdateListener listener);

    /**
     * 更新消息列表
     */
    void updateMessage(FlowableEmitter<DMMessageCenterItem> emitter);
//    ConnectableFlowable<DMMessageCenterItem> updateMessage(DMMessageCenterItem item);

    /**
     * 保存若干条消息
     *
     * @param item 消息
     */
    void onSaveMessage(DMMessageCenterItem... item);

    /**
     * 删除消息
     *
     * @param items 要删除的消息
     * @return 删除数据的数量
     */
    int deleteMessage(DMMessageCenterItem... items);
}
