package com.uaes.android.data.json;

import com.google.gson.annotations.SerializedName;

/**
 * Created by ${GY} on 2018/6/12
 * des：
 */
public class FuelSettingsJson {

    @SerializedName("gasQuery")
    public String type;
    /**
     * 店名
     */
    @SerializedName("CSthreshold")
    public String threShold;
}
