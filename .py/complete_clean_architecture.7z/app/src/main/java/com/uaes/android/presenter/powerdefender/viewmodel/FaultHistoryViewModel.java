package com.uaes.android.presenter.powerdefender.viewmodel;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.arch.lifecycle.MutableLiveData;

import com.uaes.android.R;
import com.uaes.android.domain.Result;
import com.uaes.android.domain.entity.DMPowerReport;
import com.uaes.android.domain.usecase.PowerReportQuery;
import com.uaes.android.presenter.powerdefender.pojo.CarFaultHistory;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;

/**
 * Created by diaokaibin@gmail.com on 2018/5/9.
 */
public class FaultHistoryViewModel extends AndroidViewModel {


    public MutableLiveData<List<CarFaultHistory>> faultItems = new MutableLiveData<>();

    private Disposable mDisposable;
    private PowerReportQuery mReportQuery;

    public FaultHistoryViewModel(Application application, PowerReportQuery reportQuery) {
        super(application);
        this.mReportQuery = reportQuery;
    }


    public void doQuery() {
        mReportQuery.execute().subscribe(new SingleObserver<Result<List<DMPowerReport>>>() {
            @Override
            public void onSubscribe(Disposable d) {
                if (mDisposable != null)
                    mDisposable.dispose();

                mDisposable = d;
            }

            @Override
            public void onSuccess(Result<List<DMPowerReport>> result) {
                upData(result);

            }

            @Override
            public void onError(Throwable throwable) {

            }
        });
    }

    private void upData(Result<List<DMPowerReport>> result) {
        if (result == null) return;
        List<DMPowerReport> content = result.content;
        List<CarFaultHistory> data = new ArrayList<>();
        if (content.size() > 0) {
            for (int i = 0; i < content.size(); i++) {
                DMPowerReport report = content.get(i);
                String status;
                if (report.isResolved) {
                    status = getApplication().getString(R.string.power_tv_title_resolved);
                } else {
                    status = getApplication().getString(R.string.power_tv_title_to_be_solved);
                }
                CarFaultHistory history = new CarFaultHistory(report.problemDescription, report.date, status, report.resolvedDate);
                data.add(history);
            }
            faultItems.setValue(data);

        }
    }


    public void cancleQuery() {
        if (mDisposable != null)
            mDisposable.dispose();
    }
}
