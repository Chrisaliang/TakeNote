package com.uaes.android.presenter.maintainsecretary;

import com.amap.api.navi.AMapNaviListener;
import com.amap.api.navi.model.AMapLaneInfo;
import com.amap.api.navi.model.AMapModelCross;
import com.amap.api.navi.model.AMapNaviCameraInfo;
import com.amap.api.navi.model.AMapNaviCross;
import com.amap.api.navi.model.AMapNaviInfo;
import com.amap.api.navi.model.AMapNaviLocation;
import com.amap.api.navi.model.AMapNaviTrafficFacilityInfo;
import com.amap.api.navi.model.AMapServiceAreaInfo;
import com.amap.api.navi.model.AimLessModeCongestionInfo;
import com.amap.api.navi.model.AimLessModeStat;
import com.amap.api.navi.model.NaviInfo;
import com.autonavi.tbt.TrafficFacilityInfo;
import com.uaes.android.presenter.BaseFragment;

/**
 * Created by ${GY} on 2018/5/11
 * des：
 */
public class MaintainBaseFragment extends BaseFragment implements AMapNaviListener {

    MaintainNavigator mNavigator;

    @Override
    public void onInitNaviFailure() {

    }

    @Override
    public void onInitNaviSuccess() {

    }

    @Override
    public void onStartNavi(int i) {

    }

    @Override
    public void onTrafficStatusUpdate() {

    }

    @Override
    public void onLocationChange(AMapNaviLocation location) {

    }

    @Override
    public void onGetNavigationText(int i, String s) {

    }

    @Override
    public void onGetNavigationText(String s) {

    }

    @Override
    public void onEndEmulatorNavi() {

    }

    @Override
    public void onArriveDestination() {

    }

    @Override
    public void onCalculateRouteFailure(int i) {

    }

    @Override
    public void onReCalculateRouteForYaw() {

    }

    @Override
    public void onReCalculateRouteForTrafficJam() {

    }

    @Override
    public void onArrivedWayPoint(int i) {

    }

    @Override
    public void onGpsOpenStatus(boolean b) {

    }

    @Override
    public void onNaviInfoUpdate(NaviInfo info) {

    }

    @Override
    public void onNaviInfoUpdated(AMapNaviInfo info) {

    }

    @Override
    public void updateCameraInfo(AMapNaviCameraInfo[] infos) {

    }

    @Override
    public void updateIntervalCameraInfo(AMapNaviCameraInfo info, AMapNaviCameraInfo info1, int i) {

    }

    @Override
    public void onServiceAreaUpdate(AMapServiceAreaInfo[] infos) {

    }

    @Override
    public void showCross(AMapNaviCross cross) {

    }

    @Override
    public void hideCross() {

    }

    @Override
    public void showModeCross(AMapModelCross cross) {

    }

    @Override
    public void hideModeCross() {

    }

    @Override
    public void showLaneInfo(AMapLaneInfo[] infos, byte[] bytes, byte[] bytes1) {

    }

    @Override
    public void showLaneInfo(AMapLaneInfo info) {

    }

    @Override
    public void hideLaneInfo() {

    }

    @Override
    public void onCalculateRouteSuccess(int[] ints) {

    }

    @Override
    public void notifyParallelRoad(int i) {

    }

    @Override
    public void OnUpdateTrafficFacility(AMapNaviTrafficFacilityInfo info) {

    }

    @Override
    public void OnUpdateTrafficFacility(AMapNaviTrafficFacilityInfo[] infos) {

    }

    @Override
    public void OnUpdateTrafficFacility(TrafficFacilityInfo info) {

    }

    @Override
    public void updateAimlessModeStatistics(AimLessModeStat stat) {

    }

    @Override
    public void updateAimlessModeCongestionInfo(AimLessModeCongestionInfo info) {

    }

    @Override
    public void onPlayRing(int i) {

    }
}
