package com.uaes.android.presenter.message;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.uaes.android.domain.Result;
import com.uaes.android.domain.entity.DMMessageCenterItem;
import com.uaes.android.domain.usecase.MessageCenterMsgDelete;
import com.uaes.android.domain.usecase.MessageCenterMsgQuery;
import com.uaes.android.domain.usecase.MessageCenterMsgUpdate;

import org.reactivestreams.Subscription;

import java.util.List;

import io.reactivex.FlowableSubscriber;
import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

public class MessageCenterViewModel extends ViewModel implements SingleObserver<Result<List<DMMessageCenterItem>>> {


    private static final String TAG = "MessageCenterViewModel";
    public final MutableLiveData<Integer> selected = new MutableLiveData<>();

    //    private MessageMapper mapper;
    private MsgMapper mapper;
    private MessageCenterMsgQuery msgQuery;
    private MessageCenterMsgUpdate msgUpdate;
    private MessageCenterMsgDelete msgDelete;
    private MutableLiveData<List<MessageCenterMsgItem>> messageItems = new MutableLiveData<>();
    private MutableLiveData<MessageCenterMsgItem> updateMessageItem = new MutableLiveData<>();
    private Disposable disposable;
//    private Disposable updateDisposable;

    private Subscription subscription;

    public MessageCenterViewModel(MessageCenterMsgQuery msgQuery, MessageCenterMsgUpdate msgUpdate,
                                  MessageCenterMsgDelete msgDelete) {
        this.msgQuery = msgQuery;
        this.msgUpdate = msgUpdate;
        this.msgDelete = msgDelete;
        mapper = new MsgMapper();
//        mapper = new MessageMapper();
    }

    public MutableLiveData<List<MessageCenterMsgItem>> getMessageItems() {
        return messageItems;
    }

    public MutableLiveData<MessageCenterMsgItem> getUpdateMessageItem() {
        return updateMessageItem;
    }

    public void updateMessage() {
        updateMessage(0);
    }

    public void updateMessage(int type) {

        if (selected.getValue() != null && selected.getValue() == type) return;

        selected.setValue(type);

        msgQuery.setMessageType(type);

        msgQuery.execute().subscribe(this);
    }

    @Override
    public void onSubscribe(Disposable d) {
        checkDisposable();
        disposable = d;
    }

    private void checkDisposable() {
        if (disposable != null)
            disposable.dispose();
    }

    @Override
    public void onSuccess(Result<List<DMMessageCenterItem>> result) {
        messageItems.setValue(mapper.map(result.content));
    }

    @Override
    public void onError(Throwable e) {
        Timber.tag(TAG).d(e);
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        checkDisposable();
    }

    public void subscribe() {

//        msgUpdate.setListener(listener);

//        msgUpdate.execute();

        msgUpdate.execute().subscribe(new FlowableSubscriber<DMMessageCenterItem>() {
            @Override
            public void onSubscribe(Subscription s) {
                subscription = s;
                s.request(Integer.MAX_VALUE);
            }

            @Override
            public void onNext(DMMessageCenterItem dmMessageCenterItem) {
                MessageCenterMsgItem item = mapper.map(dmMessageCenterItem);
                updateMessageItem.setValue(item);
            }

            @Override
            public void onError(Throwable t) {
                Timber.tag(TAG).e(t);
            }

            @Override
            public void onComplete() {
                Timber.tag(TAG).d("onComplete");
            }
        });

//        msgUpdate.execute().subscribe(new Observer<MessageCenterMsgItem>() {
//            @Override
//            public void onSubscribe(Disposable d) {
//                checkUpdateDisposable();
//                updateDisposable = d;
//            }
//
//            @Override
//            public void onNext(MessageCenterMsgItem item) {
////                updateMessageItem.setValue(item);
//            }
//
//            @Override
//            public void onError(Throwable e) {
//                Timber.tag(TAG).e(e);
//            }
//
//            @Override
//            public void onComplete() {
//                Timber.tag(TAG).d("onComplete");
//            }
//        });
    }

    public void unSubscribe() {
        if (subscription != null)
            subscription.cancel();
//        msgUpdate.setListener(null);
//        checkUpdateDisposable();
    }

    public void removeItem(MessageCenterMsgItem item) {
        msgDelete.setDeleteItems(mapper.map(item));

        msgDelete.execute().subscribe();
    }

//    private void checkUpdateDisposable() {
//        if (updateDisposable != null && !updateDisposable.isDisposed())
//            updateDisposable.dispose();
//    }
}
