package com.uaes.android.domain.entity;

import android.support.annotation.IntRange;

import java.util.List;

/**
 * 保养记录
 */
public class DMMaintainRecord {
    /**
     * 保养记录 ID
     *
     * @see DMMaintainRating#id  它们是相同的
     */
    public String id;
    /**
     * 店名
     */
    public String name;

    /**
     * 保养时间 格式 2018-03-31 17:30
     */
    public String time;
    /**
     * 进店里程
     */
    public int mile;
    /**
     * 保养内容
     */
    public List<String> maintainContents;
    /**
     * 服务高效度
     */
    @SuppressWarnings("WeakerAccess")
    @IntRange(from = -1, to = 5)
    public int serviceRating = -1;

    /**
     * 态度友好
     */
    @IntRange(from = -1, to = 5)
    @SuppressWarnings("WeakerAccess")
    public int attitudeRating = -1;

    /**
     * 收费透明
     */
    @IntRange(from = -1, to = 5)
    @SuppressWarnings("WeakerAccess")
    public int transparencyOfFeesRate = -1;


    /**
     * 是否已经评分
     */
    public boolean isRating() {
        return getRating() >= 0;
    }

    /**
     * 获取平均分
     */
    @SuppressWarnings("WeakerAccess")
    public float getRating() {
        float sum = transparencyOfFeesRate
                + serviceRating + attitudeRating;
        return sum / 3;
    }

}
