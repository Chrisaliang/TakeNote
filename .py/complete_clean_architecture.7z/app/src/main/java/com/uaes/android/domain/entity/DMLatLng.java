package com.uaes.android.domain.entity;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * domain latLng position
 */
@SuppressWarnings({"WeakerAccess", "unused"})
public class DMLatLng implements Parcelable, Cloneable {

    public static final Creator<DMLatLng> CREATOR = new Creator<DMLatLng>() {
        @Override
        public DMLatLng createFromParcel(Parcel in) {
            return new DMLatLng(in);
        }

        @Override
        public DMLatLng[] newArray(int size) {
            return new DMLatLng[size];
        }
    };
    public double lat;
    public double lng;

    public DMLatLng() {
    }

    public DMLatLng(double lat, double lng) {
        this.lat = lat;
        this.lng = lng;
    }

    protected DMLatLng(Parcel in) {
        lat = in.readDouble();
        lng = in.readDouble();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeDouble(lat);
        dest.writeDouble(lng);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public String toString() {
        return "DMLatLng{" +
                "lat=" + lat +
                ", lng=" + lng +
                '}';
    }
}
