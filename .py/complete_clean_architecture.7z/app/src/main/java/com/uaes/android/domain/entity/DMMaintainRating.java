package com.uaes.android.domain.entity;

import android.support.annotation.IntRange;

/**
 * 评价该保养记录
 */
public class DMMaintainRating {

    /**
     * 主要ID 用于更新
     */
    public String id;

    /**
     * 服务高效度
     */
    @SuppressWarnings("WeakerAccess")
    @IntRange(from = 0, to = 5)
    public int serviceRating;

    /**
     * 态度友好
     */
    @IntRange(from = 0, to = 5)
    @SuppressWarnings("WeakerAccess")
    public int attitudeRating;

    /**
     * 收费透明
     */
    @IntRange(from = 0, to = 5)
    @SuppressWarnings("WeakerAccess")
    public int transparencyOfFeesRate;
}
