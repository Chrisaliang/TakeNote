package com.uaes.android.presenter.message;

import com.uaes.android.domain.entity.DMMessageCenterItem;

import java.util.ArrayList;
import java.util.List;

public class MsgMapper {

    public MessageCenterMsgItem map(DMMessageCenterItem dmMessageCenterItem) {
        MessageCenterMsgItem item = new MessageCenterMsgItem();
        item.msgContent = dmMessageCenterItem.msgContent;
        item.msgTime = dmMessageCenterItem.msgTime;
        item.id = dmMessageCenterItem.id;
        return item;
    }

    public List<MessageCenterMsgItem> map(List<DMMessageCenterItem> dmMessageCenterItems) {
        List<MessageCenterMsgItem> items = new ArrayList<>(dmMessageCenterItems.size() * 5 / 3);
        for (DMMessageCenterItem dmMessageCenterItem : dmMessageCenterItems) {
            items.add(map(dmMessageCenterItem));
        }
        return items;
    }

    public DMMessageCenterItem map(MessageCenterMsgItem item) {
        DMMessageCenterItem dmMessageCenterItem = new DMMessageCenterItem();
        dmMessageCenterItem.id = item.id;
        dmMessageCenterItem.msgTime = item.msgTime;
        dmMessageCenterItem.msgContent = item.msgContent;
        return dmMessageCenterItem;
    }
}
