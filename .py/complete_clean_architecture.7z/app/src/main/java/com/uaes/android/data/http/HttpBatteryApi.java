package com.uaes.android.data.http;

import com.uaes.android.data.json.BatteryStatusJson;
import com.uaes.android.data.json.BatteryVolJson;
import com.uaes.android.data.json.CommonResponse;

import retrofit2.Call;
import retrofit2.http.GET;

public interface HttpBatteryApi {
    /**
     * 读取电池状态接口
     */
    @GET("battery/v1/battery/life")
    Call<CommonResponse<BatteryStatusJson>> queryBatterStatus();

    /**
     * 读取电池电量
     */
    @GET("battery/v1/battery/power")
    Call<CommonResponse<BatteryVolJson>> queryBatteryVol();
}
