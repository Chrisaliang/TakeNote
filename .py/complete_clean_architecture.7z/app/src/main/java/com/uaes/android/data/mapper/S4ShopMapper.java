package com.uaes.android.data.mapper;

import android.support.annotation.NonNull;

import com.uaes.android.data.json.S4ShopJson;
import com.uaes.android.domain.entity.DM4SShop;

public class S4ShopMapper {

    public static DM4SShop map(@NonNull S4ShopJson json) {
        DM4SShop dm4SShop = new DM4SShop();
        dm4SShop.latitude = json.latitude;
        dm4SShop.longitude = json.longitude;
        dm4SShop.name = json.name;
        dm4SShop.phone = json.serviceTel;
        dm4SShop.address = json.serviceAddress;
        return dm4SShop;
    }
}
