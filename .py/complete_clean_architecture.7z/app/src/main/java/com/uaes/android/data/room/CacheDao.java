package com.uaes.android.data.room;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.OnConflictStrategy;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Transaction;

@SuppressWarnings("WeakerAccess")
@Dao
public abstract class CacheDao {


    // **************************** query **************************** //

    /**
     * 获取全部消息
     *
     * @return 消息列表
     */
    @Query("SELECT * FROM " + Tables.MessageCenter.TABLE_NAME + " ORDER BY " +
            Tables.MessageCenter.COLUMN_TIME_STAMP + " DESC")
    public abstract MessageCenterEntity[] queryAllMessage();

    /**
     * 查询指定类型的消息列表
     *
     * @param type 消息类型
     * @return 消息列表
     */
    @Query("SELECT * FROM " + Tables.MessageCenter.TABLE_NAME + " WHERE "
            + Tables.MessageCenter.COLUMN_TYPE + " = :type" + " ORDER BY " +
            Tables.MessageCenter.COLUMN_TIME_STAMP + " DESC")
    public abstract MessageCenterEntity[] queryMessages(int type);

    /**
     * 查询数据库数量
     *
     * @return 数据总数
     */
    @Query("SELECT count(*) FROM " + Tables.MessageCenter.TABLE_NAME)
    public abstract int countMessage();

    /**
     * 查询数据库第一条记录
     *
     * @return 第一条数据
     */
    @Query("SELECT * FROM " + Tables.MessageCenter.TABLE_NAME + " LIMIT 1")
    public abstract MessageCenterEntity queryFirst();


    // ************************  insert and update ********************** //

    /**
     * 插入消息
     *
     * @param entities 消息实体
     */
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public abstract long[] insertMessage(MessageCenterEntity... entities);

    /**
     * 插入消息 当数据库消息数量达到256条时，删除最早的一条
     *
     * @param entities 要插入的数据
     * @return 插入的数据列id
     */
    @Transaction
    @SuppressWarnings("UnusedReturnValue")
    public long[] insertMessageCenter(MessageCenterEntity... entities) {
        if (countMessage() == 256) {
            deleteMessageItem(queryFirst());
        }
        return insertMessage(entities);
    }


//    public long[] updateMessage(MessageCenterEntity... entities) {
//        return insertMessageCenter(entities);
//    }

    // ************************** delete ****************************** //

    /**
     * 删除若干消息
     *
     * @param entities 要删除的对象
     * @return 删除行的数量
     */
    @Delete
    public abstract int deleteMessageItem(MessageCenterEntity... entities);
}
