package com.uaes.android.presenter.driver;

import android.support.annotation.DrawableRes;

import com.amap.api.maps.model.LatLng;

public class DriverMasterDetailItem {

    public String time;

    @DrawableRes
    public int locationIcon;

    @DrawableRes
    public int ratingRes;

    public String locationStr;

    public int dangerousRank;

    public String duration;

    public LatLng[] locations;
}
