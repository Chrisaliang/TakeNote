package com.uaes.android.data.json;


import com.google.gson.annotations.SerializedName;

import java.util.Date;

/**
 * 驾驶达人 详细列表json
 */
public class DriverMasterDetailJson {

    //      {
    //            "vin": "LNBSCUAK5HF043610",
    //            "targetType": 1,
    //            "gps": "121.627647,31.27038",
    //            "location": "联合汽车电子有限公司北门",
    //            "occurTime": "2018-05-16 13:56:05",
    //            "dangerLevel": 5,
    //            "continuedTime": 5
    //        }

    @SerializedName("vin")
    public String vin;

    @SerializedName("targetType")
    public int targetType;

    @SerializedName("gps")
    public String gps;

    @SerializedName("location")
    public String location;

    @SerializedName("occurTime")
    public Date occurTime;

    @SerializedName("dangerLevel")
    public int dangerLevel;

    @SerializedName("continuedTime")
    public long continuedTime;

}
