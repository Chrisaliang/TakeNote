package com.uaes.android.presenter.powerdefender.pojo;

/**
 * Created by diaokaibin@gmail.com on 2018/5/13.
 */
public class CallPhone {
    public String address;
    public String phone;
}
