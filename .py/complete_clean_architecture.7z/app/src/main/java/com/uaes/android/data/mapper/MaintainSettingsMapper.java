package com.uaes.android.data.mapper;

import com.uaes.android.data.json.CommonResponse;
import com.uaes.android.data.json.MaintainSettingJson;
import com.uaes.android.domain.entity.DMMaintainSetting;

import io.reactivex.functions.Function;

/**
 * Created by ${GY} on 2018/5/21
 * des：
 */
public class MaintainSettingsMapper implements Function<CommonResponse<MaintainSettingJson>, DMMaintainSetting> {


    @Override
    public DMMaintainSetting apply(CommonResponse<MaintainSettingJson> maintainSetting) {
        DMMaintainSetting dmMaintainSetting = new DMMaintainSetting();
        dmMaintainSetting.isAllowedPush = maintainSetting.msgContent.isAllowedPush;
        dmMaintainSetting.pushFrequency = maintainSetting.msgContent.pushFrequency - 1;
        dmMaintainSetting.pushType = maintainSetting.msgContent.pushType - 1;
        return dmMaintainSetting;
    }
}
