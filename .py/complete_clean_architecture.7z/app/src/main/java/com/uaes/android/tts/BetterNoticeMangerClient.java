package com.uaes.android.tts;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;

import com.iflytek.autofly.noticemanager.INoticeManager;
import com.iflytek.autofly.noticemanager.NoticeParam;

import timber.log.Timber;

import static android.content.Context.BIND_AUTO_CREATE;


public class BetterNoticeMangerClient {

    public static final int NOTICE_TOAST_ID = 0;
    @SuppressWarnings("WeakerAccess")
    public static final int NOTICE_CHOICE_ID = 1;
    @SuppressWarnings("WeakerAccess")
    public static final int NOTICE_CUSTOM_ID = 2;
    // 优先级最大
    public static final int NOTICE_PRIORITY_POWER = 6;
    // 优先级最大
    public static final int NOTICE_PRIORITY_CARERROR = 5;
    // 优先级别最大
    public static final int NOTICE_PRIORITY_SENDTOCAR = 4;
    public static final int NOTICE_PRIORITY_XPUSH = 3;
    public static final int NOTICE_PRIORITY_UPDATE = 2;
    public static final int NOTICE_PRIORITY_APP = 1;
    private static final String TAG = "NoticeManagerClient";
    private final String SERVICEACTIONNAME = "com.iflytek.autofly.NoticeService";

    private final int MSG_REBILND = 257;
    private final int MSG_INIT = 258;
    private final int MSG_UNINIT = 259;

    private Context context;

    private INoticeManager mService = null;

    private NoticeListener noticeListener;
    private ServiceConnection mConnection = new ServiceConnection() {
        public void onServiceConnected(ComponentName name, IBinder service) {
            Timber.tag(TAG).d("ServiceIpc | onServiceConnected");
            try {
                mService = INoticeManager.Stub.asInterface(service);
                mHandler.sendEmptyMessage(MSG_INIT);
            } catch (Exception var4) {
                Timber.tag(TAG).e(var4);
            }

        }

        public void onServiceDisconnected(ComponentName name) {
            Timber.tag(TAG).d("ServiceIpc | onServiceDisconnected ComponentName:");
            mHandler.sendEmptyMessage(MSG_UNINIT);
            mHandler.sendEmptyMessage(MSG_REBILND);
        }
    };
    private Handler mHandler = new Handler(Looper.getMainLooper()) {
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case MSG_REBILND:
                    startBindService();
                    break;
                case MSG_INIT:
                    if (null != noticeListener) {
                        noticeListener.onServiceConnected();
                    }
                    break;
                case MSG_UNINIT:
                    if (null != noticeListener) {
                        noticeListener.onServiceDisconnected();
                    }
                    break;
                default:
                    Timber.tag(TAG).d("unknown msg %s", msg.what);
            }

        }
    };

    public BetterNoticeMangerClient(Context context, NoticeListener noticeListener) {
        this.context = context;
        this.noticeListener = noticeListener;
    }

    public void startBindService() {
        Timber.tag(TAG).d("ServiceIpc | startBindService");
        boolean ret = context.bindService(new Intent("com.iflytek.autofly.NoticeService"), mConnection, BIND_AUTO_CREATE);
        if (!ret) {
            this.mHandler.sendEmptyMessage(MSG_REBILND);
        }
    }

    public void stopBindService() {
        if (mConnection == null) return;
        context.unbindService(mConnection);
    }

    public void showNotice(NoticeParam noticeParam) {
        if (null != this.mService) {
            try {
                switch (noticeParam.getFlags()) {
                    case NOTICE_TOAST_ID:
                        this.mService.showToast(noticeParam);
                        break;
                    case NOTICE_CHOICE_ID:
                        noticeParam.setFlags(NOTICE_CHOICE_ID);
                        this.mService.showNotice(noticeParam);
                        break;
                    case NOTICE_CUSTOM_ID:
                        noticeParam.setFlags(NOTICE_CUSTOM_ID);
                        this.mService.showCustomNotice(noticeParam);
                }
            } catch (RemoteException var3) {
                Timber.tag(TAG).e(var3);
            }
        } else {
            Timber.tag(TAG).e("showNotice|service is null");
        }

    }


    /**
     * 消息通知服务 事件接口
     */
    public interface NoticeListener {
        void onServiceConnected();

        void onServiceDisconnected();
    }
}
