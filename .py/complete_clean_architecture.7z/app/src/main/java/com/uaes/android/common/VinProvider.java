package com.uaes.android.common;

import com.google.common.hash.Hashing;
import com.uaes.android.MockCar;

import java.nio.charset.Charset;

import timber.log.Timber;

public class VinProvider implements CarInfoProvider {

    private static final String TAG = "VinProvider";

    private String vinStr;

    private String sha384;

    private String sn;

    public VinProvider() {
        parser(this);
    }

    private static void parser(VinProvider realCarInfoProvider) {
        if (MockCar.MOCK) {
            realCarInfoProvider.vinStr = MockCar.MOCK_VIN;
            realCarInfoProvider.sn = MockCar.MOCK_SN;
        } else {
            realCarInfoProvider.vinStr = PhoneManagerUtils.getAutoId();
            realCarInfoProvider.sn = PhoneManagerUtils.getSerial();
        }
        realCarInfoProvider.sha384 = Hashing.sha384().hashString(
                realCarInfoProvider.vinStr + ":" + realCarInfoProvider.sn,
                Charset.defaultCharset()).toString();
        Timber.tag(TAG).d("vin: %s, sn: %s, sha384: %s",
                realCarInfoProvider.vinStr,
                realCarInfoProvider.sn,
                realCarInfoProvider.sha384);
    }

    @Override
    public String getVin() {
        return vinStr;
    }

    @Override
    public String getSerialNumber() {
        return sn;
    }

    @Override
    public String getSHA384() {
        return sha384;
    }

    @Override
    public String debugString() {
        return toString();
    }

    @Override
    public String toString() {
        return "RealCarInfoProvider{" +
                "vinStr='" + vinStr + '\'' +
                ", sha384='" + sha384 + '\'' +
                ", sn='" + sn + '\'' +
                '}';
    }
}
