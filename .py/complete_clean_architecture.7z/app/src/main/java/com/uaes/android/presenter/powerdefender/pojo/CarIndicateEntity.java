package com.uaes.android.presenter.powerdefender.pojo;

/**
 * Created by diaokaibin@gmail.com on 2018/5/7.
 */
public class CarIndicateEntity {


    /**
     * 0 显示ok
     * 1 warning
     * 2 图片不显示,显示数字
     */

    public int index;
    public int carIndicateStatus;
    public String faultCount;

    public CarIndicateEntity() {
    }

    public CarIndicateEntity(int index, int carIndicateStatus, String faultCount) {
        this.index = index;
        this.carIndicateStatus = carIndicateStatus;
        this.faultCount = faultCount;
    }

}
