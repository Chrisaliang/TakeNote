package com.uaes.android.presenter.maintainsecretary;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.uaes.android.R;
import com.uaes.android.databinding.MaintainFragmentSettingsBinding;

import javax.inject.Inject;

import timber.log.Timber;

/**
 * Created by ${GY} on 2018/5/7
 * des：
 */
public class MaintainSettingsFragment extends MaintainBaseFragment {
    private static final String TAG = "MaintainSettingsFragmen";
    private MaintainFragmentSettingsBinding binding;
    @Inject
    ViewModelProvider.Factory factory;
    private MaintainSettingsViewModel maintainSettingsViewModel;

    private Observer<Boolean> saveStatus = new Observer<Boolean>() {
        @Override
        public void onChanged(@Nullable Boolean aBoolean) {
            Timber.tag(TAG).d("saveResult:%s", aBoolean);
            //noinspection ConstantConditions
            if (aBoolean) {
                Toast.makeText(getContext(), "保存成功", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getContext(), "保存失败", Toast.LENGTH_SHORT).show();
            }
            mNavigator.onBack();
        }
    };


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        maintainSettingsViewModel = ViewModelProviders.of(this, factory)
                .get(MaintainSettingsViewModel.class);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater,
                R.layout.maintain_fragment_settings,
                container, false);
        binding.setLifecycleOwner(this);
        maintainSettingsViewModel.getSaveStatus().observe(this, saveStatus);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding.setNavigator(mNavigator);
        binding.setListener(maintainSettingsViewModel);
        binding.setMaintainSettingsViewModel(maintainSettingsViewModel);

    }

    @Override
    public void onStart() {
        super.onStart();
        maintainSettingsViewModel.querySettings();
    }

    @Override
    public void onStop() {
        super.onStop();
        maintainSettingsViewModel.unSubscribe();
    }
}
