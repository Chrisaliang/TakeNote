package com.uaes.android.data.json;

import com.google.gson.annotations.SerializedName;

import java.util.List;
import java.util.Map;

/**
 * 驾驶达人 页面类
 */
public class DriverMasterPageJson {

    @SerializedName("drivingStyle")
    public DrivingStyle drivingLevel;

    @SerializedName("metrics")
    public List<Map<String, Integer>> metricsRatio;

    public class DrivingStyle {

        @SerializedName("drivingCode")
        public String drivingCode;

        @SerializedName(value = "drivingDescription", alternate = {"drivingDescprition"})
        public String drivingDescription;

        @SerializedName("drivingStyle")
        public String drivingStyle;
    }

//    class MetricsRatio {
//        /**
//         * 急加速
//         */
//        @SerializedName("1")
//        public int acuteAcc;
//
//        /**
//         * 急刹车
//         */
//        @SerializedName("2")
//        public int acuteBreak;
//
//        /**
//         * 急转弯
//         */
//        @SerializedName("3")
//        public int acuteTurn;
//
//        /**
//         * 连续加减速
//         */
//        @SerializedName("4")
//        public int continueAccAndDec;
//
//        /**
//         * 凌晨驾驶
//         */
//        @SerializedName("5")
//        public int nightDriver;
//    }
}
