package com.uaes.android.presenter.powerdefender.fragment;

import com.uaes.android.presenter.BaseFragment;
import com.uaes.android.presenter.powerdefender.PowerNavigator;

/**
 * Created by diaokaibin@gmail.com on 2018/6/5.
 */
public class PowerDefenderBaseFragment extends BaseFragment {

    protected PowerNavigator mNavigator;
}
