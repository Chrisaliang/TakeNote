package com.uaes.android.presenter.maintainsecretary;

import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.content.Intent;
import android.databinding.DataBindingUtil;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.widget.LinearLayoutManager;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.amap.api.maps.AMap;
import com.amap.api.maps.CameraUpdateFactory;
import com.amap.api.maps.MapView;
import com.amap.api.maps.UiSettings;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.LatLngBounds;
import com.amap.api.maps.model.MarkerOptions;
import com.amap.api.navi.AMapNavi;
import com.amap.api.navi.model.AMapNaviPath;
import com.amap.api.navi.model.AMapNaviStep;
import com.amap.api.navi.model.NaviLatLng;
import com.amap.api.navi.model.RouteOverlayOptions;
import com.amap.api.navi.view.RouteOverLay;
import com.uaes.android.R;
import com.uaes.android.databinding.MaintainFragmentDriveSchemeBinding;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

import javax.inject.Inject;

import timber.log.Timber;

import static com.uaes.android.presenter.maintainsecretary.MaintainConstant.MAINTAIN_NAVIGATION_TYPE;

/**
 * Created by ${GY} on 2018/5/10
 * des：
 */
public class MaintainDriveSchemeFragment extends MaintainBaseFragment implements MaintainOnClickListener {
    private static final String TAG = "MaintainDriveSchemeFrag";
    //    private static final int ROUTE_TYPE_DRIVE = 2;
    private MaintainFragmentDriveSchemeBinding binding;
    private MaintainDriveSchemeAdapter maintainDriveSchemeAdapter;
    @Inject
    ViewModelProvider.Factory factory;
    private List<AMapNaviPath> list = new ArrayList<>();
    private NaviLatLng mStartPoint;//起点
    private NaviLatLng mEndPoint;//终点
    private AMap aMap;
    private ArrayList<MarkerOptions> markerOptions = new ArrayList<>();
    private AMapNavi aMapNavi;
    private Bitmap startBitmap;
    private Bitmap endBitmap;
    private int currentOverlay = 0;
    private int colorLight[] = new int[]{Color.parseColor("#0299E8"),
            Color.parseColor("#0299E8"), Color.parseColor("#0299E8"),
            Color.parseColor("#0299E8"), Color.parseColor("#0299E8")};
    private int colorDark[] = new int[]{Color.parseColor("#30000000"),
            Color.parseColor("#30000000"), Color.parseColor("#30000000"),
            Color.parseColor("#30000000"), Color.parseColor("#30000000")};
    private RouteOverlayOptions overlayOptions = new RouteOverlayOptions();
    private List<RouteOverLay> overLays = new ArrayList<>();
    private int inputType = 0;
    private String address;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater,
                R.layout.maintain_fragment_drive_scheme, container, false);
        binding.setLifecycleOwner(this);
        if (aMap == null) {
            MapView mapView = binding.mapview;
            aMap = mapView.getMap();
        }
        aMapNavi = AMapNavi.getInstance(getContext());
        aMapNavi.addAMapNaviListener(this);

        initMap();
        initBitmap();
        return binding.getRoot();
    }

    private void initBitmap() {
        startBitmap = BitmapFactory.decodeResource(getResources(),
                R.drawable.ic_map_start);
        endBitmap = BitmapFactory.decodeResource(getResources(),
                R.drawable.ic_map_end);
    }

    private void initMap() {
        aMap.setMyLocationEnabled(false);
        UiSettings uiSettings = aMap.getUiSettings();
        uiSettings.setZoomControlsEnabled(false);
        uiSettings.setMyLocationButtonEnabled(false);
        uiSettings.setAllGesturesEnabled(true);
        uiSettings.setLogoBottomMargin(-50);
        aMap.animateCamera(CameraUpdateFactory.zoomTo(13));
        aMap.setMapCustomEnable(true);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        MaintainDriveSchemeViewModel maintainDriveSchemeViewModel = ViewModelProviders
                .of(this).get(MaintainDriveSchemeViewModel.class);
        binding.setMaintainDriveSchemeViewModel(maintainDriveSchemeViewModel);
        binding.setMaintainOnClickListener(this);
        binding.mapview.onCreate(savedInstanceState);
        initAdapter();
        getlatData();
    }

    private void initAdapter() {
        if (maintainDriveSchemeAdapter == null) {
            maintainDriveSchemeAdapter = new MaintainDriveSchemeAdapter();
            maintainDriveSchemeAdapter.setMaintainSchemeItemOnClickListener(new MaintainDriveSchemeAdapter.MaintainSchemeItemOnClickListener() {
                @Override
                public void onSchemeItemClick(int position) {
                    showOverlay(position);
                }
            });
        }
        binding.rclDriveScheme.setLayoutManager(new LinearLayoutManager(getActivity()));
        binding.rclDriveScheme.setAdapter(maintainDriveSchemeAdapter);
    }

    private void getlatData() {
        Bundle bundle = getArguments();
        if (bundle != null) {
            mStartPoint = new NaviLatLng(bundle.getDouble(MaintainConstant.MAINTAIN_CURRENT_LATITUDE), bundle.getDouble(MaintainConstant.MAINTAIN_CURRENT_LONGITUDE));
            mEndPoint = new NaviLatLng(bundle.getDouble(MaintainConstant.MAINTAIN_LATITUDE), bundle.getDouble(MaintainConstant.MAINTAIN_LONGITUDE));
            address = bundle.getString(MaintainConstant.MAINTAIN_ADDRESS);
            inputType = bundle.getInt(MAINTAIN_NAVIGATION_TYPE);
            Timber.tag(TAG).w("CURRENT_LATITUDE：" + bundle.getDouble(MaintainConstant.MAINTAIN_CURRENT_LATITUDE) +
                    "CURRENT_LONGITUDE：" + bundle.getDouble(MaintainConstant.MAINTAIN_CURRENT_LONGITUDE) +
                    "MAINTAIN_LATITUDE：" + bundle.getDouble(MaintainConstant.MAINTAIN_LATITUDE) +
                    "MAINTAIN_LONGITUDE：" + bundle.getDouble(MaintainConstant.MAINTAIN_LONGITUDE)
            );
        }
    }

    @Override
    public void onInitNaviSuccess() {
        super.onInitNaviSuccess();
        Timber.tag(TAG).w("onInitNaviSuccess");
        int strategy = 0;
        try {
            strategy = aMapNavi.strategyConvert(true, false, false, false, true);
        } catch (Exception e) {
            e.printStackTrace();
        }
        List<NaviLatLng> start = new ArrayList<>();
        start.add(mStartPoint);
        List<NaviLatLng> end = new ArrayList<>();
        end.add(mEndPoint);
        aMapNavi.calculateDriveRoute(start, end, null, strategy);
    }

    @Override
    public void onInitNaviFailure() {
        super.onInitNaviFailure();
        Timber.tag(TAG).w("onInitNaviFailure");
    }

    @Override
    public void onCalculateRouteSuccess(int[] ints) {
        Timber.tag(TAG).w("onCalculateRouteSuccess : ");
        super.onCalculateRouteSuccess(ints);
        HashMap<Integer, AMapNaviPath> naviPaths = aMapNavi.getNaviPaths();
        list.clear();
        for (int key : naviPaths.keySet()) {
            list.add(naviPaths.get(key));
        }
        initPlanObserver(list);
    }

    @Override
    public void onCalculateRouteFailure(int i) {
        super.onCalculateRouteFailure(i);
        Timber.tag(TAG).e("onCalculateRouteFailure : %s", i);
    }

    private void initPlanObserver(List<AMapNaviPath> list) {

        AMapNaviPath aMapNaviPath;
        if (list != null && list.size() > 0) {
            List<MaintainDriveSchemeItem> routeList = new ArrayList<>();


            for (int i = 0; i < list.size(); i++) {
                aMapNaviPath = list.get(i);
                int distance = aMapNaviPath.getAllLength();
                int time = aMapNaviPath.getAllTime();
                int traffic_light = aMapNaviPath.getLightList().size();

                MaintainDriveSchemeItem item = new MaintainDriveSchemeItem();
                item.minutes = String.valueOf(MaintainAMapUtil.getFriendlyTime(time));
                item.miles = String.valueOf(MaintainAMapUtil.getFriendlyLength(distance));
                item.lightNumbers = String.valueOf(traffic_light);
                if (i == 0) {
                    item.isChoice = true;
                }
                item.position = i;

                StringBuilder road = new StringBuilder("");
                for (int j = 0; j < aMapNaviPath.getSteps().size(); j++) {
                    AMapNaviStep step = aMapNaviPath.getSteps().get(j);
                    String roadNameTemp = "";
                    for (int z = 0; z < step.getLinks().size(); z++) {
                        String roadName = step.getLinks().get(z).getRoadName();
                        if (z > 0) roadNameTemp = step.getLinks().get(z - 1).getRoadName();
                        if (!TextUtils.equals(roadName, roadNameTemp)) {
                            road.append(TextUtils.isEmpty(roadName) ? "未知" : roadName);
                            if (j == aMapNaviPath.getSteps().size() - 1 && z == step.getLinks().size() - 1)
                                road.append("");
                            else road.append(">");
                        }
                    }
                }
                item.detailPassWay = road.toString();
                routeList.add(item);
            }
            maintainDriveSchemeAdapter.updateALL(routeList);
            drawRoutes(list);
        }
    }

    private void drawRoutes(List<AMapNaviPath> list) {
        aMap.clear();
        overLays.clear();
        for (int i = 0; i < list.size(); i++) {
            RouteOverLay routeOverLay = new RouteOverLay(aMap, list.get(i), getContext());
            routeOverLay.setTrafficLine(false);

            overlayOptions.setLineWidth(14f);
            routeOverLay.setRouteOverlayOptions(overlayOptions);
            routeOverLay.setStartPointBitmap(startBitmap);
            routeOverLay.setEndPointBitmap(endBitmap);

            overLays.add(routeOverLay);
            if (i == 0) routeOverLay.addToMap(colorLight, list.get(i).wayPointIndex);
            else routeOverLay.addToMap(colorDark, list.get(i).wayPointIndex);
        }
        overLays.get(0).zoomToSpan();

        NaviLatLng startPoint = overLays.get(0).getAMapNaviPath().getStartPoint();
        NaviLatLng endPoint = overLays.get(0).getAMapNaviPath().getEndPoint();

        LatLngBounds.Builder builder = LatLngBounds.builder();
        builder.include(new LatLng(startPoint.getLatitude(), startPoint.getLongitude()))
                .include(new LatLng(endPoint.getLatitude(), endPoint.getLongitude()));

        moveCamera(builder);
    }

    private void moveCamera(LatLngBounds.Builder builder) {
        aMap.animateCamera(CameraUpdateFactory.newLatLngBoundsRect(builder.build(), 400, 40, 80, 20));
    }

    @Override
    public void onClick(int type) {
        switch (type) {
            case 0:
                //返回按钮
                if (inputType == 1) {
                    if (getFragmentManager() != null) {
                        getFragmentManager().popBackStack();
                    }
                } else if (inputType == 2) {

                    mNavigator.onBack();
                }
                break;
            case 1:
                //开始导航
                startAuto();
                break;
        }
    }

    private void startAuto() {
        Intent intent = new Intent();
        intent.setAction("AUTONAVI_STANDARD_BROADCAST_RECV");
        intent.putExtra("KEY_TYPE", 10038);
        intent.putExtra("POINAME", address);
        intent.putExtra("LAT", mEndPoint.getLatitude());
        intent.putExtra("LON", mEndPoint.getLongitude());
        intent.putExtra("DEV", 0);
        intent.putExtra("STYLE", 0);
        intent.putExtra("EXTRA_DAY_NIGHT_MODE", 0);
        intent.putExtra("SOURCE_APP", "永不抛锚");
        Objects.requireNonNull(getContext()).sendBroadcast(intent);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding.mapview.onDestroy();
        if (aMapNavi != null) {
            aMapNavi.destroy();
        }

    }

    @Override
    public void onResume() {
        super.onResume();
        binding.mapview.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        binding.mapview.onPause();
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        binding.mapview.onSaveInstanceState(outState);
    }

    private void showOverlay(int selectOverlay) {
        if (currentOverlay == selectOverlay) {
            return;
        }
        overlayOptions.setLineWidth(14f);
        RouteOverLay selectOver = overLays.get(selectOverlay);
        selectOver.removeFromMap();
        selectOver.setRouteOverlayOptions(overlayOptions);
        selectOver.addToMap(colorLight, list.get(selectOverlay).wayPointIndex);//高亮显示

        RouteOverLay currentOver = overLays.get(currentOverlay);
        currentOver.removeFromMap();
        currentOver.setRouteOverlayOptions(overlayOptions);
        currentOver.addToMap(colorDark, list.get(currentOverlay).wayPointIndex);//灰色

        currentOverlay = selectOverlay;

        selectOver.zoomToSpan();

        NaviLatLng startPoint = selectOver.getAMapNaviPath().getStartPoint();
        NaviLatLng endPoint = selectOver.getAMapNaviPath().getEndPoint();

        LatLngBounds.Builder builder = LatLngBounds.builder();
        builder.include(new LatLng(startPoint.getLatitude(), startPoint.getLongitude()))
                .include(new LatLng(endPoint.getLatitude(), endPoint.getLongitude()));

        moveCamera(builder);
    }
}
