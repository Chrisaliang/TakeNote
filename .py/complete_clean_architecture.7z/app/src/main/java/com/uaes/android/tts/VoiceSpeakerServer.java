package com.uaes.android.tts;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.text.TextUtils;

import com.iflytek.autofly.noticemanager.NoticeParam;

import java.util.ArrayList;
import java.util.List;

import timber.log.Timber;

/**
 * 假设前提，核心语音服务内部，为队列
 */
public class VoiceSpeakerServer extends Service implements BetterNoticeMangerClient.NoticeListener {

    private static final String TAG = "VoiceSpeakerServer";

    // play window for cache message.
    private static final int PLAY_WINDOW = 3000;

    private static final int DISMISS_TIME = 3000;

    public static final String EXTRA_VOICE_CONTENT = "com.uaes.android.tts.voice.content";
    public static final String EXTRA_TEXT_CONTENT = "com.uaes.android.tts.text.content";

    private BetterNoticeMangerClient client;

    private List<Message> caches = new ArrayList<>();

    private static final Message MESSAGE
            = new Message("多个故障预警发生，请进入动力管家查看", "多个故障预警发生，请进入动力管家查看");


    private final Object lock = new Object();

    // the play queue in VoiceCoreService is not

    private Runnable scheduleWork = new Runnable() {
        @Override
        public void run() {
            synchronized (lock) {
                if (caches.size() > 2) {
                    play(MESSAGE);
                } else if (caches.size() == 2) {
                    // 假设 科大讯飞系统中的语音服务是队列播放， 本假设待验证
                    play(caches.get(0));
                    play(caches.get(1));
                } else if (caches.size() == 1) {
                    play(caches.get(0));
                }
                caches.clear();
                ACTIVE = false;
            }
        }
    };

    private volatile boolean ACTIVE = false;

    // scheduler for play work
    private HandlerThread workQueue;
    private Handler workHandler;

    @Override
    public void onCreate() {
        super.onCreate();
//        Tts.getInstance(this);
        Timber.tag(TAG).e("onCreate: ");
        // work queue started.
        workQueue = new HandlerThread("mqttMessageLooper");
        workQueue.start();
        workHandler = new Handler(workQueue.getLooper());
        client = new BetterNoticeMangerClient(this, this);
        client.startBindService();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String voiceContent = intent.getStringExtra(EXTRA_VOICE_CONTENT);
            String textContent = intent.getStringExtra(EXTRA_TEXT_CONTENT);
            final Message message = new Message(voiceContent, textContent);
            Timber.tag(TAG).e("onStartCommand: %s", message.toString());
            synchronized (lock) {
                caches.add(message);
                if (!ACTIVE) {
                    // active scheduler
                    ACTIVE = true;
                    workHandler.postDelayed(scheduleWork, PLAY_WINDOW);
                }
            }
        }
        return Service.START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (client != null)
            client.stopBindService();
        if (workQueue != null)
            workQueue.quit();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }


    @Override
    public void onServiceConnected() {
        Timber.tag(TAG).d("弹窗服务连接成功");
    }

    @Override
    public void onServiceDisconnected() {
        Timber.tag(TAG).d("弹窗服务断开");
    }

    private void play(Message message) {
        Timber.tag(TAG).e("voiceContent: %s, textContent: %s", message.voiceMessage, message.textMessage);
        NoticeParam.Builder builder = new NoticeParam.Builder();
        if (!TextUtils.isEmpty(message.voiceMessage)) {
            builder.setPlayText(message.voiceMessage);
            builder.setIsPlay(true).setDismissOnTtsEnd(true);
        } else {
            builder.setIsPlay(true);
            builder.setDismissTime(DISMISS_TIME);
        }

        if (TextUtils.isEmpty(message.textMessage)) {
            Timber.tag(TAG).e("textMessage is empty");
            return;
        } else {
            builder.setShowText(message.textMessage);
        }

        builder.setDismissOnTouchOutside(true)
                .setFlags(BetterNoticeMangerClient.NOTICE_TOAST_ID)
                .setNoticePriority(BetterNoticeMangerClient.NOTICE_PRIORITY_APP)
                .build();
        client.showNotice(builder.build());
    }

    private static class Message {
        String voiceMessage;
        String textMessage;

        Message(String voiceMessage, String textMessage) {
            this.voiceMessage = voiceMessage;
            this.textMessage = textMessage;
        }

        @Override
        public String toString() {
            return "Message{" +
                    "voiceMessage='" + voiceMessage + '\'' +
                    ", textMessage='" + textMessage + '\'' +
                    '}';
        }
    }
}
