package com.uaes.android.domain;

import com.uaes.android.domain.entity.DMBatteryStatus;

/**
 * 电池助手
 */
public interface BatteryRepository {
    /**
     * 查询电池寿命
     */
    DMBatteryStatus queryBatteryStatus() throws Exception;


//    查询电池电量

    DMBatteryStatus queryBatteryVol() throws Exception;


    /**
     * 查询电池描述,
     * isStatus - 电池状态 true 是老化
     * isVol   - 电池   true 电量满
     **/
    String queryBatteryDescription(boolean isStatus, boolean isVol) throws Exception;
}
