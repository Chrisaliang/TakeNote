package com.uaes.android.data.internel;

import android.support.annotation.NonNull;
import android.text.TextUtils;

import com.amap.api.location.AMapLocation;
import com.amap.api.location.AMapLocationClient;
import com.amap.api.location.AMapLocationListener;

import java.util.concurrent.atomic.AtomicInteger;

import io.reactivex.Observable;
import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;
import io.reactivex.exceptions.CompositeException;
import io.reactivex.exceptions.Exceptions;
import io.reactivex.plugins.RxJavaPlugins;
import timber.log.Timber;

/**
 * 高德定位封装
 */
final class AMapLocationObservable extends Observable<AMapLocation> {

    private static final String TAG = "AMapLocationObservable";

    private AMapLocationClient client;

    AMapLocationObservable(@NonNull AMapLocationClient client) {
        this.client = client;
    }

    @Override
    protected void subscribeActual(Observer<? super AMapLocation> observer) {
        LocationObserver originObserver = new LocationObserver(client, observer);
        client.setLocationListener(originObserver);
        observer.onSubscribe(originObserver);
        client.startLocation();
    }

    private static class LocationObserver extends AtomicInteger implements AMapLocationListener, Disposable {

        private static final int MAX_ERROR_COUNT = 4;

        private Observer<? super AMapLocation> source;
        private AMapLocationClient client;

        private boolean isDisposed = false;

        LocationObserver(AMapLocationClient client, Observer<? super AMapLocation> source) {
            this.source = source;
            this.client = client;
        }

        @Override
        public void onLocationChanged(AMapLocation aMapLocation) {
            Timber.tag(TAG).d(aMapLocation.toStr());
            try {
                if (aMapLocation.getErrorCode() == 0 && !TextUtils.isEmpty(aMapLocation.getProvince())) {
                    source.onNext(aMapLocation);
                    if (!isDisposed) {
                        source.onComplete();
                        dispose();
                    }
                } else {
                    if (get() < MAX_ERROR_COUNT) {
                        getAndIncrement();
                    } else {
                        try {
                            dispose();
                            source.onError(new AMapLocationException(aMapLocation.getErrorCode(), aMapLocation.getErrorInfo()));
                        } catch (Throwable inner) {
                            Exceptions.throwIfFatal(inner);
                            RxJavaPlugins.onError(new CompositeException(new AMapLocationException(aMapLocation.getErrorCode(), aMapLocation.getErrorInfo()), inner));
                        }
                    }
                }
            } catch (Throwable t) {
                if (isDisposed) {
                    RxJavaPlugins.onError(t);
                } else {
                    try {
                        source.onError(t);
                    } catch (Throwable inner) {
                        Exceptions.throwIfFatal(inner);
                        RxJavaPlugins.onError(new CompositeException(t, inner));
                    } finally {
                        dispose();
                    }
                }
            }
        }

        @Override
        public void dispose() {
            if (client.isStarted()) {
                client.stopLocation();
                client.unRegisterLocationListener(this);
            }
            client.onDestroy();
            isDisposed = true;
        }

        @Override
        public boolean isDisposed() {
            return isDisposed;
        }
    }
}
