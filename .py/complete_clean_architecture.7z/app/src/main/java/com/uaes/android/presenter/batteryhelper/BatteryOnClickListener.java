package com.uaes.android.presenter.batteryhelper;

public interface BatteryOnClickListener {
    void showTips();
}
