package com.uaes.android.data.mapper;

import android.text.TextUtils;

import com.uaes.android.data.MaintainRepositoryImp;
import com.uaes.android.data.http.HttpMaintainApi;
import com.uaes.android.data.json.CommonResponse;
import com.uaes.android.data.json.MaintainContentItemJson;
import com.uaes.android.data.json.MaintainStatusJson;
import com.uaes.android.domain.entity.DMMaintainStatus;

import java.util.ArrayList;
import java.util.List;

import io.reactivex.functions.Function;

/**
 * Created by ${GY} on 2018/5/21
 * des：
 */
public class MaintainStatusMapper implements Function<CommonResponse<MaintainStatusJson>, DMMaintainStatus> {
    private static final String TAG = "MaintainStatusMapper";

    @Override
    public DMMaintainStatus apply(CommonResponse<MaintainStatusJson> maintainStatus) {
        DMMaintainStatus dmMaintainStatus = new DMMaintainStatus();
        ArrayList<String> contenList = new ArrayList<>();
        ArrayList<String> codeList = new ArrayList<>();
        List<MaintainContentItemJson> dataList = maintainStatus.msgContent.maintainList;
        if (dataList == null)
            dataList = new ArrayList<>();
        for (int i = 0; i < dataList.size(); i++) {
            contenList.add(dataList.get(i).content);
            codeList.add(dataList.get(i).code);

        }
        dmMaintainStatus.maintainList = contenList;
        dmMaintainStatus.maintainCodeList = codeList;
        if (HttpMaintainApi.TYPE_DAY.equals(maintainStatus.msgContent.statusReminder.maintainType)) {
            dmMaintainStatus.maintainType = MaintainRepositoryImp.TYPE_MAINTAIN_DAY;
        } else {
            dmMaintainStatus.maintainType = MaintainRepositoryImp.TYPE_MAINTAIN_MILE;
        }
        if (TextUtils.isEmpty(maintainStatus.msgContent.statusReminder.maintainValue) || "null".equals(maintainStatus.msgContent.statusReminder.maintainValue)) {
            dmMaintainStatus.maintainValue = -1;
        } else {
            dmMaintainStatus.maintainValue = Float.valueOf(maintainStatus.msgContent.statusReminder.maintainValue).intValue();
        }
        return dmMaintainStatus;
    }
}
