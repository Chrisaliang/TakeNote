package com.uaes.android.presenter.fuelaccountancy;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SeekBar;

import com.uaes.android.R;
import com.uaes.android.databinding.FuelAccountancyFragmentStationSettingBinding;

import javax.inject.Inject;

import timber.log.Timber;

public class FuelAccountancyStationSettingFragment extends FuelAccountancyFragment implements SeekBar.OnSeekBarChangeListener {
    private static final String TAG = "FuelAccountancyStationS";

    private FuelAccountancyFragmentStationSettingBinding binding;
    private FuelAccountancySettingViewModel viewModel;

    private final Handler handler = new Handler();

    @Inject
    ViewModelProvider.Factory factory;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        viewModel = ViewModelProviders.of(this, factory).get(FuelAccountancySettingViewModel.class);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.fuel_accountancy_fragment_station_setting, container, false);
        binding.setLifecycleOwner(this);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding.setViewModel(viewModel);
        binding.setNavigator(navigator);
        binding.setSelector(viewModel);
        binding.fuelAccountancyStationSettingSeekBar.setOnSeekBarChangeListener(this);
    }

    private final Runnable shutDown = new Runnable() {
        @Override
        public void run() {
            Timber.tag(TAG).d("close FuelAccountancySetSuccess fragment");
            navigator.back();
            viewModel.saveData();
        }
    };

    @Override
    public void onStart() {
        super.onStart();
        observerSettingUpdate();
        viewModel.subscription();
        handler.postDelayed(shutDown, 10 * 60 * 1000);
    }

    @Override
    public void onStop() {
        super.onStop();
        viewModel.unSubscribe();
        handler.removeCallbacks(shutDown);
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
        Timber.tag(TAG).d("the seek bar progress is: %s", progress);
        viewModel.fuelNum.setValue(progress);
    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }

    private void observerSettingUpdate() {
        viewModel.isSuccess.observe(this, new Observer<Boolean>() {
            @Override
            public void onChanged(@Nullable Boolean aBoolean) {
                if (aBoolean != null && aBoolean) {
                    Timber.tag(TAG).d("save data success ");
                    viewModel.isSuccess.setValue(false);
                    navigator.goToSettingSuccess();

                } else {
                    Timber.tag(TAG).d("save data fail ");
                }
            }
        });
    }
}
