package com.uaes.android.presenter.powerdefender.viewholder;

import android.databinding.ViewDataBinding;
import android.support.v7.widget.RecyclerView;

/**
 * Created by diaokaibin@gmail.com on 2018/5/11.
 */
public abstract class HistoryFaultBase extends RecyclerView.ViewHolder {

    private ViewDataBinding mBinding;

    HistoryFaultBase(ViewDataBinding binding) {
        super(binding.getRoot());
        mBinding = binding;
    }

    public ViewDataBinding getBinding() {
        return mBinding;
    }
}
