package com.uaes.android.tts;

import android.content.Context;
import android.media.AudioManager;
import android.media.AudioManager.OnAudioFocusChangeListener;

import com.iflytek.autofly.utils.FlyLog;

/**
 * AudioFocusManager
 *
 * @author admin<br>
 * description: AudioFocusManager<br/>
 * create: 2015-12-19 morning 11:07:26<br/>
 */

class AudioFocusManager {
    private static final String TAG = "AudioFocusManager";
    private AudioManager mManager;
    private boolean isInFocus;

    AudioFocusManager(Context context) {
        mManager = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
        isInFocus = false;
    }

    boolean requestAudioFocus(OnAudioFocusChangeListener listener) {
        if (isInFocus) {
            return true;
        }
        isInFocus = true;

        // 播放提示音
        FlyLog.d(TAG, "request audio focus");
        int result = mManager.requestAudioFocus(listener,
                AudioManager.STREAM_VOICE_CALL, AudioManager.AUDIOFOCUS_GAIN);

        return result == AudioManager.AUDIOFOCUS_REQUEST_GRANTED;
    }

    void abandonAudioFocus(OnAudioFocusChangeListener listener) {
        if (isInFocus) {
            FlyLog.d(TAG, "abandon audio focus");
            mManager.abandonAudioFocus(listener);
            isInFocus = false;
        }
    }
}
