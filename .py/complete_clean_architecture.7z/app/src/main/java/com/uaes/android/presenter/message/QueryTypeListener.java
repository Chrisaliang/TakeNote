package com.uaes.android.presenter.message;

public interface QueryTypeListener {

    void onClick(int type);
}
