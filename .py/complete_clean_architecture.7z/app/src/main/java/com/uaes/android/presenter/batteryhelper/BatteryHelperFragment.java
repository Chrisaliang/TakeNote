package com.uaes.android.presenter.batteryhelper;

import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.databinding.BatteryHelperMainFragmentBinding;
import com.uaes.android.presenter.BaseFragment;

import javax.inject.Inject;

/**
 * 电池助手
 */
public class BatteryHelperFragment extends BaseFragment implements BatteryOnClickListener {

    private BatteryHelperMainFragmentBinding binding;
    private BatteryHelperViewModel batteryHelperViewModel;
    private final BatteryTipsFragment batteryTipsFragment = new BatteryTipsFragment();

    @Inject
    ViewModelProvider.Factory factory;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        batteryHelperViewModel = ViewModelProviders.of(this, factory).get(BatteryHelperViewModel.class);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.battery_helper_main_fragment, container, false);
        binding.setLifecycleOwner(this);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding.setBatteryOnClickListener(this);
        binding.setBatteryHelperView(batteryHelperViewModel);
    }

    @Override
    public void onStart() {
        super.onStart();
        batteryHelperViewModel.subscription();
    }

    @Override
    public void onStop() {
        super.onStop();
        batteryHelperViewModel.unSubscribe();
    }

    @Override
    public void showTips() {
        if (!batteryTipsFragment.isAdded())
            batteryTipsFragment.show(getChildFragmentManager(), null);
    }
}
