package com.uaes.android.data;

import android.content.Context;

import com.google.gson.Gson;
import com.uaes.android.data.http.HttpMaintainApi;
import com.uaes.android.data.json.CommonResponse;
import com.uaes.android.data.json.JsonRequestBody;
import com.uaes.android.data.json.MaintainRecordJson;
import com.uaes.android.data.json.MaintainSettingJson;
import com.uaes.android.data.json.MaintainStatusJson;
import com.uaes.android.data.mapper.MaintainItemDetailMapper;
import com.uaes.android.data.mapper.MaintainRecordMapper;
import com.uaes.android.data.mapper.MaintainSettingsMapper;
import com.uaes.android.data.mapper.MaintainStatusMapper;
import com.uaes.android.domain.MaintainRepository;
import com.uaes.android.domain.entity.DMMaintainItemDetail;
import com.uaes.android.domain.entity.DMMaintainRating;
import com.uaes.android.domain.entity.DMMaintainRecord;
import com.uaes.android.domain.entity.DMMaintainSetting;
import com.uaes.android.domain.entity.DMMaintainStatus;

import java.io.IOException;
import java.util.List;

import retrofit2.Response;

public class MaintainRepositoryImp implements MaintainRepository {
    private HttpMaintainApi api;
    private Gson gson;
    private MaintainStatusMapper maintainStatusMapper = new MaintainStatusMapper();
    private MaintainRecordMapper maintainRecordMapper = new MaintainRecordMapper();
    private MaintainSettingsMapper maintainSettingsMapper = new MaintainSettingsMapper();
    private MaintainItemDetailMapper maintainItemDetailMapper;

    public MaintainRepositoryImp(HttpMaintainApi api, Gson gson, Context ctx) {
        this.api = api;
        this.gson = gson;
        maintainItemDetailMapper = new MaintainItemDetailMapper(ctx);
    }

    @Override
    public DMMaintainStatus queryStatus() throws Exception {
        Response<CommonResponse<MaintainStatusJson>> response = api.queryStatus().execute();
        if (response.isSuccessful()) {
            return maintainStatusMapper.apply(response.body());
        }
        return null;
    }

    @Override
    public DMMaintainSetting querySetting() throws Exception {
        Response<CommonResponse<MaintainSettingJson>> response = api.querySetting().execute();
        if (response.isSuccessful()) {
            return maintainSettingsMapper.apply(response.body());
        }
        return null;
    }

    /**
     * 更新保养设置
     * {
     * "pushFlag": false,
     * "pushTimeType": "2",
     * "pushFrequency": "1"
     * }
     */
    @Override
    public boolean updateSetting(DMMaintainSetting setting) throws IOException {
        Response response = api.updateSetting(JsonRequestBody.createMaintainSettingUpdate(gson, setting.isAllowedPush
                , setting.pushType, setting.pushFrequency)).execute();
        return response.isSuccessful();
    }

    @Override
    public List<DMMaintainRecord> queryRecord() throws Exception {
        Response<CommonResponse<List<MaintainRecordJson>>> response = api.queryRecord().execute();
        if (response.isSuccessful()) {
            return maintainRecordMapper.apply(response.body());
        }
        return null;
    }

    /* {
     * "recordId": 123,
     * "efficientService": 4,
     * "friendlyAttitude": 4,
     * "transparentFees": 5
     * }*/
    @Override
    public boolean ratingRecord(DMMaintainRating rating) throws IOException {
        Response response = api.ratingRecord(JsonRequestBody.createMaintainRatingUpdate(gson, rating)).execute();
        return response.isSuccessful();
    }

    @Override
    public DMMaintainItemDetail queryDMMaintainItemDetail(int type) throws Exception {
        return maintainItemDetailMapper.apply(type);
    }

}
