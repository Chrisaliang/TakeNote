package com.uaes.android.presenter.powerdefender.fragment;

import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.databinding.FragmentPowerDefenderFaultHistoryBinding;
import com.uaes.android.presenter.powerdefender.PowerDefenderOnClickListener;
import com.uaes.android.presenter.powerdefender.viewmodel.FaultHistoryViewModel;

import javax.inject.Inject;

/**
 * Created by diaokaibin@gmail.com on 2018/5/9.
 */
public class PowerDefenderFaultHistoryFragment extends PowerDefenderBaseFragment implements PowerDefenderOnClickListener {

    private FragmentPowerDefenderFaultHistoryBinding mHistoryBinding;

    @Inject
    ViewModelProvider.Factory mFactory;
    private FaultHistoryViewModel mFaultHistoryViewModel;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mHistoryBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_power_defender_fault_history, container, false);
        mHistoryBinding.setLifecycleOwner(this);
        return mHistoryBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mFaultHistoryViewModel = ViewModelProviders.of(this, mFactory).get(FaultHistoryViewModel.class);
        mHistoryBinding.setViewModel(mFaultHistoryViewModel);
        mFaultHistoryViewModel.doQuery();

        mHistoryBinding.setPowerClickListener(this);
    }


    @Override
    public void onStop() {
        super.onStop();
        mFaultHistoryViewModel.cancleQuery();
    }

    @Override
    public void onClick(int type) {
        switch (type) {
            case 1:
                mNavigator.onBack();
                break;
        }

    }
}
