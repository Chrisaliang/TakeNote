package com.uaes.android.data.room;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.RoomDatabase;
import android.arch.persistence.room.TypeConverters;

@Database(entities = {
        MessageCenterEntity.class
}, version = 1)
@TypeConverters({RoomTypeConverters.class})
public abstract class UaesDatabase extends RoomDatabase {

    public abstract CacheDao getCacheDao();
}
