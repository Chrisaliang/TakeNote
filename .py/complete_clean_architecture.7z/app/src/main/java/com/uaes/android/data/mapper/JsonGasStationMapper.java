package com.uaes.android.data.mapper;

import android.support.annotation.NonNull;

import com.uaes.android.data.json.FuelStationJson;
import com.uaes.android.domain.entity.DMGas;

public class JsonGasStationMapper {

    public static DMGas map(@NonNull FuelStationJson json) {
        DMGas gas = new DMGas();
        gas.name = json.name;
        gas.latitude = json.latitude;
        gas.longitude = json.longitude;
        gas.duration = json.duration;
        gas.distance = json.distance;
        gas.brand = json.brand;
        gas.address = json.address;
        gas.fillTime = json.fillTime;
        gas.rate = json.rate;
        return gas;
    }
}
