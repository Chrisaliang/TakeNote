package com.uaes.android.data;

import com.uaes.android.data.mapper.MessageCenterMapper;
import com.uaes.android.data.room.CacheDao;
import com.uaes.android.data.room.MessageCenterEntity;
import com.uaes.android.domain.MessageCenterRepository;
import com.uaes.android.domain.MessageReceiveInterpolator;
import com.uaes.android.domain.entity.DMMessageCenterItem;

import java.util.List;

import io.reactivex.FlowableEmitter;


public class MessageCenterRepositoryImp implements MessageCenterRepository {

//    private static final String TAG = "MessageCenterRepository";

    private final CacheDao cacheDao;
    private final MessageCenterMapper mapper;
    //    private DMMsgUpdateListener mListener;
    private FlowableEmitter<DMMessageCenterItem> emitter;

//    private boolean receive = true;

    private MessageReceiveInterpolator interpolator;

//    private Disposable disposable;

    public MessageCenterRepositoryImp(CacheDao cacheDao) {
        this.cacheDao = cacheDao;
        mapper = new MessageCenterMapper();
    }

    @Override
    public boolean isReceive(String msgParaType) {
        return interpolator == null || interpolator.receiveMsg(msgParaType);
    }

    @Override
    public void setReceive(MessageReceiveInterpolator interpolator) {
        this.interpolator = interpolator;
    }

    @Override
    public List<DMMessageCenterItem> queryMessage(int type) {
        MessageCenterEntity[] entities;
        if (type == MESSAGE_CENTER_QUERY_ALL) {
            entities = cacheDao.queryAllMessage();
        } else {
            entities = cacheDao.queryMessages(type);
        }
        return mapper.mapper(entities);
    }

//    @Override
//    public void updateMessage(DMMsgUpdateListener listener) {
////        mListener = listener;
//    }

//    @Override
//    public ConnectableFlowable<DMMessageCenterItem> updateMessage(DMMessageCenterItem item) {
//        return Flowable.just(item).publish();
//    }

    @Override
    public void updateMessage(FlowableEmitter<DMMessageCenterItem> emitter) {
        this.emitter = emitter;
    }

    @Override
    public void onSaveMessage(DMMessageCenterItem... item) {

        if (emitter != null)
            for (DMMessageCenterItem dmMessageCenterItem : item) {
                emitter.onNext(dmMessageCenterItem);
            }

//        if (mListener != null)
//            mListener.onUpdate(item);
    }

    @Override
    public int deleteMessage(DMMessageCenterItem... items) {
        return cacheDao.deleteMessageItem(mapper.mapper(items));
    }


}
