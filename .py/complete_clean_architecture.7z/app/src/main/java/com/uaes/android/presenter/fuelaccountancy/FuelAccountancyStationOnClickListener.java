package com.uaes.android.presenter.fuelaccountancy;

public interface FuelAccountancyStationOnClickListener {

    void onClick(int type);

}
