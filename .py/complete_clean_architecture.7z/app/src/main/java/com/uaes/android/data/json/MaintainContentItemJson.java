package com.uaes.android.data.json;

import com.google.gson.annotations.SerializedName;

/**
 * 当前车况保养状态
 * <p>
 * {
 * "msgCode": "10000",
 * "msg": "OK",
 * "content": {
 * "list": [{"maintenanceCode":"1","maintenanceContent":"发动机机油"},{},{}],
 * "remainder": {
 * "dataKey": "day",
 * "dataValue": "10"
 * }
 * },
 * "status": 1,
 * "total": 2
 * }
 */
public class MaintainContentItemJson {

    /**
     * 剩余保养数值表示的值类型
     */
    @SerializedName("maintenanceCode")
    public String code;
    /**
     * 剩余保养的值，代表了天数 或者里程 KM
     */
    @SerializedName("maintenanceContent")
    public String content;

    public MaintainContentItemJson(String code, String content) {
        this.code = code;
        this.content = content;
    }

    public MaintainContentItemJson() {
    }
}
