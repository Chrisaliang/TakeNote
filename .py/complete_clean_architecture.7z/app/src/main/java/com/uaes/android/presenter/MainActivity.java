package com.uaes.android.presenter;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.content.LocalBroadcastManager;
import android.view.View;

import com.uaes.android.R;
import com.uaes.android.common.ConnectionChecker;
import com.uaes.android.common.Intents;
import com.uaes.android.presenter.batteryhelper.BatteryHelperFragment;
import com.uaes.android.presenter.driver.DriverMasterFragment;
import com.uaes.android.presenter.fuelaccountancy.FuelAccountancySettingMainFragment;
import com.uaes.android.presenter.maintainsecretary.MaintainGuideMangerFragment;
import com.uaes.android.presenter.message.MessageCenterFragment;
import com.uaes.android.presenter.powerdefender.fragment.PowerGuideManagerFragment;

import dagger.android.support.DaggerAppCompatActivity;
import timber.log.Timber;

public class MainActivity extends DaggerAppCompatActivity {

    private static final String TAG = "MainActivity";

    public static final String EXTRA_SELECTED_ITEM = "com.uaes.android.presenter";

    private int selectedViewId = View.NO_ID;

    private NetworkErrorDialog networkErrorDialog;

    private LocalBroadcastManager mBroadcastManager;

    private IntentFilter intentFilter;

    private ConnectivityManager cm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        intentFilter = new IntentFilter();
        intentFilter.addAction(Intents.ACTION_NETWORK_ERROR);
        mBroadcastManager = LocalBroadcastManager.getInstance(this);
        cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        int newSelectedViewId = getIntent().getIntExtra(EXTRA_SELECTED_ITEM, View.NO_ID);
        if (newSelectedViewId == View.NO_ID)
            if (savedInstanceState == null) {
                onTabSelected(findViewById(R.id.main_tab_item_fuel_helper));
            } else {
                selectedViewId = savedInstanceState.getInt(EXTRA_SELECTED_ITEM);
                findViewById(selectedViewId).setSelected(true);
            }
        else
            onTabSelected(findViewById(newSelectedViewId));
    }

    @Override
    protected void onStart() {
        super.onStart();
        // 发送广播 通知 系统 显示返回键 , 只在科大讯飞平台车机有效
        Intent intent = new Intent("com.iflytek.car.USER_ACTION");
        intent.putExtra("name", "showBack");
        sendBroadcast(intent);
//        mBroadcastManager.registerReceiver(networkListener, intentFilter);
        IntentFilter filter = new IntentFilter();
        filter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(connectionListener, filter);
        if (!ConnectionChecker.isOnline(cm)) {
            showNetworkError();
        } else {
            dismissNetworkError();
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
//        mBroadcastManager.unregisterReceiver(networkListener);
        unregisterReceiver(connectionListener);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        onTabSelected(findViewById(intent.getIntExtra(EXTRA_SELECTED_ITEM, View.NO_ID)));
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(EXTRA_SELECTED_ITEM, selectedViewId);
    }

    public void onTabSelected(View view) {
        final int newId = view.getId();
        Timber.tag(TAG).d("origin id:  %d, newId: %d", selectedViewId, newId);
        if (newId == selectedViewId) return;
        if (selectedViewId != View.NO_ID)
            findViewById(selectedViewId).setSelected(false);
        selectedViewId = newId;
        view.setSelected(true);
        Fragment fragment = getFragment(selectedViewId);
        if (fragment == null) return;
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.main_container, fragment)
                .setPrimaryNavigationFragment(fragment)
                .commit();
    }

    private Fragment getFragment(int id) {
        switch (id) {
            case R.id.main_tab_item_fuel_helper:
                return new FuelAccountancySettingMainFragment();
            case R.id.main_tab_item_battery_helper:
                return new BatteryHelperFragment();
            case R.id.main_tab_item_master_driver:
//                return null;
                return new DriverMasterFragment();
            case R.id.main_tab_item_message_center:
//                return null;
                return new MessageCenterFragment();
            case R.id.main_tab_item_maintain_secretary:
//                return null;
                return new MaintainGuideMangerFragment();
            case R.id.main_tab_item_power_defender:
//                return null;
                return new PowerGuideManagerFragment();
        }
        return null;
    }

    private BroadcastReceiver networkListener = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (Intents.ACTION_NETWORK_ERROR.equals(intent.getAction()))
                showNetworkError();
        }
    };

    private void showNetworkError() {
        if (networkErrorDialog == null) {
            networkErrorDialog = new NetworkErrorDialog();
        }

        if (!networkErrorDialog.isAdded())
            networkErrorDialog.show(getSupportFragmentManager(), "errorNetwork");
    }

    private void dismissNetworkError() {
        if (networkErrorDialog != null) {
            networkErrorDialog.dismiss();
        }
    }

    private BroadcastReceiver connectionListener = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (!ConnectionChecker.isOnline(cm)) {
                showNetworkError();
            } else {
                dismissNetworkError();
            }
        }
    };
}
