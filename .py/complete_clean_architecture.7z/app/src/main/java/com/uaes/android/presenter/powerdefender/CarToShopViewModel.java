package com.uaes.android.presenter.powerdefender;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;

import com.uaes.android.domain.entity.DM4SShop;
import com.uaes.android.domain.entity.DMLocation;

/**
 * Created by diaokaibin@gmail.com on 2018/5/15.
 */
public class CarToShopViewModel implements CarShopOnClickListener {

    private FragmentManager mManager;
    private PowerNavigator mNavigator;
    private Context mContext;

    public CarToShopViewModel(FragmentManager manager, Context ctx, PowerNavigator navigator) {
        this.mNavigator = navigator;
        this.mContext = ctx;
        this.mManager = manager;
    }

    @Override
    public void onCarClickPos(int type, DM4SShop dm4SShop, DMLocation dmLocation) {
        if (dm4SShop == null) return;
        switch (type) {
            case 1:
                //
                Bundle bundle = new Bundle();
                bundle.putString(PowerConstant.BUNDLE_DTAT_TO_PHONE, dm4SShop.phone);
                bundle.putString(PowerConstant.BUNDLE_DTAT_TO_NAME, dm4SShop.name);
                mNavigator.goPhoneCall(bundle);

//                PowerDefenderPhoneFragment fragment = new PowerDefenderPhoneFragment();
//                fragment.setArguments(bundle);
//                mManager.beginTransaction()
//                        .add(R.id.fl_power_defender_near_car_container, fragment, null)
//                        .addToBackStack(null).commit();
                break;

            case 2:


                Intent intent = new Intent();
                intent.setAction("AUTONAVI_STANDARD_BROADCAST_RECV");
                intent.putExtra("KEY_TYPE", 10007);
                intent.putExtra("EXTRA_SNAME", dmLocation.address);
                intent.putExtra("EXTRA_SLON", dmLocation.longitude);
                intent.putExtra("EXTRA_SLAT", dmLocation.latitude);
                intent.putExtra("EXTRA_DNAME", dm4SShop.address);
                intent.putExtra("EXTRA_DLON", dm4SShop.longitude);
                intent.putExtra("EXTRA_DLAT", dm4SShop.latitude);
                intent.putExtra("EXTRA_DEV", 0);
                intent.putExtra("EXTRA_M", 0);
                mContext.sendBroadcast(intent);


                break;
        }
    }
}
