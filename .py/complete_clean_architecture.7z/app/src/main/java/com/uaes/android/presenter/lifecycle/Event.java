package com.uaes.android.presenter.lifecycle;

import android.support.annotation.Nullable;

public class Event<T> {
    private T content;
    private boolean hasBeenHandled = false;

    /**
     * Returns the content and prevents its use again.
     */
    @Nullable
    public T getContentIfNotHandled() {
        if (hasBeenHandled) return null;
        else {
            hasBeenHandled = true;
            return content;
        }
    }

    public boolean isHasBeenHandled() {
        return hasBeenHandled;
    }

    public T peekContent() {
        return content;
    }
}
