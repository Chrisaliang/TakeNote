package com.uaes.android.data.json;

import com.google.gson.annotations.SerializedName;
import com.uaes.android.domain.entity.DMMaintainRating;

import java.util.List;

/**
 * 保养记录
 */
public class MaintainRecordJson {

 /*
    "msgCode": "10000",
            "msg": "OK",
            "content": [
    {
        "recordId": 4,
            "shopCode": "1234567",
            "vin": "LNBSCUAK5HF043610",
            "mileage": "123455.434km",
            "shopName":"某某4S店",
            "efficientService": 5,
            "friendlyAttitude": 10,
            "transparentFees": 3,
            "creationDate": "2018-05-14 19:15:06",
            "contents": [
        {
            "maintenanceCode": "0001",
                "maintenanceRecord": "avc"
        },
        {
            "maintenanceCode": "0002",
                "maintenanceRecord": "ajfje"
        }
            ]
    }
}*/

    /**
     * 保养记录 ID
     *
     * @see DMMaintainRating#id  它们是相同的
     */
    @SerializedName("recordId")
    public String id;
    /**
     * 店名
     */
    @SerializedName("shopName")
    public String name;

    /**
     * 保养时间 格式 2018-03-31 17:30
     */
    @SerializedName("creationDate")
    public String time;
    /**
     * 进店里程
     */
    @SerializedName("mileage")
    public int mile;
    /**
     * 保养内容
     */
    @SerializedName("contents")
    public List<MaintainContentItemJson> maintainContents;
    /**
     * 服务高效度
     */
    @SerializedName("efficientService")
    public int serviceRating = -1;

    /**
     * 态度友好
     */
    @SerializedName("friendlyAttitude")
    public int attitudeRating = -1;

    /**
     * 收费透明
     */
    @SerializedName("transparentFees")
    public int transparencyOfFeesRate = -1;
}
