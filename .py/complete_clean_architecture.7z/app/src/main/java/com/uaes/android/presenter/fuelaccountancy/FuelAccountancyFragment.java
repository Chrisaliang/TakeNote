package com.uaes.android.presenter.fuelaccountancy;

import com.uaes.android.presenter.BaseFragment;


//base
public class FuelAccountancyFragment extends BaseFragment {

    public FuelAccountancyNavigator navigator;


}
