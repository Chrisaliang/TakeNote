package com.uaes.android.presenter.fuelaccountancy;

/**
 * 设置用油会计-设置页面-加油站查询类型
 */
public interface FuelAccountancySettingOnClickListener {
    /**
     * 触发更改 设置的加油站 查询类型
     *
     * @param type 0 -- 选择全部
     *             1 -- 选中中石油
     *             2 -- 选中中石化
     */
    void onStationTypeSelected(int type);
}
