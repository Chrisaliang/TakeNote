package com.uaes.android.domain;

import android.support.annotation.IntDef;

import com.uaes.android.domain.entity.DMMaintainItemDetail;
import com.uaes.android.domain.entity.DMMaintainRating;
import com.uaes.android.domain.entity.DMMaintainRecord;
import com.uaes.android.domain.entity.DMMaintainSetting;
import com.uaes.android.domain.entity.DMMaintainStatus;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.List;

/**
 * 保养秘书数据层接口
 */
public interface MaintainRepository {

    /**
     * 200KM/周
     */
    int TYPE_PUSH_200KM = 0;
    /**
     * 500KM/两周
     */
    int TYPE_PUSH_500KM = 1;
    /**
     * 1000KM/月
     */
    int TYPE_PUSH_1000KM = 2;
    /**
     * 没50KM 一次 推送
     */
    int PUSH_FREQUENCY_EVERY_50KM = 0;
    /**
     * 每次驾驶 推送一次
     */
    int PUSH_FREQUENCY_EVERY_DRIVE = 1;
    /**
     * 每天 推送
     */
    int PUSH_FREQUENCY_EVERY_DAY = 2;
    /**
     * 每周 推送
     */
    int PUSH_FREQUENCY_EVERY_WEEK = 3;
    /**
     * 剩余保养里程
     */
    int TYPE_MAINTAIN_MILE = 0;
    /**
     * 剩余保养天数
     */
    int TYPE_MAINTAIN_DAY = 1;
    // 推荐更换机油
    int MAINTAIN_LIST_MACHINE_OIL = 0;

    /**
     * 保养状态
     */
    DMMaintainStatus queryStatus() throws Exception;

    /**
     * 查询保养秘书配置
     */
    DMMaintainSetting querySetting() throws Exception;

    /**
     * 更新保养秘书配置
     */
    boolean updateSetting(DMMaintainSetting setting) throws Exception;

    /**
     * 查询保养记录
     */
    List<DMMaintainRecord> queryRecord() throws Exception;

    /**
     * 评价保养记录
     */
    boolean ratingRecord(DMMaintainRating rating) throws Exception;

    /**
     * 查询保养条目对应的详情
     *
     * @param type 保养条目对应的code
     */
    DMMaintainItemDetail queryDMMaintainItemDetail(int type) throws Exception;

    @Retention(RetentionPolicy.SOURCE)
    @IntDef({
            TYPE_PUSH_200KM, TYPE_PUSH_500KM, TYPE_PUSH_1000KM
    })
    @interface PushType {
    }

    @Retention(RetentionPolicy.SOURCE)
    @IntDef({
            PUSH_FREQUENCY_EVERY_50KM, PUSH_FREQUENCY_EVERY_DRIVE,
            PUSH_FREQUENCY_EVERY_DAY, PUSH_FREQUENCY_EVERY_WEEK
    })
    @interface PushFrequency {
    }

    @Retention(RetentionPolicy.SOURCE)
    @IntDef({
            TYPE_MAINTAIN_MILE, TYPE_MAINTAIN_DAY
    })
    @interface MaintainType {
    }
}
