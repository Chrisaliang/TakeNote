package com.uaes.android.data.http;

import com.uaes.android.data.json.CommonResponse;
import com.uaes.android.data.json.PowerDefenderJson;
import com.uaes.android.data.json.PowerHistoryFaultReportJson;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

/**
 * Created by diaokaibin@gmail.com on 2018/5/28.
 */
public interface HttpPowerDefenderApi {

    /**
     * 读取动力卫士 基础基础状态信息（包括错误，以及各个部件列表）
     */
    @GET("/power/v1/powerguard/powerdetails")
    Call<CommonResponse<PowerDefenderJson>> queryPower();

    /**
     * 读取动力卫士历史报告
     */
    @GET("/power/v1/powerguard/breakdown/list")
    Call<CommonResponse<List<PowerHistoryFaultReportJson>>> queryHistoryFaultReport();


}
