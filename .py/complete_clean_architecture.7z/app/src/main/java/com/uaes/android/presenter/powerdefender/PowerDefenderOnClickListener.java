package com.uaes.android.presenter.powerdefender;

/**
 * Created by diaokaibin@gmail.com on 2018/5/8.
 */
public interface PowerDefenderOnClickListener {

    void onClick(int type);

}
