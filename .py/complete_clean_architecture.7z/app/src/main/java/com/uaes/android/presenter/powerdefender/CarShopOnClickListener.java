package com.uaes.android.presenter.powerdefender;

import com.uaes.android.domain.entity.DM4SShop;
import com.uaes.android.domain.entity.DMLocation;

/**
 * Created by diaokaibin@gmail.com on 2018/5/11.
 */
public interface CarShopOnClickListener {
    void onCarClickPos(int type, DM4SShop dm4SShop, DMLocation dmLocation);
}
