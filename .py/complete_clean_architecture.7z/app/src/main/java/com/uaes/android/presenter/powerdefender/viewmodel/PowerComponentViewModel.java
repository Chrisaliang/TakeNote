package com.uaes.android.presenter.powerdefender.viewmodel;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.uaes.android.presenter.powerdefender.pojo.PowerPart;

import java.util.List;

/**
 * Created by diaokaibin@gmail.com on 2018/5/17.
 */
public class PowerComponentViewModel extends ViewModel {

    public final MutableLiveData<List<PowerPart>> mDataParts = new MutableLiveData<>();

    public void setData(List<PowerPart> mList) {
        mDataParts.setValue(mList);
    }
}
