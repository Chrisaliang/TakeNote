package com.uaes.android.domain.entity;

public class DMMessageCenterItem {

    /**
     * 消息实体的数据库表id
     */
    public long id;
    /**
     * 消息时间
     */
    public String msgTime;

    /**
     * 消息内容
     */
    public String msgContent;
}
