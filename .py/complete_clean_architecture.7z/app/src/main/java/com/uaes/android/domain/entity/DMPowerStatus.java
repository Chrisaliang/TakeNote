package com.uaes.android.domain.entity;

import android.support.annotation.NonNull;
import android.support.annotation.StringDef;

import com.uaes.android.domain.PowerDefenderRepository;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.List;
import java.util.Map;

/**
 * 动力卫士状态
 */
@SuppressWarnings("WeakerAccess")
public class DMPowerStatus {
    /**
     * 润滑系统
     */
    public final static String KEY_CODE_LUBRICATION_SYSTEM = "com.uaes.system.power.LUBRICATION";
    /**
     * 热管理系统
     */
    public final static String KEY_CODE_THERMAL_MANAGEMENT_SYSTEM = "com.uaes.system.power.THERMAL_MANAGEMENT";
    /**
     * 供油系统
     */
    public final static String KEY_CODE_FUEL_SUPPLY_SYSTEM = "com.uaes.system.power.FUEL_SUPPLY";
    /**
     * 点火系统
     */
    public final static String KEY_CODE_IGNITION_SYSTEM = "com.uaes.system.power.IGNITION";
    /**
     * 排气系统
     */
    public final static String KEY_CODE_EXHAUST_SYSTEM = "com.uaes.system.power.EXHAUST";
    /**
     * 供电系统
     */
    public final static String KEY_CODE_POWER_SUPPLY_SYSTEM = "com.uaes.system.power.POWER_SUPPLY";
    /**
     * 空气系统
     */
    public final static String KEY_CODE_AIR_SYSTEM = "com.uaes.system.power.AIR";
    /**
     * 操作系统
     */
    public final static String KEY_CODE_OPERATION_SYSTEM = "com.uaes.system.power.OPERATION";
    /**
     * 综合评分
     */
    @PowerDefenderRepository.OverallRating
    public int overallRating;
    /**
     * 所有系统部件的状态
     *
     * @see #KEY_CODE_AIR_SYSTEM
     * @see #KEY_CODE_EXHAUST_SYSTEM
     * @see #KEY_CODE_FUEL_SUPPLY_SYSTEM
     * @see #KEY_CODE_IGNITION_SYSTEM
     * @see #KEY_CODE_LUBRICATION_SYSTEM
     * @see #KEY_CODE_OPERATION_SYSTEM
     * @see #KEY_CODE_POWER_SUPPLY_SYSTEM
     * @see #KEY_CODE_THERMAL_MANAGEMENT_SYSTEM
     * @see DMSystemPart
     */
    public Map<String, DMSystemPart> systemParts;

    @Retention(RetentionPolicy.SOURCE)
    @StringDef({
            KEY_CODE_LUBRICATION_SYSTEM, KEY_CODE_THERMAL_MANAGEMENT_SYSTEM, KEY_CODE_FUEL_SUPPLY_SYSTEM,
            KEY_CODE_IGNITION_SYSTEM, KEY_CODE_EXHAUST_SYSTEM, KEY_CODE_POWER_SUPPLY_SYSTEM,
            KEY_CODE_AIR_SYSTEM, KEY_CODE_OPERATION_SYSTEM
    })
    @interface SystemKeyCode {
    }

    /**
     * 系统部件的状态
     */
    public static class DMSystemPart {
        /**
         * 该部件的关键字 KEY_CODE, 外部代码不应该更改该属性
         *
         * @see #KEY_CODE_AIR_SYSTEM
         * @see #KEY_CODE_EXHAUST_SYSTEM
         * @see #KEY_CODE_FUEL_SUPPLY_SYSTEM
         * @see #KEY_CODE_IGNITION_SYSTEM
         * @see #KEY_CODE_LUBRICATION_SYSTEM
         * @see #KEY_CODE_OPERATION_SYSTEM
         * @see #KEY_CODE_POWER_SUPPLY_SYSTEM
         * @see #KEY_CODE_THERMAL_MANAGEMENT_SYSTEM
         */
        @SystemKeyCode
        private final String keyCode;
        /**
         * 错误代码
         */
        @PowerDefenderRepository.ErrorCode
        public int errorCode;
        /**
         * 实际错误数
         */

        public List<DMSystemPartError> errors;

        /**
         * 故障错误数量
         */
        public int errorsNum;

        public DMSystemPart(@NonNull String keyCode) {
            this.keyCode = keyCode;
        }

        /**
         * 获取错误数
         * 客户端代码应该调用此方法来避免空指针
         */
        @Deprecated
        public int getErrorCount() {
            return errors == null ? 0 : errors.size();
        }

        public List<DMSystemPartError> getErrors() {
            return errors;
        }
    }

    /**
     * 部件错误信息
     */
    public static class DMSystemPartError {
        /**
         * 错误主题
         */
        public String errorSubject;
        /**
         * 错误内容
         */
        public String errorContent;
    }
}
