package com.uaes.android.presenter.powerdefender;

import android.content.Context;
import android.databinding.BindingAdapter;
import android.databinding.BindingMethod;
import android.databinding.BindingMethods;
import android.support.v4.app.FragmentManager;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.uaes.android.R;
import com.uaes.android.presenter.powerdefender.pojo.CarFaultHistory;
import com.uaes.android.presenter.powerdefender.pojo.CarLocation;
import com.uaes.android.presenter.powerdefender.pojo.PowerPart;

import java.util.List;
import java.util.Objects;

/**
 * Created by diaokaibin@gmail.com on 2018/5/11.
 */
@BindingMethods({
        @BindingMethod(type = RecyclerView.class, attribute = "historyFaults", method = "bindFaults"),
        @BindingMethod(type = RecyclerView.class, attribute = "powerPart", method = "bindPowerPart"),
        @BindingMethod(type = RecyclerView.class, attribute = "carShop", method = "bindCarShop"),
        @BindingMethod(type = RecyclerView.class, attribute = "fragmentManager", method = "bindCarShop"),
        @BindingMethod(type = RecyclerView.class, attribute = "ctx", method = "bindCarShop"),
        @BindingMethod(type = RecyclerView.class, attribute = "navigator", method = "bindCarShop"),


})
public class RecyclerViewBindAdapter {

    @BindingAdapter(value = "historyFaults")
    public static void bindFaults(RecyclerView recyclerView, List<CarFaultHistory> faultHistoryList) {
        if (faultHistoryList == null) return;
        recyclerView.setLayoutManager(new LinearLayoutManager(recyclerView.getContext()));
        HistoryFaultAdapter adapter = new HistoryFaultAdapter();
        adapter.appendAll(faultHistoryList);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(recyclerView.getContext(), DividerItemDecoration.VERTICAL);
        dividerItemDecoration.setDrawable(Objects.requireNonNull(ContextCompat.getDrawable(recyclerView.getContext(), R.drawable.divider_rv_fault)));
        recyclerView.addItemDecoration(dividerItemDecoration);
        recyclerView.setAdapter(adapter);
    }


    @BindingAdapter(value = "powerPart")
    public static void bindPowerPart(RecyclerView recyclerView, List<PowerPart> parts) {
        if (parts == null || parts.size() == 0) return;
        recyclerView.setLayoutManager(new LinearLayoutManager(recyclerView.getContext()));
        PowerPartAdapter adapter = new PowerPartAdapter();
        adapter.appendAll(parts);
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(recyclerView.getContext(), DividerItemDecoration.VERTICAL);
        dividerItemDecoration.setDrawable(Objects.requireNonNull(ContextCompat.getDrawable(recyclerView.getContext(), R.drawable.divider_rv_fault)));
        recyclerView.addItemDecoration(dividerItemDecoration);
        recyclerView.setAdapter(adapter);
    }

    @BindingAdapter(value = {"carShop", "fragmentManager", "ctx", "navigator",})
    public static void bindCarShop(RecyclerView recyclerView, CarLocation carLocation, FragmentManager fragmentManager, Context ctx, PowerNavigator navigator) {
        if (carLocation == null || carLocation.mShopList == null || carLocation.mShopList.size() == 0)
            return;
        recyclerView.setLayoutManager(new LinearLayoutManager(recyclerView.getContext()));
        CarShopAdapter shopAdapter = new CarShopAdapter(new CarToShopViewModel(fragmentManager, ctx, navigator), carLocation.mLocation);
        recyclerView.setAdapter(shopAdapter);
        shopAdapter.appendAll(carLocation.mShopList);
//        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(Objects.requireNonNull(recyclerView.getContext()), DividerItemDecoration.VERTICAL);
//        dividerItemDecoration.setDrawable(Objects.requireNonNull(ContextCompat.getDrawable(Objects.requireNonNull(recyclerView.getContext()), R.drawable.divider_bg)));
//
//        int itemDecorationCount = recyclerView.getItemDecorationCount();
//        Timber.tag("-----").d(" itemDecorationCount  "+ itemDecorationCount);
//        recyclerView.addItemDecoration(dividerItemDecoration);

    }

}
