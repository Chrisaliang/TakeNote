package com.uaes.android.data;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.LocalBroadcastManager;

import com.alibaba.sdk.android.push.MessageReceiver;
import com.alibaba.sdk.android.push.notification.CPushMessage;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.uaes.android.R;
import com.uaes.android.common.Intents;
import com.uaes.android.data.mapper.MessageCenterMapper;
import com.uaes.android.data.room.CacheDao;
import com.uaes.android.data.room.MessageCenterEntity;
import com.uaes.android.domain.MessageCenterRepository;
import com.uaes.android.presenter.MainActivity;
import com.uaes.android.tts.VoiceSpeakerServer;

import java.lang.reflect.Type;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicInteger;

import javax.inject.Inject;

import dagger.android.AndroidInjection;
import io.reactivex.Single;
import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import io.reactivex.schedulers.Schedulers;
import timber.log.Timber;

public class AliPushMessageReceiver extends MessageReceiver {

    private static final String REC_TAG = "AliPushMessageReceiver";

    public static final String NOTIFICATION_CHANNEL_ID = "com.uaes.iot.CHANNEL_ID";
    private final static AtomicInteger c = new AtomicInteger(0);
    private static final String EXT_PARAMETER_TYPE = "type";
    private static final String EXT_PARAMETER_TITLE = "title";
    private static final String EXT_PARAMETER_BODY = "body";
    private static final String EXT_PARAMETER_MESSAGE_CLASS = "messageClass";
    private static final String EXT_PARAMETER_SYSTEM_TIME = "systemTime";

    @Inject
    MessageCenterRepository repository;

    @Inject
    CacheDao cacheDao;

    @Inject
    LocalBroadcastManager manager;

    @Inject
    Gson gson;

    private static final MessageCenterMapper mapper = new MessageCenterMapper();
    private Disposable disposable;
    private static final String TARGET_PATTERN = "yyyy-MM-dd HH:mm";
    private SimpleDateFormat sdf;

    public static void sendNotification(Context context, MessageCenterEntity msg) {
        int unicodeId = getID();
        NotificationCompat.Builder builder =
                new NotificationCompat.Builder(context, NOTIFICATION_CHANNEL_ID)
                        .setContentTitle(msg.title)
                        .setContentText(msg.msgContent)
                        .setContentIntent(PendingIntent.getActivity(context, unicodeId,
                                getIntent(context), PendingIntent.FLAG_CANCEL_CURRENT))
                        .setSmallIcon(R.mipmap.ic_launcher)
                        .setAutoCancel(true)
                        .setNumber(666);
        NotificationManager manager =
                (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        if (manager != null) {
            manager.notify(unicodeId, builder.build());
        }
    }

    private static int getID() {
        return c.incrementAndGet();
    }

    @Override
    public void onNotification(Context context, String title,
                               String summary, Map<String, String> extraMap) {
        Timber.tag(REC_TAG).e(
                "Receive notification, title: %s, summary: %s, extraMap: %s.",
                title,
                summary,
                extraMap.toString());
    }

    @Override
    public void onMessage(Context context, CPushMessage cPushMessage) {
        Timber.tag(REC_TAG).e(
                "onMessage, messageId: %s, title: %s, content: %s.",
                cPushMessage.getMessageId(),
                cPushMessage.getTitle(),
                cPushMessage.getContent());

        MessageCenterEntity msg = parseMsg(cPushMessage);

        if (msg == null) return;

        Intent broadcast = new Intent(Intents.ACTION_POWER_TRAIN_GUARD);
        manager.sendBroadcast(broadcast);

        saveMsgToDb(context, msg);

    }

    @Nullable
    private MessageCenterEntity parseMsg(CPushMessage cPushMessage) {
        Type type = new TypeToken<Map<String, String>>() {
        }.getType();
        Map<String, String> map
                = gson.fromJson(cPushMessage.getContent(), type);

        //            "{" +
        //            "\"TYPE\":\"fuelWarn\"," +                // maintenance\fuelWarn\
        //            "\"title\":\"消息推送测试推荐\"," +
        //            "\"messageClass\":\"通知\"," +            // 通知\预警\故障
        //            "\"systemTime\":\"2017-11-17 13:32:22\"," +
        //            "\"body\":推荐警告你的车子已经没有机油了警告你的车子已经没有机油了" +
        //            "}"

        String msgParaType = map.get(EXT_PARAMETER_TYPE);

        if (!repository.isReceive(msgParaType)) return null;

        String msgType = map.get(EXT_PARAMETER_MESSAGE_CLASS);

        MessageCenterEntity msg = new MessageCenterEntity();

        msg.msgTime = formatDate(map.get(EXT_PARAMETER_SYSTEM_TIME));
        msg.msgTimeStamp = formatTimeStamp(map.get(EXT_PARAMETER_SYSTEM_TIME));

        msg.msgContent = map.get(EXT_PARAMETER_BODY);
        msg.title = map.get(EXT_PARAMETER_TITLE);
        msg.contentJson = cPushMessage.getContent();
        msg.messageClass = msgType;
        switch (msg.messageClass) {
            case "故障":
                msg.msgType = 1;
                break;
            case "预警":
                msg.msgType = 2;
                break;
            case "通知":
                msg.msgType = 3;
                break;

        }
        return msg;
    }

    private long formatTimeStamp(String msgTime) {
        return Objects.requireNonNull(getDate(msgTime)).getTime();
    }

    private void saveMsgToDb(Context context, MessageCenterEntity msg) {

        Single.just(msg)
                .subscribeOn(Schedulers.io())
                .observeOn(Schedulers.io())
                .subscribe(new SingleObserver<MessageCenterEntity>() {
                    @Override
                    public void onSubscribe(Disposable d) {
                        disposable = d;
                    }

                    @Override
                    public void onSuccess(MessageCenterEntity entity) {
                        cacheDao.insertMessageCenter(entity);
                        disposable.dispose();
                        repository.onSaveMessage(mapper.mapper(entity));
                    }

                    @Override
                    public void onError(Throwable e) {
                        Timber.tag(REC_TAG).e(e);
                        if (disposable != null)
                            disposable.dispose();
                    }
                });
        sendNotification(context, msg);
    }

    @Override
    public void onNotificationOpened(Context context, String title,
                                     String summary, String extraMap) {
        Timber.tag(REC_TAG).e("onNotificationOpened, title: %s, summary: %s, extraMap: %s."
                , title, summary, extraMap);
    }

    @Override
    protected void onNotificationClickedWithNoAction(Context context, String title,
                                                     String summary, String extraMap) {
        Timber.tag(REC_TAG).e("onNotificationClickedWithNoAction, title: %s, summary: %s, extraMap: %s.",
                title, summary, extraMap);
    }

    @Override
    protected void onNotificationReceivedInApp(Context context, String title, String summary,
                                               Map<String, String> extraMap, int openType,
                                               String openActivity, String openUrl) {
        Timber.tag(REC_TAG).e(
                "onNotificationReceivedInApp, title: %s, summary: %s, extraMap: %s, openType: %d, openActivity: %s, openUrl: %s",
                title, summary, extraMap, openType, openActivity, openUrl);
    }

    @Override
    protected void onNotificationRemoved(Context context, String messageId) {
        Timber.tag(REC_TAG).e("onNotificationRemoved messageId: %s", messageId);
    }

    private static Intent getIntent(Context context) {
        Intent intent = new Intent(context, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
        intent.putExtra(MainActivity.EXTRA_SELECTED_ITEM, R.id.main_tab_item_message_center);
        return intent;
    }

    public static void sendToVoiceSpeak(Context context, String voiceContent, String textContent) {
        Intent service = new Intent(context, VoiceSpeakerServer.class);
        service.putExtra(VoiceSpeakerServer.EXTRA_VOICE_CONTENT, voiceContent);
        service.putExtra(VoiceSpeakerServer.EXTRA_TEXT_CONTENT, textContent);
        context.startService(service);
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        Timber.tag(REC_TAG).e(intent.getAction());
        AndroidInjection.inject(this, context);
        super.onReceive(context, intent);
    }

    private String formatDate(String msgTime) {
        sdf.applyPattern(TARGET_PATTERN);
        return sdf.format(getDate(msgTime));
    }

    @Nullable
    private Date getDate(String msgTime) {
        if (sdf == null) sdf = new SimpleDateFormat(TARGET_PATTERN, Locale.CHINA);
        sdf.applyPattern("yyyy-MM-dd HH:mm:ss");
        Date date = null;
        try {
            date = sdf.parse(msgTime);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date;
    }

}
