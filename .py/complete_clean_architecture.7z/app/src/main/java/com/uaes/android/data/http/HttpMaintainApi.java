package com.uaes.android.data.http;

import com.uaes.android.data.json.CommonResponse;
import com.uaes.android.data.json.MaintainRecordJson;
import com.uaes.android.data.json.MaintainSettingJson;
import com.uaes.android.data.json.MaintainStatusJson;

import java.util.List;

import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface HttpMaintainApi {
    String TYPE_DAY = "day";
    String TYPE_MILES = "mileage";

    /**
     * 查询保养状态
     */
    @GET("/secretary/v1/maintenance/getBase")
    Call<CommonResponse<MaintainStatusJson>> queryStatus();

    /**
     * 读取保养设置
     */
    @GET("/secretary/v1/maintenance/setting")
    Call<CommonResponse<MaintainSettingJson>> querySetting();

    /**
     * 更新保养设置
     * {
     * "pushFlag": false,
     * "pushTimeType": "2",
     * "pushFrequency": "1"
     * }
     */
    @POST("/secretary/v1/maintenance/setting")
    Call<ResponseBody> updateSetting(@Body RequestBody body);


    /**
     * 查询保养记录
     */
    @GET("/secretary/v1/maintenance/record")
    Call<CommonResponse<List<MaintainRecordJson>>> queryRecord();


    /**
     * 更新保养评分
     * <p>
     * {
     * "recordId": 123,
     * "efficientService": 4,
     * "friendlyAttitude": 4,
     * "transparentFees": 5
     * }
     */
    @POST("/secretary/v1/maintenance/record/evaluation")
    Call<ResponseBody> ratingRecord(@Body RequestBody body);

}
