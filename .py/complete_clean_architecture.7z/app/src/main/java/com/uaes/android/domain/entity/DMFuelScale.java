package com.uaes.android.domain.entity;

import android.support.annotation.Nullable;

/**
 * 用油明细
 */
public final class DMFuelScale {
    /**
     * 怠速油耗
     */
    public int idleUse;

    /**
     * 空调油耗
     */
    public int acUse;

    /**
     * 行驶油耗
     */
    public int driverUse;

    /**
     * 激烈驾驶油耗
     */
    public int otherUse;

    /**
     * 该油耗的日期 日期格式例子: 2018-01-16
     */
    @SuppressWarnings("WeakerAccess")
    @Nullable
    public String nowDate;

    @Override
    public String toString() {
        return "DMFuelScale{" +
                "idleUse=" + idleUse +
                ", acUse=" + acUse +
                ", driverUse=" + driverUse +
                ", otherUse=" + otherUse +
                ", nowDate='" + nowDate + '\'' +
                '}';
    }

    public DMFuelScale(int idleUse, int acUse, int driverUse, int otherUse) {
        this.idleUse = idleUse;
        this.acUse = acUse;
        this.driverUse = driverUse;
        this.otherUse = otherUse;
    }

    public DMFuelScale(float idleUse, float acUse, float driverUse, float otherUse) {
        this((int) idleUse, (int) acUse, (int) driverUse, (int) otherUse);
    }
}
