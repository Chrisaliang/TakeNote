package com.uaes.android.presenter.powerdefender.fragment;

import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.databinding.FragmentPowerDefenderComponentBinding;
import com.uaes.android.domain.entity.DMPowerStatus;
import com.uaes.android.presenter.powerdefender.PowerConstant;
import com.uaes.android.presenter.powerdefender.pojo.DPartError;
import com.uaes.android.presenter.powerdefender.pojo.PowerPart;
import com.uaes.android.presenter.powerdefender.viewmodel.PowerComponentViewModel;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by diaokaibin@gmail.com on 2018/5/9.
 */
public class PowerDefenderComponentFragment extends PowerDefenderBaseFragment {
    public static final String TAG = "PowerDefenderAirSysFragment";
    private FragmentPowerDefenderComponentBinding mComponentBinding;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mComponentBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_power_defender_component, container, false);
        mComponentBinding.setLifecycleOwner(this);
        return mComponentBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        PowerComponentViewModel powerComponentViewModel = ViewModelProviders.of(this).get(PowerComponentViewModel.class);
        mComponentBinding.setPowerVM(powerComponentViewModel);

        Bundle arguments = getArguments();
        if (arguments != null) {
            String type = arguments.getString(PowerConstant.BUNDLE_DTAT_TO_PART_TYPE);
            if (type != null) {
                switch (type) {
                    case DMPowerStatus.KEY_CODE_LUBRICATION_SYSTEM:  // 润滑系统
                        type = getResources().getString(R.string.power_tv_title_lubrication);
                        break;

                    case DMPowerStatus.KEY_CODE_THERMAL_MANAGEMENT_SYSTEM: // 热管理系统
                        type = getResources().getString(R.string.power_tv_title_power_thermal_management);
                        break;
                    case DMPowerStatus.KEY_CODE_FUEL_SUPPLY_SYSTEM: // 供油系统
                        type = getResources().getString(R.string.power_tv_title_fuel_supply);
                        break;
                    case DMPowerStatus.KEY_CODE_IGNITION_SYSTEM: // 点火系统
                        type = getResources().getString(R.string.power_tv_title_ignition);
                        break;
                    case DMPowerStatus.KEY_CODE_EXHAUST_SYSTEM: // 排气系统
                        type = getResources().getString(R.string.power_tv_title_exhaust);
                        break;
                    case DMPowerStatus.KEY_CODE_POWER_SUPPLY_SYSTEM: // 供电系统
                        type = getResources().getString(R.string.power_tv_title_power_supply);
                        break;
                    case DMPowerStatus.KEY_CODE_AIR_SYSTEM: // 空气系统
                        type = getResources().getString(R.string.power_tv_title_air);
                        break;
                    case DMPowerStatus.KEY_CODE_OPERATION_SYSTEM: // 操作系统
                        type = getResources().getString(R.string.power_tv_title_operation);
                        break;
                }

                ArrayList<DPartError> errors = arguments.getParcelableArrayList(PowerConstant.BUNDLE_DTAT_TO_PART);
                if (errors != null && errors.size() > 0) {
                    List<PowerPart> parts = new ArrayList<>();
                    for (int i = 0; i < errors.size(); i++) {
                        PowerPart part = new PowerPart();
                        part.title = type;
                        part.errorSubject = errors.get(i).errorSubject;
                        part.errorContent = errors.get(i).errorContent;
                        parts.add(part);

                    }

                    powerComponentViewModel.setData(parts);

                }
            }

        }

        mComponentBinding.ivPowerComponentClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mNavigator.onBack();
            }
        });
    }


}
