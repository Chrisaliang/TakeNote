package com.uaes.android.data.json;

import com.google.gson.annotations.SerializedName;

public class MessageMqttJson {

    // {
    //    "TY": "CTR",
    //    "deviceName": "LNBSCUAK5HF043610",
    //    "fltlvl": 2,
    //    "nowDate": 1528329600000,
    //    "textContent": "刹车系统发生故障，可能导致刹车性能受损，注意低速行驶，建议立刻检查维修",
    //    "title": "刹车助力失效",
    //    "voiceContent": "刹车助力失效，注意低速行驶，建议立刻检查维修"
    // }

    @SerializedName("deviceName")
    public String carVin;

    @SerializedName("TY")
    public String commandType;

    @SerializedName("fltlvl")
    public int msgType;

    @SerializedName("nowDate")
    public long msgTime;

    @SerializedName("title")
    public String msgTitle;

    @SerializedName("voiceContent")
    public String voiceContent;

    @SerializedName("textContent")
    public String textContent;
}
