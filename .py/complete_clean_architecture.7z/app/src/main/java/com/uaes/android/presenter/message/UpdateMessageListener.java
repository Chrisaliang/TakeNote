package com.uaes.android.presenter.message;

public interface UpdateMessageListener {

    void onItemUpdate(MessageCenterMsgItem item);
}
