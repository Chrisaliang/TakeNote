package com.uaes.android.data;

import com.uaes.android.data.http.Http4SShopApi;
import com.uaes.android.data.json.S4ShopJson;
import com.uaes.android.data.mapper.S4ShopMapper;
import com.uaes.android.domain.S4ShopRepository;
import com.uaes.android.domain.entity.DM4SShop;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class S4ShopRepositoryImp implements S4ShopRepository {

    private Http4SShopApi api;

    public S4ShopRepositoryImp(Http4SShopApi api) {
        this.api = api;
    }

    @Override
    public List<DM4SShop> queryList(String province, double latitude, double longitude) throws Exception {
        List<S4ShopJson> msgContent =
                Objects.requireNonNull(api.getShops(province, longitude + "," + latitude).execute().body())
                        .msgContent;
        if (msgContent != null && msgContent.size() > 0) {
            List<DM4SShop> shops = new ArrayList<>();
            for (S4ShopJson item : msgContent) {
                shops.add(S4ShopMapper.map(item));
            }
            return shops;
        }
        return null;
    }
}
