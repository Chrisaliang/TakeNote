package com.uaes.android.presenter.maintainsecretary;

import android.databinding.DataBindingUtil;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.databinding.MaintainItemDriveSchemeItemBinding;

import java.util.ArrayList;
import java.util.List;

import timber.log.Timber;

/**
 * Created by ${GY} on 2018/5/17
 * des：
 */
public class MaintainDriveSchemeAdapter extends RecyclerView.Adapter<MaintainDriveSchemeAdapter.MaintainDriveSchemeViewHolder> {

    private ArrayList<MaintainDriveSchemeItem> dataList;
    private static final String TAG = "MaintaiDriveShmAdapter";
    private MaintainSchemeItemOnClickListener maintainSchemeItemOnClickListener;

    MaintainDriveSchemeAdapter() {
        dataList = new ArrayList<>();
    }

    @NonNull
    @Override
    public MaintainDriveSchemeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        MaintainItemDriveSchemeItemBinding itemBinding = DataBindingUtil.inflate(
                LayoutInflater.from(parent.getContext()),
                R.layout.maintain_item_drive_scheme_item,
                parent, false);
        return new MaintainDriveSchemeViewHolder(itemBinding);
    }

    @Override
    public void onBindViewHolder(@NonNull MaintainDriveSchemeViewHolder holder, int position) {
        holder.bind(dataList.get(position));
    }

    @Override
    public int getItemCount() {
        return dataList.size();
    }

    void updateALL(List<MaintainDriveSchemeItem> maintainDriveSchemeItems) {
        dataList.clear();
        dataList.addAll(maintainDriveSchemeItems);
        Timber.tag(TAG).w("dataList.size:%s", dataList.size());
        notifyDataSetChanged();
    }

    private void selectItemAt(int position) {
        Timber.tag(TAG).w("MaintainAppointViewHolder:onClick:%s", position);
        for (int i = 0; i < dataList.size(); i++) {
            if (i == position) {
                dataList.get(position).isChoice = true;
            } else {
                dataList.get(i).isChoice = false;
            }
        }
        notifyDataSetChanged();
    }

    class MaintainDriveSchemeViewHolder extends RecyclerView.ViewHolder implements MaintainItemOnClickListener {
        private MaintainItemDriveSchemeItemBinding itemBinding;
        private MaintainDriveSchemeItem item;

        MaintainDriveSchemeViewHolder(MaintainItemDriveSchemeItemBinding itemBinding) {
            super(itemBinding.getRoot());
            this.itemBinding = itemBinding;
        }

        void bind(MaintainDriveSchemeItem item) {
            this.item = item;
            itemBinding.setListener(this);
            itemBinding.setItem(item);
            itemBinding.executePendingBindings();
        }


        @Override
        public void onClick(int type, int position) {
            if (item.isChoice) return;
            selectItemAt(position);
            if (maintainSchemeItemOnClickListener != null) {
                maintainSchemeItemOnClickListener.onSchemeItemClick(position);
            }
        }
    }

    public void setMaintainSchemeItemOnClickListener(MaintainSchemeItemOnClickListener maintainSchemeItemOnClickListener) {
        this.maintainSchemeItemOnClickListener = maintainSchemeItemOnClickListener;
    }

    interface MaintainSchemeItemOnClickListener {
        void onSchemeItemClick(int position);
    }
}
