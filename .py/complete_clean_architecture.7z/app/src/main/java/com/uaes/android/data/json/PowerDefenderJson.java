package com.uaes.android.data.json;

import com.google.gson.annotations.SerializedName;

import java.util.HashMap;
import java.util.List;

/**
 * Created by diaokaibin@gmail.com on 2018/5/28.
 * 动力卫士
 */
public class PowerDefenderJson {

    @SerializedName("powerMark")
    public String powerMark;
    @SerializedName("powerDetails")
    public List<HashMap<String, TypeKey>> powerDetails;

    public static class TypeKey {
        @SerializedName("firLvl")
        public int firLvl;

        @SerializedName("problemNum")
        public int problemNum;
        @SerializedName("seriousProblems")
        public List<SeriousProblemsBean> seriousProblems;

        public static class SeriousProblemsBean {
            @SerializedName("textcontent")
            public String textcontent;
            @SerializedName("title")
            public String title;
        }
    }
}
