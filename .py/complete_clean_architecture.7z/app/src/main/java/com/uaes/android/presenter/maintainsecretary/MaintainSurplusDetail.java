package com.uaes.android.presenter.maintainsecretary;

/**
 * Created by ${GY} on 2018/5/21
 * des：
 */
public class MaintainSurplusDetail {
    public int type;
    public String value;

    MaintainSurplusDetail(int type, String value) {
        this.type = type;
        this.value = value;
    }
}
