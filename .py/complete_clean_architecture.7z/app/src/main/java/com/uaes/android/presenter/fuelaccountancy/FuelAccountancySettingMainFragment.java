package com.uaes.android.presenter.fuelaccountancy;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.presenter.BaseFragment;


//一级main
public class FuelAccountancySettingMainFragment extends BaseFragment implements FuelAccountancyNavigator {

    private final FuelAccountancyStationSettingFragment stationSettingFragment = new FuelAccountancyStationSettingFragment();
    private final FuelAccountancySettingSuccessFragment settingSuccessFragment = new FuelAccountancySettingSuccessFragment();
    private final FuelAccountancyMainFragment fuelAccountancyMainFragment = new FuelAccountancyMainFragment();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fuel_accountancy_container_fragment, container, false);
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (savedInstanceState == null) {
            getChildFragmentManager().beginTransaction()
                    .replace(R.id.fuel_accountancy_fragment_container, fuelAccountancyMainFragment)
                    .commit();
        }
    }

    @Override
    public void goToSetting() {
        getChildFragmentManager().beginTransaction()
                .replace(R.id.fuel_accountancy_fragment_container, stationSettingFragment)
                .addToBackStack("toSetting")
                .commit();
    }

    @Override
    public void goToSettingSuccess() {
        getChildFragmentManager().beginTransaction()
                .replace(R.id.fuel_accountancy_fragment_container, settingSuccessFragment)
                .addToBackStack("settingSuccess")
                .commit();
    }

    @Override
    public void back() {
        getChildFragmentManager().popBackStack();
    }


    @Override
    public void onAttachFragment(Fragment childFragment) {
        super.onAttachFragment(childFragment);
        if (childFragment instanceof FuelAccountancyFragment) {
            FuelAccountancyFragment fragment = (FuelAccountancyFragment) childFragment;
            fragment.navigator = this;
        }
    }


}
