package com.uaes.android.presenter.maintainsecretary;

import java.text.DecimalFormat;

public class MaintainAMapUtil {
    public static String getFriendlyLength(int lenMeter) {
        if (lenMeter > 10000) // 10 km
        {
            int dis = lenMeter / 1000;
            return dis + MaintainConstant.KILOMETER;
        }

        if (lenMeter > 1000) {
            float dis = (float) lenMeter / 1000;
            DecimalFormat format = new DecimalFormat("##0.0");
            String dStr = format.format(dis);
            return dStr + MaintainConstant.KILOMETER;
        }

        if (lenMeter > 100) {
            int dis = lenMeter / 50 * 50;
            return dis + MaintainConstant.METER;
        }

        int dis = lenMeter / 10 * 10;
        if (dis == 0) {
            dis = 10;
        }

        return dis + MaintainConstant.METER;
    }

    public static String getFriendlyTime(int second) {
        if (second > 3600) {
            int hour = second / 3600;
            int min = (second % 3600) / 60;
            return hour + "小时" + min + "分钟";
        }
        if (second >= 60) {
            int min = second / 60;
            return min + "分钟";
        }
        return second + "秒";
    }

}
