package com.uaes.android.data.http;

import com.uaes.android.data.json.CommonResponse;
import com.uaes.android.data.json.S4ShopJson;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

/**
 * 获取4S店列表
 */
public interface Http4SShopApi {

    /**
     * 获取4S店
     *
     * @param province 省份中文名称
     * @param latlong  经纬度格式:  "longitude,latitude"
     */
    @GET("/iss/v1/car/app/query4S")
    Call<CommonResponse<List<S4ShopJson>>> getShops(@Query("province") String province,
                                                    @Query("location") String latlong);
}
