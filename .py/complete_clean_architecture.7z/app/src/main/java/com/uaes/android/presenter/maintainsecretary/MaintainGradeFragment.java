package com.uaes.android.presenter.maintainsecretary;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.uaes.android.R;
import com.uaes.android.databinding.MaintainFragmentGradeBinding;

import javax.inject.Inject;

/**
 * Created by ${GY} on 2018/5/9
 * des：
 */
public class MaintainGradeFragment extends MaintainBaseFragment {
    private MaintainFragmentGradeBinding binding;
    private MaintainGradeViewModel maintainGradeViewModel;
    private static final String TAG = "MaintainGradeFragment_";
    @Inject
    ViewModelProvider.Factory factory;

    private Observer<Boolean> observer = new Observer<Boolean>() {
        @Override
        public void onChanged(@Nullable Boolean aBoolean) {
            //noinspection ConstantConditions
            if (aBoolean) {
                Toast.makeText(getContext(), "保存成功", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(getContext(), "保存失败", Toast.LENGTH_SHORT).show();
            }
            mNavigator.onBack();
        }
    };

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        maintainGradeViewModel = ViewModelProviders.of(this, factory).get(MaintainGradeViewModel.class);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater,
                R.layout.maintain_fragment_grade, container, false);
        binding.setLifecycleOwner(this);
        binding.setNavigator(mNavigator);
        maintainGradeViewModel.saveStatus.observe(this, observer);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding.setMaintainOnClickListener(maintainGradeViewModel);
        binding.setMaintainGradeViewModel(maintainGradeViewModel);
        initView();
    }


    private void initView() {
        maintainGradeViewModel.initData(getArguments());
    }

}
