package com.uaes.android.data.mapper;

import android.support.annotation.NonNull;

import com.uaes.android.data.json.DriverMasterDetailJson;
import com.uaes.android.data.json.DriverMasterPageJson;
import com.uaes.android.domain.entity.DMDriverMasterItem;
import com.uaes.android.domain.entity.DMDriverMasterPage;
import com.uaes.android.domain.entity.DMLatLng;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class DriverMasterJsonMapper {

    private static final String pattern = "yyyy.MM.dd\nHH:mm:ss";
    private static final SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern, Locale.CHINA);
    private List<DMDriverMasterItem> items;

    public DMDriverMasterPage map(@NonNull DriverMasterPageJson masterPageJson) {
        if (masterPageJson.drivingLevel == null && masterPageJson.metricsRatio == null)
            return DMDriverMasterPage.empty();
        DMDriverMasterPage dmDriverMasterPage = new DMDriverMasterPage();
        dmDriverMasterPage.titleSum = masterPageJson.drivingLevel.drivingStyle;
        dmDriverMasterPage.titleDsc = masterPageJson.drivingLevel.drivingDescription;
        if (!masterPageJson.metricsRatio.isEmpty()) {
            dmDriverMasterPage.acuteAcc = masterPageJson.metricsRatio.get(0).get("1");
            dmDriverMasterPage.acuteBreak = masterPageJson.metricsRatio.get(1).get("2");
            dmDriverMasterPage.acuteTurn = masterPageJson.metricsRatio.get(2).get("3");
            dmDriverMasterPage.continueAccAndDec = masterPageJson.metricsRatio.get(0).get("1");
            dmDriverMasterPage.nightDriver = masterPageJson.metricsRatio.get(0).get("1");
        }
        return dmDriverMasterPage;
    }

    public List<DMDriverMasterItem> map(@NonNull List<DriverMasterDetailJson> detailJson) {
        if (items == null)
            items = new ArrayList<>(detailJson.size() * 5 / 3);
        items.clear();
        for (DriverMasterDetailJson masterDetailJson : detailJson) {
            items.add(map(masterDetailJson));
        }
        return items;
    }

    private DMDriverMasterItem map(DriverMasterDetailJson json) {
        DMDriverMasterItem dmDriverMasterItem = new DMDriverMasterItem();
        dmDriverMasterItem.detailType = json.targetType;
        dmDriverMasterItem.dangerousRank = json.dangerLevel;
        dmDriverMasterItem.duration = json.continuedTime + " S";
        dmDriverMasterItem.time = simpleDateFormat.format(json.occurTime);
        dmDriverMasterItem.locationStr = json.location;

        double lng = 0, lat = 0;
        if (json.gps != null && json.gps.length() > 0) {
            String[] gps = json.gps.split(",");
            lng = Double.parseDouble(gps[0]);
            lat = Double.parseDouble(gps[1]);

        }
        dmDriverMasterItem.locations = new DMLatLng[]{
                new DMLatLng(lat, lng)
        };
        return dmDriverMasterItem;
    }
}
