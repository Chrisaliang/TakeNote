package com.uaes.android.data.json;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Chrisaliang on 2017/11/23.
 * general data receive obj
 */

@SuppressWarnings("WeakerAccess")
public class CommonResponse<T> {
    //{"msgCode":"10000","msg":"OK","content":{"CSthreshold":"7"},"status":1,"total":1}
    @SerializedName("msgCode")
    public String msgCode;
    @SerializedName("msg")
    public String msg;
    @SerializedName("content")
    public T msgContent;
    @SerializedName("status")
    public String status;
    @SerializedName("total")
    public String total;

    @Override
    public String toString() {
        return "CommonResponse{" +
                "msgCode='" + msgCode + '\'' +
                ", msg='" + msg + '\'' +
                ", msgContent=" + msgContent +
                ", status='" + status + '\'' +
                ", total='" + total + '\'' +
                '}';
    }
}
