package com.uaes.android.common;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;

public class ConnectionChecker {

    /**
     * 检测当前网络状态是否正常
     */
    @SuppressWarnings("BooleanMethodIsAlwaysInverted")
    public static boolean isOnline(ConnectivityManager cm) {
        NetworkInfo activeNetworkInfo = cm.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }
}
