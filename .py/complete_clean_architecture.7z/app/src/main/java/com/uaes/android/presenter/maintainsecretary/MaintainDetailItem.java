package com.uaes.android.presenter.maintainsecretary;

/**
 * Created by ${GY} on 2018/5/11
 * des：
 */
public class MaintainDetailItem {
    public int position;
    public String content;
    public String code;
    public boolean isChoice;

    MaintainDetailItem(int position, String content, String code, boolean isChoice) {
        this.position = position;
        this.content = content;
        this.isChoice = isChoice;
        this.code = code;
    }
}
