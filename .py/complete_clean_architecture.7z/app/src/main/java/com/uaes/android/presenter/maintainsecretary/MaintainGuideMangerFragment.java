package com.uaes.android.presenter.maintainsecretary;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.presenter.BaseFragment;

import java.util.Objects;

/**
 * Created by ${GY} on 2018/5/11
 * des：
 */
public class MaintainGuideMangerFragment extends BaseFragment implements MaintainNavigator {

    private MaintainAppointFragment maintainAppointFragment = new MaintainAppointFragment();
    private MaintainSettingsFragment maintainSettingsFragment = new MaintainSettingsFragment();
    private MaintainHistoryFragment maintainHistoryFragment = new MaintainHistoryFragment();
    private MaintainContentDetailFragment maintainContentDetailFragment = new MaintainContentDetailFragment();
    private MaintainQrCodeFragment maintainQrCodeFragment = new MaintainQrCodeFragment();
    private MaintainGradeFragment maintainGradeFragment = new MaintainGradeFragment();
    private MaintainPhoneAppointFragment maintainPhoneAppointFragment = new MaintainPhoneAppointFragment();
    private MaintainDetailFragment maintainDetailFragment = new MaintainDetailFragment();


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.maintain_guide_manger, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (savedInstanceState == null) {
            getChildFragmentManager()
                    .beginTransaction()
                    .replace(R.id.fl_maintain_content, maintainDetailFragment)
                    .commit();
        }
    }

    @Override
    public void onAttachFragment(Fragment childFragment) {
        super.onAttachFragment(childFragment);
        if (childFragment instanceof MaintainBaseFragment) {
            ((MaintainBaseFragment) childFragment).mNavigator = this;
        }
    }

    @Override
    public void showMaintainPoint() {
        setFragment(maintainAppointFragment, null);
    }

    @Override
    public void showSetting() {
        setFragment(maintainSettingsFragment, null);
    }

    @Override
    public void showHistory() {
        setFragment(maintainHistoryFragment, null);
    }

    @Override
    public void showMaintainContentDetail(int code) {
        Bundle bundle = new Bundle();
        bundle.putInt(MaintainConstant.MAINTAIN_CONTENT_TYPE, code);
        setFragment(maintainContentDetailFragment, bundle);
    }

    @Override
    public void showQRCode() {
        setFragment(maintainQrCodeFragment, null);
    }

    @Override
    public void showGrade(Bundle bundle) {
        setFragment(maintainGradeFragment, bundle);
    }

    @Override
    public void showPhoneAppoint(Bundle bundle) {
        setFragment(maintainPhoneAppointFragment, bundle);
    }

    @Override
    public void showDriveScheme(Bundle bundle) {
        double currentLongitude = bundle.getDouble(MaintainConstant.MAINTAIN_CURRENT_LONGITUDE);
        double currentLatitude = bundle.getDouble(MaintainConstant.MAINTAIN_CURRENT_LATITUDE);
        double longitude = bundle.getDouble(MaintainConstant.MAINTAIN_LONGITUDE);
        double latitude = bundle.getDouble(MaintainConstant.MAINTAIN_LATITUDE);
        String currentAddress = bundle.getString(MaintainConstant.MAINTAIN_CURRENT_ADDRESS);
        String address = bundle.getString(MaintainConstant.MAINTAIN_ADDRESS);

        Intent intent = new Intent();
        intent.setAction("AUTONAVI_STANDARD_BROADCAST_RECV");
        intent.putExtra("KEY_TYPE", 10007);
        intent.putExtra("EXTRA_SNAME", currentAddress);
        intent.putExtra("EXTRA_SLON", currentLongitude);
        intent.putExtra("EXTRA_SLAT", currentLatitude);
        intent.putExtra("EXTRA_DNAME", address);
        intent.putExtra("EXTRA_DLON", longitude);
        intent.putExtra("EXTRA_DLAT", latitude);
        intent.putExtra("EXTRA_DEV", 0);
        intent.putExtra("EXTRA_M", 0);
        Objects.requireNonNull(getContext()).sendBroadcast(intent);
    }


    @Override
    public void onBack() {
        getChildFragmentManager().popBackStack(null, 0);
    }

    private void setFragment(Fragment fragment, Bundle bundle) {
        if (bundle != null) {
            fragment.setArguments(bundle);
        }
        getChildFragmentManager()
                .beginTransaction()
                .replace(R.id.fl_maintain_content, fragment)
                .addToBackStack(null)
                .commit();
    }

}
