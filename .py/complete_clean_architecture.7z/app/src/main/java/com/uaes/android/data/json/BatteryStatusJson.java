package com.uaes.android.data.json;

import com.google.gson.annotations.SerializedName;

/**
 * 电池寿命
 */
public class BatteryStatusJson {

    /**
     * 读取时间
     * 格式： 2018-05-08 11:18:11
     */
    @SerializedName("nowDate")
    public String nowDate;

    /**
     * false 电池老化
     */
    @SerializedName("state")
    public boolean state;
}
