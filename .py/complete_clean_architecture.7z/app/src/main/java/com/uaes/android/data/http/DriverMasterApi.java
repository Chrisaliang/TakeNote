package com.uaes.android.data.http;

import com.uaes.android.data.json.CommonResponse;
import com.uaes.android.data.json.DriverMasterDetailJson;
import com.uaes.android.data.json.DriverMasterPageJson;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

/**
 * 驾驶达人接口
 */
public interface DriverMasterApi {

    /**
     * 驾驶达人 summary 界面
     *
     * @return driver master page
     */
    @GET("driving/v1/drivingtalent/metrics/{TYPE}")
    Call<CommonResponse<DriverMasterPageJson>> driverMasterPage(@Path("TYPE") int type);

    /**
     * 驾驶达人 详细列表
     *
     * @param execType   时间类型
     * @param targetType 驾驶类型
     * @return 详细列表
     */
    @GET("driving/v1/driving/detail/{execType}/{targetType}")
    Call<CommonResponse<List<DriverMasterDetailJson>>> driverMasterDetail(
            @Path("execType") int execType,
            @Path("targetType") int targetType);
}
