package com.uaes.android.presenter.powerdefender.fragment;

import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.databinding.FragmentPowerDefenderNearbyBinding;
import com.uaes.android.presenter.powerdefender.PowerDefenderOnClickListener;
import com.uaes.android.presenter.powerdefender.viewmodel.AutoRepairViewModel;

import javax.inject.Inject;

/**
 * Created by diaokaibin@gmail.com on 2018/5/9.
 */
public class PowerDefenderNearByFragment extends PowerDefenderBaseFragment implements PowerDefenderOnClickListener {


    private FragmentPowerDefenderNearbyBinding mNearbyBinding;

    @Inject
    ViewModelProvider.Factory mFactory;
    private AutoRepairViewModel mRepairViewModel;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mNearbyBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_power_defender_nearby, container, false);
        mNearbyBinding.setLifecycleOwner(this);
        return mNearbyBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mRepairViewModel = ViewModelProviders.of(this, mFactory).get(AutoRepairViewModel.class);
        mNearbyBinding.setPowerClickListener(this);
        mNearbyBinding.setAutoRepair(mRepairViewModel);
        mNearbyBinding.setFm(getFragmentManager());
        mNearbyBinding.setCtx(getContext());
        mNearbyBinding.setPowerNavigator(mNavigator);
        mRepairViewModel.doQuery();
//        Timber.tag("-----").d(" PowerDefenderNearByFragment  onViewCreated");

    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        Timber.tag("-----").d(" PowerDefenderNearByFragment  onCreate");
    }

    @Override
    public void onClick(int type) {
        mNavigator.onBack();
    }

    @Override
    public void onStop() {
        super.onStop();
        mRepairViewModel.cancleQuery();
    }
}
