package com.uaes.android.domain.usecase;

import com.uaes.android.domain.JobThread;
import com.uaes.android.domain.MaintainRepository;
import com.uaes.android.domain.SingleUseCase;
import com.uaes.android.domain.entity.DMMaintainSetting;

import io.reactivex.Single;
import io.reactivex.functions.Function;

public class MaintainSettingUpdate extends SingleUseCase<Boolean> {

    private MaintainRepository repository;

    private JobThread jobThread;

    private DMMaintainSetting dmMaintainSetting;

    public MaintainSettingUpdate(MaintainRepository repository, JobThread jobThread) {
        this.repository = repository;
        this.jobThread = jobThread;
    }

    @Override
    protected Single<Boolean> buildSingle() {
        return Single.just(repository).map(new Function<MaintainRepository, Boolean>() {
            @Override
            public Boolean apply(MaintainRepository repository) throws Exception {
                return dmMaintainSetting != null && repository.updateSetting(dmMaintainSetting);
            }
        }).subscribeOn(jobThread.provideWorker()).observeOn(jobThread.providerUi());
    }

    public void setSetting(DMMaintainSetting setting) {
        this.dmMaintainSetting = setting;
    }
}
