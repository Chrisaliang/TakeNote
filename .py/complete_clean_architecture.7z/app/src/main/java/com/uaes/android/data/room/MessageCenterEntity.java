package com.uaes.android.data.room;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import static com.uaes.android.data.room.Tables.MessageCenter.COLUMN_CONTENT;
import static com.uaes.android.data.room.Tables.MessageCenter.COLUMN_JSON;
import static com.uaes.android.data.room.Tables.MessageCenter.COLUMN_TIME;
import static com.uaes.android.data.room.Tables.MessageCenter.COLUMN_TIME_STAMP;
import static com.uaes.android.data.room.Tables.MessageCenter.COLUMN_TYPE;
import static com.uaes.android.data.room.Tables.MessageCenter.TABLE_NAME;

@Entity(tableName = TABLE_NAME)
public class MessageCenterEntity {

    static final int MESSAGE_TYPE_ALL = 0;
    public static final int MESSAGE_TYPE_MALFUNCTION = 1;
    public static final int MESSAGE_TYPE_WARNING = 2;
    public static final int MESSAGE_TYPE_NOTIFICATION = 3;

    public String title;//消息的头


    @PrimaryKey(autoGenerate = true)
    public long id; // 自增长id

    @ColumnInfo(name = COLUMN_TIME)
    public String msgTime; // 消息时间

    @ColumnInfo(name = COLUMN_TIME_STAMP)
    public long msgTimeStamp; // 消息时间戳

    @ColumnInfo(name = COLUMN_CONTENT)
    public String msgContent; // 消息内容

    @ColumnInfo(name = COLUMN_TYPE)
    @MsgType
    public int msgType;

    public String messageClass;//消息大类，APP 根据该key 决定推送汇总界面的显示

    @ColumnInfo(name = COLUMN_JSON)
    public String contentJson; // actual action

    @Retention(RetentionPolicy.SOURCE)
    @IntDef({
            MESSAGE_TYPE_ALL, MESSAGE_TYPE_MALFUNCTION,
            MESSAGE_TYPE_WARNING, MESSAGE_TYPE_NOTIFICATION
    })
    @interface MsgType {
    }
}
