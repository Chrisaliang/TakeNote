package com.uaes.android.presenter.maintainsecretary;

/**
 * Created by ${GY} on 2018/5/10
 * des：
 */
public interface MaintainConstant {

    String MAINTAIN_SERVICE_POINT = "maintain_service_point";
    String MAINTAIN_ATTITUDE_POINT = "maintain_attitude_point";
    String MAINTAIN_CHARGE_POINT = "maintain_charge_point";
    String MAINTAIN_HISTORY_POSITION_ITEM_ID = "maintain_history_position_item_id";
    //    String MAINTAIN_IS_ADD_COMMENT = "maintain_is_add_comment";
    String MAINTAIN_LATITUDE = "maintain_latitude";
    String MAINTAIN_NAVIGATION_TYPE = "maintain_navigation_type";
    String MAINTAIN_LONGITUDE = "maintain_longitude";
    String MAINTAIN_ADDRESS = "maintain_address";
    String MAINTAIN_CURRENT_ADDRESS = "maintain_current_address";
    String MAINTAIN_PHONE = "maintain_phone";
    String MAINTAIN_CURRENT_LATITUDE = "maintain_current_latitude";
    String MAINTAIN_CURRENT_LONGITUDE = "maintain_current_longitude";
    String MAINTAIN_CONTENT_TYPE = "maintain_content_type";

    String KILOMETER = "\u516c\u91cc";// "公里";
    String METER = "\u7c73";// "米";
    String TYPE = "\u7c7b\u522b"; // 类别
    String ADDRESS = "\u5730\u5740"; // 地址
}
