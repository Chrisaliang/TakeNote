package com.uaes.android.presenter.fuelaccountancy;

/**
 * @author qingxin.chen
 * Created by qingxin.chen on 2018/5/14.
 * <p>
 * 用油历史中左右选择年份的按钮的点击事件
 */
public interface FuelAcountancyHistoryOnYearSlideListener {

    void onDirectionClick(DirectionType type);

    enum DirectionType {
        LEFT, RIGHT
    }

}
