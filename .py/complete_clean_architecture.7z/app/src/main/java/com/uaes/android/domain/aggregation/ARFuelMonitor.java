package com.uaes.android.domain.aggregation;

import com.uaes.android.domain.entity.DMAccumulativeFuelConsumption;
import com.uaes.android.domain.entity.DMFuelConsumptionOfDay;

/**
 * 用油会计-用油监控 聚合类
 */
public class ARFuelMonitor extends Aggregation {
    /**
     * 经济性排名
     */
    public int rank;
    /**
     * 每日的 包公里油耗统计， 已经排序好了
     */
    public DMFuelConsumptionOfDay[] fuelConsumptionOfDay;

    /**
     * 累计油耗点, 用于绘制曲线
     */
    public DMAccumulativeFuelConsumption[] accumulativeFuelConsumptions;
}
