package com.uaes.android.domain.entity;

/**
 * 动力卫士体检报告
 */
public class DMPowerReport {
    /**
     * 问题说明
     */
    public String problemDescription;
    /**
     * 发生时间 格式: 2018.07.23
     */
    public String date;
    /**
     * 问题状态 是否已经解决
     */
    public boolean isResolved;
    /**
     * 解决问题的日期
     */
    public String resolvedDate;
}
