package com.uaes.android.domain.usecase;

import com.uaes.android.domain.JobThread;
import com.uaes.android.domain.MessageCenterRepository;
import com.uaes.android.domain.SingleUseCase;
import com.uaes.android.domain.entity.DMMessageCenterItem;

import io.reactivex.Single;
import io.reactivex.functions.Function;

public class MessageCenterMsgDelete extends SingleUseCase<Integer> {


    private MessageCenterRepository repository;

    private JobThread jobThread;

    private DMMessageCenterItem[] deleteItems;

    public MessageCenterMsgDelete(MessageCenterRepository repository, JobThread jobThread) {
        this.repository = repository;
        this.jobThread = jobThread;
    }

    public void setDeleteItems(DMMessageCenterItem... deleteItems) {
        this.deleteItems = deleteItems;
    }

    @Override
    protected Single<Integer> buildSingle() {
        return Single.just(repository)
                .map(new Function<MessageCenterRepository, Integer>() {
                    @Override
                    public Integer apply(MessageCenterRepository repository) {
                        return repository.deleteMessage(deleteItems);
                    }
                })
                .observeOn(jobThread.providerUi())
                .subscribeOn(jobThread.provideWorker());
    }
}
