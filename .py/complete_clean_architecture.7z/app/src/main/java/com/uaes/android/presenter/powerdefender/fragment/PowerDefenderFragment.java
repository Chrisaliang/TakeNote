package com.uaes.android.presenter.powerdefender.fragment;

import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.LocalBroadcastManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.common.Intents;
import com.uaes.android.databinding.FragmentPowerDefenderBinding;
import com.uaes.android.domain.entity.DMPowerStatus;
import com.uaes.android.presenter.powerdefender.PowerConstant;
import com.uaes.android.presenter.powerdefender.PowerPartOnClickListener;
import com.uaes.android.presenter.powerdefender.pojo.CarIndicateEntity;
import com.uaes.android.presenter.powerdefender.pojo.DPartError;
import com.uaes.android.presenter.powerdefender.viewmodel.CarStatusViewModel;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import javax.inject.Inject;

import static com.uaes.android.domain.entity.DMPowerStatus.KEY_CODE_AIR_SYSTEM;
import static com.uaes.android.domain.entity.DMPowerStatus.KEY_CODE_EXHAUST_SYSTEM;
import static com.uaes.android.domain.entity.DMPowerStatus.KEY_CODE_FUEL_SUPPLY_SYSTEM;
import static com.uaes.android.domain.entity.DMPowerStatus.KEY_CODE_IGNITION_SYSTEM;
import static com.uaes.android.domain.entity.DMPowerStatus.KEY_CODE_LUBRICATION_SYSTEM;
import static com.uaes.android.domain.entity.DMPowerStatus.KEY_CODE_OPERATION_SYSTEM;
import static com.uaes.android.domain.entity.DMPowerStatus.KEY_CODE_POWER_SUPPLY_SYSTEM;
import static com.uaes.android.domain.entity.DMPowerStatus.KEY_CODE_THERMAL_MANAGEMENT_SYSTEM;

/**
 * Created by diaokaibin@gmail.com on 2018/5/7.
 */
public class PowerDefenderFragment extends PowerDefenderBaseFragment implements PowerPartOnClickListener {

    private static final String FRAGMENT_TYPE_NEAR_BY = "1";
    private static final String FRAGMENT_TYPE_FAULT_HISTORY = "2";
    private static final String FRAGMENT_TYPE_AIR_SYS = "3";
    private FragmentPowerDefenderBinding dataBinding;

    @Inject
    ViewModelProvider.Factory mFactory;
    private CarStatusViewModel mCarStatusViewModel;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        dataBinding = DataBindingUtil.inflate(inflater, R.layout.fragment_power_defender, container, false);

        dataBinding.setLifecycleOwner(this);
        return dataBinding.getRoot();
    }


    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mCarStatusViewModel = ViewModelProviders.of(this, mFactory).get(CarStatusViewModel.class);
        dataBinding.setPowerClickListener(this);
        dataBinding.setCarStatusViewModel(mCarStatusViewModel);
        mCarStatusViewModel.doQuery();
    }


    @Override
    public void onClick(int type, CarIndicateEntity carIndicateEntity) {
        if (type == 1) {
            mNavigator.goNearByShop();
            return;
        } else if (type == 2) {
            mNavigator.goHistoryFault(FRAGMENT_TYPE_FAULT_HISTORY);
            return;
        }
        if (carIndicateEntity == null) return;
        if (carIndicateEntity.carIndicateStatus == 0) {
            return;
        }
        String key = "unknow";
        switch (type) {

            case 3:    // 空气系统
                key = KEY_CODE_AIR_SYSTEM;
                break;

            case 4:  // 点火系统
                key = KEY_CODE_IGNITION_SYSTEM;
                break;


            case 5:  // 供电系统

                key = KEY_CODE_POWER_SUPPLY_SYSTEM;
                break;


            case 6:  // 供油系统
                key = KEY_CODE_FUEL_SUPPLY_SYSTEM;
                break;

            case 7:  // 操作系统
                key = KEY_CODE_OPERATION_SYSTEM;
                break;

            case 8:  // 热管理系统
                key = KEY_CODE_THERMAL_MANAGEMENT_SYSTEM;
                break;

            case 9:  // 排气系统
                key = KEY_CODE_EXHAUST_SYSTEM;
                break;

            case 10:  // 润滑系统
                key = KEY_CODE_LUBRICATION_SYSTEM;

                break;

        }

        List<DMPowerStatus.DMSystemPartError> errors = mCarStatusViewModel.getDMSPartErrors(key);
        if (errors != null && errors.size() > 0) {

            ArrayList<DPartError> arrayList = new ArrayList<>();
            for (int i = 0; i < errors.size(); i++) {
                DPartError dPartError = new DPartError();
                DMPowerStatus.DMSystemPartError partError = errors.get(i);
                dPartError.errorContent = partError.errorContent;
                dPartError.errorSubject = partError.errorSubject;
                arrayList.add(dPartError);

            }
            Bundle bundle = new Bundle();
            bundle.putParcelableArrayList(PowerConstant.BUNDLE_DTAT_TO_PART, arrayList);
            bundle.putString(PowerConstant.BUNDLE_DTAT_TO_PART_TYPE, key);
            mNavigator.goComponentDetails(bundle, key);
        } else {
            Bundle bundle = new Bundle();
            bundle.putString(PowerConstant.BUNDLE_DTAT_TO_PART_TYPE, key);
            mNavigator.goComponentDetails(bundle, key);
        }

    }

    private BroadcastReceiver updateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (Intents.ACTION_POWER_TRAIN_GUARD.equals(intent.getAction()))
                mCarStatusViewModel.doQuery();
        }
    };

    @Override
    public void onStart() {
        super.onStart();
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(Intents.ACTION_POWER_TRAIN_GUARD);
        LocalBroadcastManager.getInstance(Objects.requireNonNull(getContext())).registerReceiver(updateReceiver, intentFilter);
    }

    @Override
    public void onStop() {
        super.onStop();
        LocalBroadcastManager.getInstance(Objects.requireNonNull(getContext())).unregisterReceiver(updateReceiver);
        mCarStatusViewModel.cancleQuery();

    }
}
