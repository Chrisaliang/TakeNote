package com.uaes.android.presenter.fuelaccountancy;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

import com.github.mikephil.charting.charts.BarChart;
import com.uaes.android.R;

import timber.log.Timber;

/**
 * Created by diaokaibin@gmail.com on 2018/6/12.
 */
public class FuelBarChart extends BarChart {
    public FuelBarChart(Context context) {
        super(context);
    }

    public FuelBarChart(Context context, AttributeSet attrs) {
        super(context, attrs);
    }

    public FuelBarChart(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }


    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
//        getParent().requestDisallowInterceptTouchEvent(true);
        requestDisallowInterceptTouchEvent((ViewGroup) findViewById(R.id.fuel_accountancy_consume_barchart), true);
        return super.dispatchTouchEvent(ev);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        switch (event.getAction()) {
            case MotionEvent.ACTION_DOWN:
                Timber.tag("FuelBarChart").i(" event  ACTION_DOWN");
                break;
            case MotionEvent.ACTION_MOVE:
                Timber.tag("FuelBarChart").i(" event  ACTION_MOVE");
                break;
            case MotionEvent.ACTION_UP:
                Timber.tag("FuelBarChart").i(" event  ACTION_UP");
                break;
            case MotionEvent.ACTION_CANCEL:
                Timber.tag("FuelBarChart").i(" event  ACTION_CANCEL ");
                break;


        }
        return super.onTouchEvent(event);
    }


    private void requestDisallowInterceptTouchEvent(ViewGroup v, boolean disallowIntercept) {
        v.requestDisallowInterceptTouchEvent(disallowIntercept);
        int childCount = v.getChildCount();
        for (int i = 0; i < childCount; i++) {
            View child = v.getChildAt(i);
            if (child instanceof ViewGroup) {
                requestDisallowInterceptTouchEvent((ViewGroup) child, disallowIntercept);
            }
        }
    }
}
