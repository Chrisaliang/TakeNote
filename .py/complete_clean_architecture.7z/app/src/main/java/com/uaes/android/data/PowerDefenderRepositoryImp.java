package com.uaes.android.data;

import com.google.gson.Gson;
import com.uaes.android.data.http.HttpPowerDefenderApi;
import com.uaes.android.data.json.CommonResponse;
import com.uaes.android.data.json.PowerDefenderJson;
import com.uaes.android.data.json.PowerHistoryFaultReportJson;
import com.uaes.android.data.mapper.HistoryFaultReportMapper;
import com.uaes.android.data.mapper.PowerDefenderMapper;
import com.uaes.android.domain.PowerDefenderRepository;
import com.uaes.android.domain.entity.DMPowerReport;
import com.uaes.android.domain.entity.DMPowerStatus;

import java.util.List;

import retrofit2.Call;
import retrofit2.Response;

public class PowerDefenderRepositoryImp implements PowerDefenderRepository {

    private HttpPowerDefenderApi mApi;
    private Gson mGson;

    private PowerDefenderMapper mMapper = new PowerDefenderMapper();
    private HistoryFaultReportMapper mReportMapper = new HistoryFaultReportMapper();

    public PowerDefenderRepositoryImp(HttpPowerDefenderApi httpPowerDefenderApi, Gson gson) {
        mApi = httpPowerDefenderApi;
        mGson = gson;
    }

    @Override
    public DMPowerStatus queryPowerStatus() throws Exception {
        DMPowerStatus powerStatus;
        Call<CommonResponse<PowerDefenderJson>> call = mApi.queryPower();
        Response<CommonResponse<PowerDefenderJson>> response = call.execute();
        powerStatus = mMapper.apply(response.body());
        return powerStatus;
    }

    @Override
    public List<DMPowerReport> queryPowerReport() throws Exception {

        Call<CommonResponse<List<PowerHistoryFaultReportJson>>> call = mApi.queryHistoryFaultReport();
        Response<CommonResponse<List<PowerHistoryFaultReportJson>>> response = call.execute();
        return mReportMapper.apply(response.body());
    }
}
