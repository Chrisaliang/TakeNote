package com.uaes.android.domain.usecase;

import com.uaes.android.domain.JobThread;
import com.uaes.android.domain.MaintainRepository;
import com.uaes.android.domain.SingleUseCase;
import com.uaes.android.domain.entity.DMMaintainSetting;

import io.reactivex.Single;
import io.reactivex.functions.Function;

/**
 * 查询用保养秘书设置
 */
public class MaintainSettingQuery extends SingleUseCase<DMMaintainSetting> {

    private MaintainRepository repository;

    private JobThread jobThread;

    public MaintainSettingQuery(MaintainRepository repository, JobThread jobThread) {
        this.repository = repository;
        this.jobThread = jobThread;
    }

    @Override
    protected Single<DMMaintainSetting> buildSingle() {
        return Single.just(repository).map(new Function<MaintainRepository, DMMaintainSetting>() {
            @Override
            public DMMaintainSetting apply(MaintainRepository maintainRepository) throws Exception {
                return repository.querySetting();
            }
        }).subscribeOn(jobThread.provideWorker()).observeOn(jobThread.providerUi());
    }
}
