package com.uaes.android.data.http;


import com.google.gson.JsonObject;
import com.uaes.android.data.json.CommonResponse;
import com.uaes.android.data.json.FuelFillRecordJson;
import com.uaes.android.data.json.FuelMonitorJson;
import com.uaes.android.data.json.FuelScale;
import com.uaes.android.data.json.FuelStationJson;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

/**
 *用油会计 后端接口
 * */
public interface HttpFuelHelper {

    /**
     * 本次循环，此种类型不需要循环调用
     * */
    String QUERY_TYPE_REAL_TIME = "realTime";
    /**
     * 近一周
     * */
    String QUERY_TYPE_WEEK = "week";
    /**
     * 近一月
     * */
    String QUERY_TYPE_MONTH = "mon";
    /**
     * 近100KM
     * */
    String QUERY_TYPE_HUNDRED = "hundred";
    /**
     * 近1000KM
     * */
    String QUERY_TYPE_THOUSAND = "thousand";
    /**
     * 出厂至今
     * */
    String QUERY_TYPE_ALL = "all";
    /**
     * 用油明细-查询油耗信息
     * 查询条件只能是
     * */
    @GET("/fuelconp/v1/fuel/fuelScale/{queryType}")
    Call<CommonResponse<FuelScale>> getFuelScale(@Path("queryType") String queryType);

    /**
     * 读取 用油监控数据点
     */
    @GET("/fuelconp/v1/fuel/consumption/monitor")
    Call<CommonResponse<FuelMonitorJson>> getMonitor();

    /**
     * 加油站查询
     * location: 116.418275,40.022874
     * strategy: 0 , 1, 2
     */
    @POST("/gas/v1/gasStation/getGasStationNearBy")
    @FormUrlEncoded
    Call<CommonResponse<List<FuelStationJson>>> getStation(@Field("location") String location,
                                                           @Field("strategy") int strategy);
    /**
     * 更新加油评价
     */
    @POST("fuelfill/v1/fillRecord/app/review")
    Call<JsonObject> setFuelAccount(@Query("eventId") long eventId, @Query("star") int star);

    /**
     * 读取加油记录列表
     */
    @GET("/fuelfill/v1/fillRecord/app/findListApp/{year}")
    Call<CommonResponse<List<FuelFillRecordJson>>> getFillRecord(@Path("year") String year);

    /**
     * 查询历史加油记录的 所有有数据的可用年份列表
     */
    @GET("fuelfill/v1/fillRecord/app/findFillYear")
    Call<CommonResponse<List<String>>> queryAvailableYears();
}
