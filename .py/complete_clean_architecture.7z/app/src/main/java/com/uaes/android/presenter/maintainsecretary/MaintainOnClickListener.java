package com.uaes.android.presenter.maintainsecretary;

public interface MaintainOnClickListener {

    void onClick(int type);
}
