package com.uaes.android.presenter.fuelaccountancy;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProvider;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.AxisBase;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.formatter.IAxisValueFormatter;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.uaes.android.R;
import com.uaes.android.databinding.FuelAccountancyFragmentFuelHistoryBinding;
import com.uaes.android.domain.entity.DMFuelFillHistory;

import javax.inject.Inject;

/**
 * @author qingxin.chen
 * Created by qingxin.chen on 2018/5/7.
 */
public class FuelHistoryFragment extends FuelAccountancyFragment implements OnChartValueSelectedListener {

    FuelAccountancyFragmentFuelHistoryBinding binding;

    @Inject
    ViewModelProvider.Factory factory;

    FuelAccountancyFuelHistoryViewModel viewModel;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        viewModel = ViewModelProviders.of(this, factory).get(FuelAccountancyFuelHistoryViewModel.class);
        viewModel.msgTips.observe(this, new Observer<String>() {
            @Override
            public void onChanged(@Nullable String s) {
                if (!TextUtils.isEmpty(s)) {
                    Toast.makeText(getContext(), s, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.fuel_accountancy_fragment_fuel_history, container, false);
        binding.setLifecycleOwner(this);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding.setViewModel(viewModel);
        binding.setListener(viewModel);
        binding.setDirectionListener(viewModel);
        binding.setRatingListener(viewModel);
        initBarchart();
        viewModel.init();
    }

    private void initBarchart() {
        BarChart barChart = binding.fuelAccountancyHistoryBarchart;
        barChart.setDrawBarShadow(false);
        barChart.setDrawValueAboveBar(false);
        barChart.setDescription(null);
        barChart.setDrawGridBackground(false);
        barChart.setScaleEnabled(false);
        barChart.enableScroll();
        barChart.setOnChartValueSelectedListener(this);

        XAxis xAxis = barChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(false);
        xAxis.setTextSize(20f);
        xAxis.setTextColor(Color.parseColor("#c0fcfdfd"));

        YAxis leftAxis = barChart.getAxisLeft();
        leftAxis.setPosition(YAxis.YAxisLabelPosition.INSIDE_CHART);
        leftAxis.setDrawLabels(true);
        leftAxis.setDrawGridLines(false);
        leftAxis.setTextSize(20f);
        leftAxis.setAxisMinimum(0);
        leftAxis.setTextColor(Color.parseColor("#c0fcfdfd"));
        leftAxis.setLabelCount(2, true);
        leftAxis.setValueFormatter(new IAxisValueFormatter() {
            @Override
            public String getFormattedValue(float value, AxisBase axis) {
                return (int) value == 0 ? "" : (int) value + "L";
            }
        });

        barChart.getAxisRight().setEnabled(false);
        barChart.setHighlightPerDragEnabled(false);
        barChart.setAutoScaleMinMaxEnabled(true);
        barChart.getLegend().setEnabled(false);
        barChart.setDrawBorders(false);
        barChart.setExtraOffsets(0, 30, 0, 13);
        barChart.setRenderer(new FuelAccountancyRoundCornerBarChartRender(barChart));


    }

    @Override
    public void onValueSelected(Entry e, Highlight h) {
        viewModel.updateUI((DMFuelFillHistory) e.getData());
    }

    @Override
    public void onNothingSelected() {
        viewModel.updateUI(null);
    }
}
