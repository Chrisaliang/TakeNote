package com.uaes.android.data.json;

import com.google.gson.annotations.SerializedName;

/**
 * 代表一次加油记录
 */
public class FuelFillRecordJson {

    /**
     * 加油量
     */
    @SerializedName("fillAmount")
    public String fillAmount;

    @SerializedName("fillStartTime")
    public String fillStartTime;

    /**
     * 加油站名成
     */
    @SerializedName("gasStationName")
    public String gasStationName;

    /**
     * 加油发生的日期
     */
    @SerializedName("fillStartDay")
    public String fillStartDay;

    /**
     * 评分
     */
    @SerializedName("evaluate")
    public float evaluate = -1;
    /**
     * 加油事件ID
     */
    @SerializedName("eventId")
    public long eventId;
}
