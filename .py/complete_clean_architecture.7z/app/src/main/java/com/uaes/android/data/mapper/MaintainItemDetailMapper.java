package com.uaes.android.data.mapper;

import android.content.Context;
import android.content.res.Resources;
import android.util.SparseIntArray;

import com.uaes.android.R;
import com.uaes.android.domain.entity.DMMaintainItemDetail;

import io.reactivex.functions.Function;

/**
 * Created by ${GY} on 2018/5/29
 * des：
 */
public class MaintainItemDetailMapper implements Function<Integer, DMMaintainItemDetail> {

    private static SparseIntArray titleList = new SparseIntArray();
    private static SparseIntArray contentList = new SparseIntArray();

    static {
        titleList.append(0, R.string.maintain_engine_oil_title_01);
        titleList.append(1, R.string.maintain_oil_filter_title_02);
        titleList.append(2, R.string.maintain_replace_transmission_oil_title_03);
        titleList.append(3, R.string.maintain_spark_plug_replacement_title_04);
        titleList.append(4, R.string.maintain_fuel_filter_title_05);
        titleList.append(5, R.string.maintain_air_cleaner_element_title_06);
        titleList.append(6, R.string.maintain_air_conditioner_filter_element_title_07);
        titleList.append(7, R.string.maintain_check_crankcase_risk_control_system_title_08);
        titleList.append(8, R.string.maintain_replace_engine_coolant_title_09);
        titleList.append(9, R.string.maintain_replace_brake_fluid_title_10);
        titleList.append(10, R.string.maintain_check_radiator_brake_connections_title_11);
        titleList.append(11, R.string.maintain_check_door_hinge_stop_trunk_lock_title_12);
        titleList.append(12, R.string.maintain_recommended_check_engine_belt_etc_title_13);

        contentList.append(0, R.string.maintain_engine_oil_content_01);
        contentList.append(1, R.string.maintain_oil_filter_content_02);
        contentList.append(2, R.string.maintain_replace_transmission_oil_content_03);
        contentList.append(3, R.string.maintain_spark_plug_replacement_content_04);
        contentList.append(4, R.string.maintain_fuel_filter_content_05);
        contentList.append(5, R.string.maintain_air_cleaner_element_content_06);
        contentList.append(6, R.string.maintain_air_conditioner_filter_element_content_07);
        contentList.append(7, R.string.maintain_check_crankcase_risk_control_system_content_08);
        contentList.append(8, R.string.maintain_replace_engine_coolant_content_09);
        contentList.append(9, R.string.maintain_replace_brake_fluid_content_10);
        contentList.append(10, R.string.maintain_check_radiator_brake_connections_content_11);
        contentList.append(11, R.string.maintain_check_door_hinge_stop_trunk_lock_content_12);
        contentList.append(12, R.string.maintain_recommended_check_engine_belt_etc_content_13);
    }

    private Context context;

    public MaintainItemDetailMapper(Context context) {
        this.context = context;
    }

    @SuppressWarnings("RedundantThrows")
    @Override
    public DMMaintainItemDetail apply(Integer type) throws Exception {
        DMMaintainItemDetail dmMaintainItemDetail = new DMMaintainItemDetail();
        Resources resources = context.getResources();
        dmMaintainItemDetail.title = resources.getString(titleList.get(type - 1));
        dmMaintainItemDetail.content = resources.getString(contentList.get(type - 1));
        return dmMaintainItemDetail;
    }
}
