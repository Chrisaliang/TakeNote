package com.uaes.android.domain;

import io.reactivex.Scheduler;

public interface JobThread {
    Scheduler providerUi();

    Scheduler provideWorker();
}
