package com.uaes.android.data.http;

import com.google.gson.annotations.SerializedName;

public class TokenResponse {
    @SerializedName("access_token")
    public String access_token;
    @SerializedName("token_type")
    public String token_type;
    @SerializedName("refresh_token")
    public String refresh_token;
    @SerializedName("expires_in")
    public int expires_in;
    @SerializedName("scope")
    public String scope;
}
