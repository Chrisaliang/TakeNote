package com.uaes.android.domain;

import android.support.annotation.IntDef;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Result of a UseCase. Basically Result itself has four status:
 * {@link #STATUS_ERROR}, {@link #STATUS_FILL}
 * */
@SuppressWarnings("WeakerAccess")
public class Result<T> {


    @IntDef({STATUS_FILL, STATUS_ERROR})
    @Retention(RetentionPolicy.SOURCE)
    public @interface Status{}
    /**
     * Result was filled normally.
     * */
    public static final int STATUS_FILL = 0;


    public static final int STATUS_ERROR = 3;

    @Status
    public int status;

    public T content;

    public ResultException error;

    public Result(T content) {
        this.content = content;
    }
}
