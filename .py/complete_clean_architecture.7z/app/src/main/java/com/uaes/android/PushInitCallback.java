package com.uaes.android;

import com.alibaba.sdk.android.push.CommonCallback;

import timber.log.Timber;

class PushInitCallback implements CommonCallback {

    private static final String TAG = "PushInitCallback";

    private final String tag;

    PushInitCallback(String tag) {
        this.tag = tag;
    }

    @Override
    public void onSuccess(String s) {
        Timber.tag(tag).d("Init aliPush success, response: %s", s);
    }

    @Override
    public void onFailed(String errorCode, String errorMessage) {
        Timber.tag(tag).d("Init aliPush failed, errorCode: %s, msgTips: %s", errorCode, errorMessage);
    }
}
