package com.uaes.android.presenter.maintainsecretary;

import android.arch.lifecycle.Observer;
import android.arch.lifecycle.ViewModelProviders;
import android.databinding.DataBindingUtil;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.databinding.MaintainFragmentQrCodeBinding;

/**
 * Created by ${GY} on 2018/5/9
 * des：
 */
public class MaintainQrCodeFragment extends MaintainBaseFragment implements MaintainOnClickListener {

    private static final String TAG = "MaintainQrCodeFragment";
    private MaintainFragmentQrCodeBinding binding;
    private MaintainQrCodeViewModel maintainQrCodeViewModel;

    private Observer<Bitmap> dataOberver = new Observer<Bitmap>() {
        @Override
        public void onChanged(@Nullable Bitmap bitmap) {
            if (bitmap != null) {
                binding.ivQrcode.setImageBitmap(bitmap);
            }
        }
    };


    @Override

    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        maintainQrCodeViewModel = ViewModelProviders.of(this).get(MaintainQrCodeViewModel.class);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.maintain_fragment_qr_code, container, false);
        binding.setLifecycleOwner(this);
        maintainQrCodeViewModel.getQrCodeImageObserver().observe(this, dataOberver);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        binding.setMaintainQRcodeViewModel(maintainQrCodeViewModel);
        binding.setMaintainOnClickListener(this);
        maintainQrCodeViewModel.createQRCode();
    }

    @Override
    public void onClick(int type) {
        mNavigator.onBack();
    }
}
