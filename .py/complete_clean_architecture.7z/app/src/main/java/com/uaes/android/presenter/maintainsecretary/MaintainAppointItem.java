package com.uaes.android.presenter.maintainsecretary;

import android.os.Bundle;

/**
 * Created by ${GY} on 2018/5/8
 * des：
 */
public class MaintainAppointItem {
    public String maintainAddress;
    public String maintainPhone;
    public int position;

    /**
     * 坐标经度
     */
    public double longitude;
    /**
     * 坐标纬度
     */
    public double latitude;


    public Bundle getPhoneBundle() {
        Bundle bundle = new Bundle();
        bundle.putString(MaintainConstant.MAINTAIN_ADDRESS, maintainAddress);
        bundle.putString(MaintainConstant.MAINTAIN_PHONE, maintainPhone);
        return bundle;
    }
}
