package com.uaes.android.presenter.driver;

import android.databinding.DataBindingUtil;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.amap.api.maps.AMap;
import com.amap.api.maps.CameraUpdateFactory;
import com.amap.api.maps.UiSettings;
import com.amap.api.maps.model.BitmapDescriptor;
import com.amap.api.maps.model.BitmapDescriptorFactory;
import com.amap.api.maps.model.LatLng;
import com.amap.api.maps.model.LatLngBounds;
import com.amap.api.maps.model.Marker;
import com.amap.api.maps.model.MarkerOptions;
import com.amap.api.maps.model.Polyline;
import com.amap.api.maps.model.PolylineOptions;
import com.amap.api.trace.LBSTraceClient;
import com.amap.api.trace.TraceListener;
import com.amap.api.trace.TraceLocation;
import com.amap.api.trace.TraceOverlay;
import com.uaes.android.R;
import com.uaes.android.databinding.DriverMasterMapFragmentBinding;
import com.uaes.android.presenter.BaseFragment;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import timber.log.Timber;

public class MapFragment extends BaseFragment implements BackListener, TraceListener {

    public static final String MAP_LOCATION_ARGS = "com.uaes.android.presenter.driver.map.location.ARGS";

    private static final String TAG = "MapFragment";

    DriverMasterMapFragmentBinding binding;
    private AMap aMap;
    private BitmapDescriptor markerIcon;
    private BitmapDescriptor startIcon;
    private BitmapDescriptor endIcon;
    private BitmapDescriptor customTexture;
    private List<Marker> markers = new ArrayList<>(0);


    private ConcurrentMap<Integer, TraceOverlay> mOverlayList = new ConcurrentHashMap<>();


    /**
     * 地图定位点时间间隔
     * 目前为5s
     */
    private long timeSpace = 5;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater,
                R.layout.driver_master_map_fragment, container, false);
        binding.setBack(this);
        binding.setLifecycleOwner(this);
        binding.mapView.onCreate(savedInstanceState);
        if (aMap == null)
            aMap = binding.mapView.getMap();
        UiSettings uiSettings = aMap.getUiSettings();
        uiSettings.setMyLocationButtonEnabled(false);
        uiSettings.setZoomControlsEnabled(false);
        aMap.animateCamera(CameraUpdateFactory.zoomTo(14));

        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (markerIcon == null)
            markerIcon = BitmapDescriptorFactory.fromResource(R.drawable.driver_master_map_marker_icon);
        if (customTexture == null)
            customTexture = BitmapDescriptorFactory.fromResource(R.drawable.driver_master_map_router_texture);

        Bundle arguments = getArguments();
        if (arguments != null) {
            LatLng[] list = (LatLng[]) arguments.getParcelableArray(MAP_LOCATION_ARGS);

            if (list == null || list.length <= 0) {
                return;
            }
            if (list.length == 1) {
                showSingleMarker(list[0]);
            } else {
                showLine(Arrays.asList(list));
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        binding.mapView.onResume();

    }

    @Override
    public void onPause() {
        super.onPause();
        if (binding.mapView != null)
            binding.mapView.onPause();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        if (binding.mapView != null)
            binding.mapView.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        if (binding.mapView != null)
            binding.mapView.onLowMemory();
    }

    @Override
    public void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        if (binding.mapView != null)
            binding.mapView.onSaveInstanceState(outState);
    }


    @SuppressWarnings("unused")
    private void traceGrasp(List<LatLng> list) {
        int mSequenceLineID = 1000;
        if (mOverlayList.containsKey(mSequenceLineID)) {
            TraceOverlay overlay = mOverlayList.get(mSequenceLineID);
            overlay.zoopToSpan();
            return;
        }

        List<TraceLocation> mTraceList = new ArrayList<>(0);
        for (LatLng latLng : list) {
            mTraceList.add(new TraceLocation(latLng.latitude, latLng.longitude, 10, 50, timeSpace));
        }


        TraceOverlay mTraceOverlay = new TraceOverlay(aMap);
        mOverlayList.put(mSequenceLineID, mTraceOverlay);
        List<LatLng> mapList = traceLocationToMap(mTraceList);
        mTraceOverlay.setProperCamera(mapList);
//        mResultShow.setText(mDistanceString);
//        mLowSpeedShow.setText(mStopTimeString);
        LBSTraceClient mTraceClient = LBSTraceClient.getInstance(binding.mapView.getContext().getApplicationContext());

        int mCoordinateType = LBSTraceClient.TYPE_AMAP;
        mTraceClient.queryProcessedTrace(mSequenceLineID, mTraceList,
                mCoordinateType, this);
    }


    public void showLine(List<LatLng> latLngs) {

        Timber.tag(TAG).d("显示定位路线%s", latLngs);

        clearMap();

        if (startIcon == null)
            startIcon = BitmapDescriptorFactory.fromResource(R.drawable.map_marker_start);
        MarkerOptions statMarker = new MarkerOptions().icon(startIcon).position(latLngs.get(0));
        markers.add(aMap.addMarker(statMarker));

        if (endIcon == null)
            endIcon = BitmapDescriptorFactory.fromResource(R.drawable.map_marker_end);
        MarkerOptions endMarker = new MarkerOptions().icon(endIcon).position(latLngs.get(latLngs.size() - 1));
        markers.add(aMap.addMarker(endMarker));

        Polyline polyline = aMap.addPolyline(new PolylineOptions()
                .addAll(latLngs).width(10));
        polyline.setCustomTexture(customTexture);
//        polyline.setColor(Color.parseColor("#0299e8"));

        LatLngBounds.Builder bounds = new LatLngBounds.Builder();
        for (LatLng latLng : latLngs) {
            bounds.include(latLng);
        }
        animateBounds(bounds.build(), 50, 50, 100, 50);
    }


    @SuppressWarnings("unused")
    public void showRouter(List<LatLng> list) {


//        TraceOverlay traceOverlay = new TraceOverlay(aMap, list);
        int traceId = 0;


        LBSTraceClient traceClient = LBSTraceClient.getInstance(binding.mapView.getContext().getApplicationContext());
        List<TraceLocation> traceList = new ArrayList<>(0);
        for (LatLng latLng : list) {
            traceList.add(new TraceLocation(latLng.latitude, latLng.longitude, 10, 50, timeSpace));
        }
        traceClient.queryProcessedTrace(traceId, traceList, LBSTraceClient.TYPE_AMAP, this);

//        traceClient.startTrace(new TraceStatusListener() {
//            @Override
//            public void onTraceStatus(List<TraceLocation> list, List<LatLng> list1, String s) {
//
//            }
//        });

        traceClient.stopTrace();


    }

    public void animateBounds(LatLngBounds bounds,
                              int paddingLeft,
                              int paddingRight,
                              int paddingTop,
                              int paddingBottom) {
        aMap.animateCamera(
                CameraUpdateFactory.newLatLngBoundsRect(
                        bounds, paddingLeft, paddingRight, paddingTop, paddingBottom));
    }

    private void clearMap() {
        aMap.clear();
    }


    public void showSingleMarker(LatLng latLng) {

        Timber.tag(TAG).d("显示定位点：%s", latLng);

        clearMarker();

        MarkerOptions marker = new MarkerOptions().icon(markerIcon).position(latLng);
        markers.add(aMap.addMarker(marker));

        aMap.animateCamera(CameraUpdateFactory.newLatLng(latLng));
    }

    private void clearMarker() {
        if (markers != null && !markers.isEmpty())
            for (Marker marker : markers) {
                marker.remove();
            }
    }


    @Override
    public void popupBack() {
        Objects.requireNonNull(getParentFragment()).getChildFragmentManager().popBackStack();
    }


    /**
     * 轨迹纠偏点转换为地图LatLng
     *
     * @param traceLocationList 纠偏点
     * @return 地图点
     */
    public List<LatLng> traceLocationToMap(List<TraceLocation> traceLocationList) {
        List<LatLng> mapList = new ArrayList<>();
        for (TraceLocation location : traceLocationList) {
            LatLng latlng = new LatLng(location.getLatitude(),
                    location.getLongitude());
            mapList.add(latlng);
        }
        return mapList;
    }

    @Override
    public void onRequestFailed(int lineID, String s) {
        if (mOverlayList.containsKey(lineID)) {
            TraceOverlay overlay = mOverlayList.get(lineID);
            overlay.setTraceStatus(TraceOverlay.TRACE_STATUS_FAILURE);
        }
    }

    @Override
    public void onTraceProcessing(int lineID, int index, List<LatLng> segments) {

        if (segments == null) {
            return;
        }
        if (mOverlayList.containsKey(lineID)) {
            TraceOverlay overlay = mOverlayList.get(lineID);
            overlay.setTraceStatus(TraceOverlay.TRACE_STATUS_PROCESSING);
            overlay.add(segments);
        }
    }

    @Override
    public void onFinished(int lineID, List<LatLng> list, int distance, int watingtime) {
        if (mOverlayList.containsKey(lineID)) {
            TraceOverlay overlay = mOverlayList.get(lineID);
            overlay.setTraceStatus(TraceOverlay.TRACE_STATUS_FINISH);
            overlay.setDistance(distance);
            overlay.setWaitTime(watingtime);
//            setDistanceWaitInfo(overlay);
        }
    }
}
