package com.uaes.android.data.http;

import android.support.annotation.NonNull;

import okhttp3.logging.HttpLoggingInterceptor;
import timber.log.Timber;

public class HttpLogger implements HttpLoggingInterceptor.Logger {

    private static final String TAG = "HttpLogger";

    @Override
    public void log(@NonNull String message) {
        Timber.tag(TAG).d(message);
    }
}
