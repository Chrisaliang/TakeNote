package com.uaes.android.domain.usecase;

import com.uaes.android.domain.BatteryRepository;
import com.uaes.android.domain.JobThread;
import com.uaes.android.domain.entity.DMBatteryStatus;

import java.util.concurrent.TimeUnit;

import io.reactivex.Observable;
import io.reactivex.functions.Function;

/**
 * 订阅电池状态用例
 */
public class BatteryStatusSubscription {

    private static final String TAG = "BatteryStatusSubscripti";

    private BatteryRepository repository;

    private JobThread jobThread;

    private DMBatteryStatus status = new DMBatteryStatus();

    public BatteryStatusSubscription(BatteryRepository repository, JobThread jobThread) {
        this.repository = repository;
        this.jobThread = jobThread;
    }

    public Observable<DMBatteryStatus> execute() {
        return Observable.interval(0, 10, TimeUnit.SECONDS, jobThread.provideWorker())
                .flatMap(new Function<Long, Observable<DMBatteryStatus>>() {
                    @Override
                    public Observable<DMBatteryStatus> apply(Long aLong) throws Exception {
                        return Observable.just(repository).map(new Function<BatteryRepository, DMBatteryStatus>() {
                            @Override
                            public DMBatteryStatus apply(BatteryRepository repository) throws Exception {
                                status = repository.queryBatteryStatus();
                                DMBatteryStatus temp = repository.queryBatteryVol();
                                status.isBatteryLifeFull = temp.isBatteryLifeFull;
                                return status;
                            }
                        }).onErrorReturnItem(status).subscribeOn(jobThread.provideWorker());
                    }
                }).map(new Function<DMBatteryStatus, DMBatteryStatus>() {
                    @Override
                    public DMBatteryStatus apply(DMBatteryStatus dmBatteryStatus) throws Exception {
                        status.hintDescription = repository.queryBatteryDescription(status.isAgeing, status.isBatteryLifeFull);
                        return status;
                    }
                }).subscribeOn(jobThread.provideWorker()).observeOn(jobThread.providerUi());
    }
}
