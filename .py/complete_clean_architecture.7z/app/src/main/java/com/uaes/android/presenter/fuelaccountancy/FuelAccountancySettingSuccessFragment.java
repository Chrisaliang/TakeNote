package com.uaes.android.presenter.fuelaccountancy;

import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;

import timber.log.Timber;

public class FuelAccountancySettingSuccessFragment extends FuelAccountancyFragment {

    private static final String TAG = "FuelAccountancySet";

    private final Handler handler = new Handler();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fuel_accountancy_fragment_setting_success, container, false);
    }

    @Override
    public void onResume() {
        super.onResume();
        handler.postDelayed(shutDown, 3000);
    }

    @Override
    public void onStop() {
        super.onStop();
        handler.removeCallbacks(shutDown);
    }

    private final Runnable shutDown = new Runnable() {
        @Override
        public void run() {
            Timber.tag(TAG).d("close FuelAccountancySetSuccess fragment");
            navigator.back();
        }
    };
}
