package com.uaes.android.presenter.fuelaccountancy;

import android.databinding.DataBindingUtil;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.uaes.android.R;
import com.uaes.android.databinding.FuelAccountancyItemStationBinding;

import java.util.ArrayList;
import java.util.List;

import timber.log.Timber;

/**
 * 加油站Adapter
 */
public class FuelAccountancyStationAdapter extends RecyclerView.Adapter<FuelAccountancyStationAdapter.StationViewHolder> {
    private static final String TAG = "FuelAccountancyStationA";

    private final List<FuelAccountancyStationItemViewModel> stationItemViewModelList;

    FuelAccountancyStationAdapter() {
        stationItemViewModelList = new ArrayList<>();
    }

    @NonNull
    @Override
    public StationViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.fuel_accountancy_item_station, parent, false);
        return new StationViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StationViewHolder holder, int position) {
        holder.bindView(stationItemViewModelList.get(position));
    }

    @Override
    public int getItemCount() {
        return stationItemViewModelList.size();
    }

    public void updateStationAll(List<FuelAccountancyStationItemViewModel> stationItemViewModels) {
        for (int i = 0; i < stationItemViewModels.size(); i++) {
            if (i == 0)
                stationItemViewModels.get(i).isChecked.set(true);
            else
                stationItemViewModels.get(i).isChecked.set(false);
        }
        stationItemViewModelList.clear();
        stationItemViewModelList.addAll(stationItemViewModels);
        notifyDataSetChanged();
    }

    class StationViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        private final FuelAccountancyItemStationBinding itemStationBinding;


        StationViewHolder(View itemView) {
            super(itemView);
            itemStationBinding = DataBindingUtil.bind(itemView);
        }

        void bindView(FuelAccountancyStationItemViewModel stationItemViewModel) {
            itemStationBinding.setViewModel(stationItemViewModel);
            itemStationBinding.fuelAccountancyStationItemStation.setOnClickListener(this);

            // There is bug in lifecycleOwner, if we call
            // "executePendingBindings()", the observe() method will be call
            // but , bindings are not ready.
            itemStationBinding.executePendingBindings();
        }


        @Override
        public void onClick(View v) {
            Timber.tag(TAG).d("click station item position：%s", getAdapterPosition());
            for (int i = 0; i < stationItemViewModelList.size(); i++) {
                FuelAccountancyStationItemViewModel viewModel = stationItemViewModelList.get(i);
                viewModel.isChecked.set(i == getAdapterPosition());
            }
            notifyDataSetChanged();
        }
    }
}
