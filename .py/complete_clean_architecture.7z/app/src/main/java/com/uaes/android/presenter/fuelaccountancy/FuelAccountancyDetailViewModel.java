package com.uaes.android.presenter.fuelaccountancy;

import android.arch.lifecycle.MutableLiveData;
import android.arch.lifecycle.ViewModel;

import com.github.mikephil.charting.data.PieEntry;
import com.uaes.android.domain.FuelHelperRepository;
import com.uaes.android.domain.Result;
import com.uaes.android.domain.entity.DMFuelScale;
import com.uaes.android.domain.usecase.FuelScaleQuery;
import com.uaes.android.domain.usecase.FuelScaleRealTimeQuery;

import java.util.ArrayList;

import io.reactivex.Observer;
import io.reactivex.SingleObserver;
import io.reactivex.disposables.Disposable;
import timber.log.Timber;

/**
 * @author qingxin.chen
 * Created by qingxin.chen on 2018/5/7.
 */
public class FuelAccountancyDetailViewModel extends ViewModel {

    private static final String TAG = "FuelAccounDetailViewMod";

    private final MutableLiveData<Integer> selectStatus = new MutableLiveData<>();

    public final MutableLiveData<ArrayList<PieEntry>> fuelStatus = new MutableLiveData<>();

    private FuelScaleQuery typeQuery;

    private FuelScaleRealTimeQuery realTimeQuery;

    private Disposable disposable;

    private Disposable subscription;

    private PieDataMapper pieDataMapper = new PieDataMapper();

    public FuelAccountancyDetailViewModel(FuelScaleQuery typeQuery, FuelScaleRealTimeQuery realTimeQuery) {
        this.typeQuery = typeQuery;
        this.realTimeQuery = realTimeQuery;
        selectStatus.setValue(-1);
    }


    public void onSelected(int type) {
        if (selectStatus.getValue() == null || selectStatus.getValue() == type) return;
        Timber.tag(TAG).d(String.valueOf(selectStatus.getValue()));
        selectStatus.setValue(type);
        checkPreviewDisposable();
        if (type == FuelHelperRepository.TYPE_FUEL_REAL_TIME) {
            realTimeQuery.execute().subscribe(new Observer<DMFuelScale>() {

                @Override
                public void onSubscribe(Disposable d) {
                    if (subscription != null)
                        subscription.dispose();
                    subscription = d;
                }

                @Override
                public void onNext(DMFuelScale scale) {
                    Timber.tag(TAG).d("onNext: realTimeQuery%s", scale);
                    fuelStatus.setValue(pieDataMapper.map(scale));
                }

                @Override
                public void onError(Throwable e) {
                    Timber.tag(TAG).e(e);
                }

                @Override
                public void onComplete() {

                }
            });
        } else {
            typeQuery.setType(type);
            typeQuery.execute().subscribe(new SingleObserver<Result<DMFuelScale>>() {
                @Override
                public void onSubscribe(Disposable d) {
                    if (disposable != null) {
                        disposable.dispose();
                    }
                    disposable = d;
                }

                @Override
                public void onSuccess(Result<DMFuelScale> scale) {
                    Timber.tag(TAG).d("onNext: typeQuery%s", scale.content);
                    fuelStatus.setValue(pieDataMapper.map(scale.content));
                }

                @Override
                public void onError(Throwable e) {
                    Timber.tag(TAG).e(e, "single query");
                }
            });
        }
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        checkPreviewDisposable();
    }

    private void checkPreviewDisposable() {
        if (disposable != null)
            disposable.dispose();
        if (subscription != null)
            subscription.dispose();
    }

    public void init() {
        onSelected(0);
    }
}