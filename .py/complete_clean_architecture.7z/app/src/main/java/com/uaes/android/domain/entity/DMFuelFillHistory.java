package com.uaes.android.domain.entity;

/**
 * 数据
 */
public class DMFuelFillHistory {
    /**
     * 主Id
     */
    public long id;
    /**
     * 加油日期
     */
    public String date;
    /**
     * 加油量
     */
    public float volume;

    /**
     * 加油站名称
     */
    public String address;
    /**
     * 评分
     * 为 -1 表示没有点评
     */
    public int rating;

    /**
     * 是否评论
     */
    public boolean isComment;

    @Override
    public String toString() {
        return "DMFuelFillHistory{" +
                "id=" + id +
                ", date='" + date + '\'' +
                ", volume=" + volume +
                ", ADDRESS='" + address + '\'' +
                ", rating=" + rating +
                '}';
    }
}
