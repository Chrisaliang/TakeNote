package com.uaes.android;

import com.google.gson.Gson;
import com.uaes.android.data.AMapLocationRepository;
import com.uaes.android.data.BatteryRepositoryImp;
import com.uaes.android.data.DriverMasterRepositoryImp;
import com.uaes.android.data.FuelHelperRepositoryImp;
import com.uaes.android.data.MaintainRepositoryImp;
import com.uaes.android.data.MessageCenterRepositoryImp;
import com.uaes.android.data.PowerDefenderRepositoryImp;
import com.uaes.android.data.S4ShopRepositoryImp;
import com.uaes.android.data.http.DriverMasterApi;
import com.uaes.android.data.http.Http4SShopApi;
import com.uaes.android.data.http.HttpBatteryApi;
import com.uaes.android.data.http.HttpFuelHelper;
import com.uaes.android.data.http.HttpMaintainApi;
import com.uaes.android.data.http.HttpPowerDefenderApi;
import com.uaes.android.data.http.SettingApi;
import com.uaes.android.data.room.CacheDao;
import com.uaes.android.domain.BatteryRepository;
import com.uaes.android.domain.DriverMasterRepository;
import com.uaes.android.domain.FuelHelperRepository;
import com.uaes.android.domain.LocationRepository;
import com.uaes.android.domain.MaintainRepository;
import com.uaes.android.domain.MessageCenterRepository;
import com.uaes.android.domain.PowerDefenderRepository;
import com.uaes.android.domain.S4ShopRepository;

import javax.inject.Singleton;

import dagger.Module;
import dagger.Provides;

@Module
public abstract class RepositoryModule {

    @Provides
    @Singleton
    static FuelHelperRepository providerFuelHelperRepository(HttpFuelHelper api, SettingApi settingApi, App app, Gson gson) {
        return new FuelHelperRepositoryImp(api, settingApi, app, gson);
    }

    @Provides
    @Singleton
    public static MessageCenterRepository messageCenterRepository(CacheDao cacheDao) {
        return new MessageCenterRepositoryImp(cacheDao);
    }

    @Provides
    @Singleton
    public static DriverMasterRepository driverManagerDetailRepository(DriverMasterApi api) {
        return new DriverMasterRepositoryImp(api);
    }

    @Provides
    @Singleton
    static LocationRepository aMapLocationRepository(App app) {
        return new AMapLocationRepository(app);
    }

    @Provides
    @Singleton
    static BatteryRepository batteryRepository(HttpBatteryApi api, App app) {
        return new BatteryRepositoryImp(app, api);
    }

    @Provides
    @Singleton
    static S4ShopRepository s4ShopRepository(Http4SShopApi api) {
        return new S4ShopRepositoryImp(api);
    }

    @Provides
    @Singleton
    static MaintainRepository maintainRepository(HttpMaintainApi api, Gson gson, App app) {
        return new MaintainRepositoryImp(api, gson, app);
    }

    @Provides
    @Singleton
    static PowerDefenderRepository powerDefenderRepository(HttpPowerDefenderApi httpPowerDefenderApi, Gson gson) {
        return new PowerDefenderRepositoryImp(httpPowerDefenderApi, gson);
    }
}
